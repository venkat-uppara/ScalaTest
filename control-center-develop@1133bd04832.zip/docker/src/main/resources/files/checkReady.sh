#!/bin/sh
host=localhost
port=8443
curl -k https://$host:$port/ControlCenter-Desktop/healthCheck/readiness | grep '"status":"OK"' > healthCheckResults.txt

#!/bin/sh

echo Starting Control Center application...

cd $HOME/

export HOST_NAME_IP=0.0.0.0;

sed -i -e 's#STATIC_AUTHENTICATION_URL#'$STATIC_AUTHENTICATION_URL'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#STATIC_AUTHORIZATION_URL#'$STATIC_AUTHORIZATION_URL'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#STATIC_SESSIONMANAGEMENT_URL#'$STATIC_SESSIONMANAGEMENT_URL'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#STATIC_AUDIT_URL#'$STATIC_AUDIT_URL'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#STATIC_METADATA_URL#'$STATIC_METADATA_URL'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#STATIC_LISTMANAGEMENT_URL#'$STATIC_LISTMANAGEMENT_URL'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#STATIC_CSI2A_SESSIONMANAGEMENT_URL#'$STATIC_CSI2A_SESSIONMANAGEMENT_URL'#g' WEB-INF/classes/bsicontext.properties

sed -i -e 's#DB_URL#'$DB_URL'#g' WEB-INF/classes/appjdbc.properties
sed -i -e 's#DB_USER#'$DB_USER'#g' WEB-INF/classes/appjdbc.properties
sed -i -e 's#DB_PASSWORD#'$DB_PASSWORD'#g' WEB-INF/classes/appjdbc.properties
sed -i -e 's#DB_DRIVER#'$DB_DRIVER'#g' WEB-INF/classes/appjdbc.properties
sed -i -e 's#DB_TYPE#'$DB_TYPE'#g' WEB-INF/classes/appjdbc.properties

sed -i -e 's#BSI_SSL_ENABLED#'$BSI_SSL_ENABLED'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#BSI_KEYSTORE_PASSWORD#'$BSI_KEYSTORE_PASSWORD'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#BSI_TRUSTSTORE_PASSWORD#'$BSI_TRUSTSTORE_PASSWORD'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#BSI_CIPHER_PASSWORD#'$BSI_CIPHER_PASSWORD'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#BSI_KEYSTORE_PATH#'$BSI_KEYSTORE_PATH'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#BSI_TRUSTSTORE_PATH#'$BSI_TRUSTSTORE_PATH'#g' WEB-INF/classes/bsicontext.properties
sed -i -e 's#CC_BSI_CONNECTION_TIMEOUT#'$CC_BSI_CONNECTION_TIMEOUT'#g' WEB-INF/classes/bsicontext.properties

sed -i  -e 's|^healthcheck.username=.*$|healthcheck.username='${HEALTH_CHECK_USERNAME}'|' WEB-INF/classes/healthcheck.properties
sed -i  -e 's|^healthcheck.password=.*$|healthcheck.password='${HEALTH_CHECK_PASSWORD}'|' WEB-INF/classes/healthcheck.properties
sed -i  -e 's|^healthcheck.organization=.*$|healthcheck.organization='${HEALTH_CHECK_ORG}'|' WEB-INF/classes/healthcheck.properties
sed -i  -e 's|^healthcheck.refresh.time=.*$|healthcheck.refresh.time='${HEALTH_CHECK_REFRESH_TIME}'|' WEB-INF/classes/healthcheck.properties
sed -i  -e 's|^healthcheck.cipher.password=.*$|healthcheck.cipher.password='${HEALTH_CHECK_CIPHER_PASSWORD}'|' WEB-INF/classes/healthcheck.properties

sed -i -e 's#ISCALE_STORE_PATH#'$ISCALE_STORE_PATH'#g' WEB-INF/classes/iscale.properties

sed -i -e 's#HOSTNAME#'$HOSTNAME'#g' globalConfig.properties;
sed -i -e 's#KEKKEYSTOREPATH#'$KEKKEYSTOREPATH'#g' globalConfig.properties
sed -i -e 's#KEKKEYSTOREPASS#'$KEKKEYSTOREPASS'#g' globalConfig.properties
sed -i -e 's#SSOKEYSTOREPATH#'$SSOKEYSTOREPATH'#g' globalConfig.properties
sed -i -e 's#SSOKEYSTOREPASS#'$SSOKEYSTOREPASS'#g' globalConfig.properties

mv ObjectPool_Config.properties WEB-INF/classes/ObjectPool_Config.properties;
mv globalConfig.properties $CATALINA_HOME/lib/

jar uvf ControlCenter-Desktop.war WEB-INF/classes
rm -Rf WEB-INF/
mv ControlCenter-Desktop.war $CATALINA_HOME/webapps

sed -i '2 i\export CATALINA_OPTS="$CATALINA_OPTS -Duser.home=$HOME -Djava.rmi.server.hostname=$HOST_NAME_IP -Dcom.aciworldwide.log.level=$LOG_LVL_CF $CUSTOM_JAVA_OPTS"' $CATALINA_HOME/bin/catalina.sh;

sed -i '3 i\export JAVA_OPTS="-Dcc.max.threads=$CC_MAX_THREADS -Dcc.connection.timeout=$CC_CONNECTION_TIMEOUT -Dtomcat.keyStoreFilePath=$TOMCAT_KEYSTORE_PATH -Dtomcat.keyStorePassword=$TOMCAT_KEYSTORE_PSW -Dtomcat.trustStoreFilePath=$TOMCAT_TRUSTSTORE_PATH -Dtomcat.trustStorePassword=$TOMCAT_TRUSTSTORE_PSW -Dapplication.server.log.level=$APPLICATION_SERVER_LOG_LEVEL -Droot.log.level=$LOG_LVL_CF -Dspringframework.log.level=$LOG_LVL_SPRING -Duser.home=${HOME} -Dapsf.logs.home=${HOME} -Dtomcat.clientauth=$TOMCAT_CLIENTAUTH"' $CATALINA_HOME/bin/catalina.sh;

if [ "$ENABLE_DYNATRACE" = "true" ] ; then
    sed -i '4 i\export CATALINA_OPTS="$CATALINA_OPTS -agentpath:$AGENT_LIB64=name=$DYNATRACE_PROFILE_NAME,server=$DYNATRACE_SERVER"' $CATALINA_HOME/bin/catalina.sh;
fi;
#adding JMX exporter - Java metrics via http:
sed -i '5 i\export CATALINA_OPTS="$CATALINA_OPTS -javaagent:/opt/home/jmx_prometheus_javaagent.jar=9090:/opt/home/jmx_prometheus-javaagent-config.yaml"' $CATALINA_HOME/bin/catalina.sh;

$CATALINA_HOME/bin/catalina.sh run

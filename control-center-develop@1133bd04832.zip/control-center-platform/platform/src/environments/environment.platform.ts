import { Routes } from '@angular/router';

import { environment as prodEnvironment } from './environment.prod';

//
// Add the platform's lazy routes.
//
export const routes: Routes = [
    {
        path: 'upf/LmPlugin',
        loadChildren: './plugins/lm-plugin/src/app/lm-plugin.module#LmPluginModule'
    },    {
        path: 'upf/RmPlugin',
        loadChildren: './plugins/rm-plugin/src/app/rm-plugin.module#RmPluginModule'
    },
	{
	 path: 'upf/CbPlugin',
        loadChildren: './plugins/cb-plugin/src/app/cb-plugin.module#CbPluginModule'
	}
];

//
// Add the platform's widget modules.
//
export const widgetModules: any = [];

export const environment = prodEnvironment;

/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2019 by ACI Worldwide Inc.                                  *
 *  All rights reserved.                                                      *
 *                                                                            *
 *  This software is the confidential and proprietary information of ACI      *
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such   *
 *  Confidential Information and shall use it only in accordance with the     *
 *  terms of the license agreement you entered with ACI Worldwide Inc.        *
 ******************************************************************************/

package com.aciworldwide.rms.controlcenter.healthcheck;

import com.aci.titanium.healthcheck.Health;
import com.aciworldwide.rms.se.healthcheck.EntitlementsHealthIndicator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Controller for control center health checks
 */
@Controller
public class HealthCheckController {

  @Autowired
  private EntitlementsHealthIndicator entitlementsHealthIndicator;

  /**
   * Checks health and returns the result.
   * @return - Health object in the JSON format
   */
  @RequestMapping(value = "/readiness", method = RequestMethod.GET)
  @ResponseBody
  public Health getKnownHealth() {
    return entitlementsHealthIndicator.getHealth();
  }

}
/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2019 by ACI Worldwide Inc.                                  *
 *  All rights reserved.                                                      *
 *                                                                            *
 *  This software is the confidential and proprietary information of ACI      *
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such   *
 *  Confidential Information and shall use it only in accordance with the     *
 *  terms of the license agreement you entered with ACI Worldwide Inc.        *
 ******************************************************************************/

package com.aciworldwide.rms.controlcenter.healthcheck;

import com.aciworldwide.rms.controlcenter.common.Constants;
import com.aciworldwide.rms.se.sdk.service.entitlements.EntitlementsAuthenticationHelper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * Configuration for Health check components.
 */
@Configuration
@PropertySource({"classpath:healthcheck.properties"})
public class HealthCheckConfiguration {

  @Bean
  public EntitlementsAuthenticationHelper entitlementsAuthenticationHelper(
      @Value("${healthcheck.password}") String password, @Value("${healthcheck.username}") String username,
      @Value("${healthcheck.organization}") String organization,
      @Value("${healthcheck.refresh.time}") String refreshTime,
      @Value("${healthcheck.cipher.password:}") String cipher) {
    EntitlementsAuthenticationHelper authenticationHelper = new EntitlementsAuthenticationHelper() {
      @Override
      protected String getStoredPassword() {
        return password;
      }
    };

    authenticationHelper.setOrganization(organization);
    authenticationHelper.setUsername(username);
    authenticationHelper.setRefreshTimeOut(refreshTime);
    authenticationHelper.setCipher(cipher);
    authenticationHelper.setApplicationId(Constants.CONTROL_CENTER_APPID);

    return authenticationHelper;
  }

}
package com.aciworldwide.rms.controlcenter.common;

/**
 * Class to define Control center desktop constants
 */
public abstract class Constants {

  /**
   * Application Id for control center. Used for audit logs.
   */
  public static final String CONTROL_CENTER_APPID = "ControlCenter";

}
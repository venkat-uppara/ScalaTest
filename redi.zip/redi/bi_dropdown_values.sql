select * FROM redi.bi_dropdown_values

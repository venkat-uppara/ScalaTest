package com.aciworldwide.ra.redi.stream.consumer

import com.aciworldwide.ra.redi.stream.consumer.constants.AppConstants._
import com.aciworldwide.ra.redi.utils.ConfUtils.loadJdbcConfigFromArgs
import com.aciworldwide.ra.redi.utils.ReadWriteUtils._
import com.aciworldwide.ra.redi.utils.SparkUtils._
import com.aciworldwide.ra.redi.utils.spark.writer.jdbc._
import com.typesafe.config.ConfigFactory
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.{DataType, StructType}

object
BiConsumers extends App with Logging {
  try {
    // loading config
    val confNm = System.getProperties.getProperty("app.config.name")
    logInfo(s"loading config : $confNm")
    val apc = ConfigFactory.load(confNm)
    val processTm = apc.getString(STREAMING_TIME)
    val krOps = readWriteOptions(apc.getConfig("kafka.consumer.options"))
    val schemaVals = apc.getStringList("schema.on.write.values")
    val mstSchema = DataType.fromJson(schemaVals.get(0)).asInstanceOf[StructType]
    val dtlSchema = DataType.fromJson(schemaVals.get(1)).asInstanceOf[StructType]
    val rhSchema = DataType.fromJson(schemaVals.get(2)).asInstanceOf[StructType]
    val jdbcConf = loadJdbcConfigFromArgs(args)
    val targetTblNames = jdbcConf.tableName.split(",")

    jdbcConf.tableName = targetTblNames.apply(0)
    val mstSinkWr = new JdbcSink.SteamWriter(JdbcSink.metaDataBuilder(jdbcConf))
    jdbcConf.tableName = targetTblNames.apply(1)
    val dtlSinkWr = new JdbcSink.SteamWriter(JdbcSink.metaDataBuilder(jdbcConf))
    jdbcConf.tableName = targetTblNames.apply(2)
    val rhSinkWr = new JdbcSink.SteamWriter(JdbcSink.metaDataBuilder(jdbcConf))

    val spark = SparkSession
      .builder()
      .getOrCreate()
    spark.conf.set(CHECKPOINT_LOC, apc.getString(CHECKPOINT_LOC))
    // Read from kafka
    val ksDs = dataFrameReader(spark, "kafka", krOps)
      .selectExpr("CAST(value AS STRING)")
    // JDBC writer
    val mstSink = slicer4Obj(ksDs, mstSchema)
      .writeStream
      .foreach(mstSinkWr)
      .trigger(Trigger.ProcessingTime(processTm))
      .start()
    val dtlSink = slicer4ArrayOrMaps(ksDs, dtlSchema)
      .writeStream
      .foreach(dtlSinkWr)
      .trigger(Trigger.ProcessingTime(processTm))
      .start()
    val rhSink = slicer4ArrayOrMaps(ksDs, rhSchema)
      .writeStream
      .foreach(rhSinkWr)
      .trigger(Trigger.ProcessingTime(processTm))
      .start()

    mstSink.awaitTermination()
    dtlSink.awaitTermination()
    rhSink.awaitTermination()

  }
  catch {
    case e: Exception =>
      logError("Unable to initiate JdbcSink", e)
  }
}

package com.aciworldwide.ra.redi.stream.consumer

import com.aciworldwide.ra.redi.stream.consumer.constants.AppConstants._
import com.aciworldwide.ra.redi.utils.ReadWriteUtils._
import com.aciworldwide.ra.redi.utils.SparkUtils._
import com.aciworldwide.ra.redi.utils.ConfUtils.loadJdbcConfigFromArgs
import com.aciworldwide.ra.redi.utils.spark.writer.jdbc._
import com.typesafe.config.ConfigFactory
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.{DataType, StructType}

object
JdbcSinkConsumer extends App with Logging {
 try{
    val confNm = System.getProperties.getProperty("app.config.name")
    logInfo(s"loading config : $confNm")
    val apc = ConfigFactory.load(confNm)
    val processTm = apc.getString(STREAMING_TIME)
    val tblSchema = DataType.fromJson(apc.getString("schema.on.write.value")).asInstanceOf[StructType]
    val krOps = readWriteOptions(apc.getConfig("kafka.consumer.options"))
    val jdbcConf = JdbcSink.metaDataBuilder(loadJdbcConfigFromArgs(args))
    val jdbcSinkWr = new JdbcSink.SteamWriter(jdbcConf)
    val spark = SparkSession
      .builder()
      .getOrCreate()
    spark.conf.set(CHECKPOINT_LOC, apc.getString(CHECKPOINT_LOC))
    val ksDs = dataFrameReader(spark, "kafka", krOps) // <-- Read from kafka
      .selectExpr("CAST(value AS STRING)")
    slicer4ObjOrArray(ksDs, tblSchema) // <-- slice the datasets by given schema
      .writeStream
      .foreach(jdbcSinkWr) // <-- JDBC sink writer
      .trigger(Trigger.ProcessingTime(processTm))
      .start()
      .awaitTermination()
  }
 catch {
   case e: Exception =>
     logError("Unable to initiate JdbcSink", e)
 }


}

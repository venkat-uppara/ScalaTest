
package com.aciworldwide.ra.redi.stream.consumer.constants

/**
 * This specifies the different properties mentiond in configuration files
 * in hdfs , whic is being reused.
 *
 */
object AppConstants {
  //Spark
  final val APP_NAME = "spark.app.name"
  final val STREAMING_TIME = "spark.sql.streaming.duration.seconds"
  final val DF_WR_NOF = "spark.df.wr.no.files"
  final val CHECKPOINT_LOC = "spark.sql.streaming.checkpointLocation"

}
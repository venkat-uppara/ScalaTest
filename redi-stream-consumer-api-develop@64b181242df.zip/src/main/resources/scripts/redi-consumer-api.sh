#!/usr/bin/env bash

#----------------------------------------------------------------------------------------------------
# Name          : redi-consumer-api.sh
#
# Purpose       : Used for starting, restarting, stopping and reading status of a given
#                 service (aka job)
#
# App/Services  : STREAM CONSUMER API Microservice and Services offered are
#                 Consumer(INACTIVE)
#                 BiConsumers(INACTIVE)
#                 bi-consumers(ACTIVE)
#                 bae-consumer(ACTIVE)
#                 bi-consumer-historical(ACTIVE)
#                 bi-yb-consumers(ACTIVE)
#                 bi-hive-consumers(ACTIVE)
#                 bae-hive-consumers(ACTIVE)
#                 bi-trans-master-core-srtl(ACTIVE)
#                 bi-trans-rule-hits-srtl(ACTIVE)
#                 bi-trans-detail-srtl(ACTIVE)
#                 bi-trans-master-core-shtl(ACTIVE)
#                 bi-trans-rule-hits-shtl(ACTIVE)
#                 bi-trans-detail-shtl(ACTIVE)
#
#----------------------------------------------------------------------------------------------------

# Check arguments
if [[ $# != 3 ]]; then
  echo "Usage: $0 <start/stop> <app version> <job name>"
  echo "Example: $0 start 5.2-SNAPSHOT bi-consumers"
  echo "Example: $0 stop 5.2-SNAPSHOT bi-consumers"
  echo "Example: $0 restart 5.2-SNAPSHOT bi-consumers"
  echo "Example: $0 status 5.2-SNAPSHOT bi-consumers"
  exit 1
fi

# App name and location
appJAR=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/redi-consumer-api-$2.jar

CLASSPATH=/apps/ReDi/lib/config-1.3.2.jar,\
/apps/ReDi/ReDi_ext_jars/redi-utils-*.jar,\
/apps/ReDi/ReDi_ext_jars/jcommander-1.78.jar,\
/apps/ReDi/ReDi_ext_jars/postgresql-42.2.14.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-clients-2.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/spark-streaming-kafka-*.jar,\
/apps/ReDi/ReDi_ext_jars/spark-sql-kafka-*.jar,\
/apps/ReDi/ReDi_ext_jars/jackson-core-*.jar,\
/apps/ReDi/ReDi_ext_jars/jackson-databind-*.jar,\
/apps/ReDi/ReDi_ext_jars/jackson-annotations-*.jar,\
/apps/ReDi/ReDi_ext_jars/abris_*.jar,\
/apps/ReDi/ReDi_ext_jars/common-utils-*.jar,\
/apps/ReDi/ReDi_ext_jars/common-metrics-*.jar,\
/apps/ReDi/ReDi_ext_jars/common-config-*.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-client-*.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-*.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-avro-serializer-*.jar,\
/apps/ReDi/ReDi_ext_jars/avro-*.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-streams-avro-serde-*.jar,\
/apps/ReDi/ReDi_ext_jars/spark-avro_*.jar,\
/apps/ReDi/ReDi_ext_jars/encryptor-*.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-common-impl-*.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-spec-*.jar,\
/apps/ReDi/ReDi_ext_jars/core-upf-installer-jaxb-*.jar

## App level config
keyTab=$KEYTAB
principal=$PRINCIPAL
jaasConf=$JAASCONFPATH/$JAASCONFFILE
encryptor=$ENCRYPTORPROPERTIES
certs=$SCHEMAREGPATH/$SCHEMAREGFILE
log4j=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/log4j.properties
kafkaKeytabs=$KEYTABKAFKA

JVM_JAAS=" -Djava.security.auth.login.config="$JAASCONFFILE
JVM_TRUSTSTORE=" -Djavax.net.ssl.trustStore="$SCHEMAREGFILE
extraConf=
ybOptions=

if [[ $SCHEMAREGPATH == "" ]]; then
  certs=
fi

if [[ $JAASCONFPATH == "" ]]; then
  jaasConf=
fi

if [[ $3 == "bi-consumers" ]]; then
  appName="bi-consumers-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-consumers-app.properties
  className=com.aciworldwide.ra.redi.stream.consumer.BiConsumers
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-consumers-app.properties -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  if [[ $METRICS_ENABLED == "Y" ]]; then
    extraConf=" --conf \"spark.driver.extraJavaOptions=-Dapp.config.name=bi-consumers-app.properties -Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9015 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-executor-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
  fi

  driverMemory=$BICONSUMERS_DRIVER_MEMORY
  executorMemory=$BICONSUMERS_EXECUTOR_MEMORY
  numberOfExecutors=$BICONSUMERS_NUM_OF_EXECUTOR
  executorCores=$BICONSUMERS_NUM_OF_CORE
  queueName=$BICONSUMERS_QUEUE_NAME

  sed -i -e 's#BICONSUMERS_CHECKPOINTLOCATION#'$BICONSUMERS_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BICONSUMERS_TOPICS#'$BICONSUMERS_TOPICS'#g' $appConfig
  sed -i -e 's#BICONSUMERS_MSG_TYPE#'$BICONSUMERS_MSG_TYPE'#g' $appConfig
  sed -i -e 's#BICONSUMERS_GROUP_ID#'$BICONSUMERS_GROUP_ID'#g' $appConfig
  sed -i -e 's#BICONSUMERS_HIVE_DBURI#'$BICONSUMERS_HIVE_DBURI'#g' $appConfig
  sed -i -e 's#BICONSUMERS_HIVE_DBNAME#'$BICONSUMERS_HIVE_DBNAME'#g' $appConfig
  sed -i -e 's#BICONSUMERS_HIVE_TYPE#'$BICONSUMERS_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "bae-consumer" ]]; then
  appName="bae-consumer-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bae-consumer-app.properties
  className=com.aciworldwide.ra.redi.stream.consumer.Consumer
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bae-consumer-app.properties -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  if [[ $METRICS_ENABLED == "Y" ]]; then
    extraConf=" --conf \"spark.driver.extraJavaOptions=-Dapp.config.name=bae-consumer-app.properties -Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9015 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-executor-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
  fi

  driverMemory=$BAECONSUMER_DRIVER_MEMORY
  executorMemory=$BAECONSUMER_EXECUTOR_MEMORY
  numberOfExecutors=$BAECONSUMER_NUM_OF_EXECUTOR
  executorCores=$BAECONSUMER_NUM_OF_CORE
  queueName=$BAECONSUMER_QUEUE_NAME

  sed -i -e 's#BAECONSUMER_CHECKPOINTLOCATION#'$BAECONSUMER_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BAECONSUMER_TOPICS#'$BAECONSUMER_TOPICS'#g' $appConfig
  sed -i -e 's#BAECONSUMER_MSG_TYPE#'$BAECONSUMER_MSG_TYPE'#g' $appConfig
  sed -i -e 's#BAECONSUMER_GROUP_ID#'$BAECONSUMER_GROUP_ID'#g' $appConfig
  sed -i -e 's#BAECONSUMER_HIVE_DBURI#'$BAECONSUMER_HIVE_DBURI'#g' $appConfig
  sed -i -e 's#BAECONSUMER_HIVE_DBNAME#'$BAECONSUMER_HIVE_DBNAME'#g' $appConfig
  sed -i -e 's#BAECONSUMER_HIVE_TYPE#'$BAECONSUMER_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "bi-consumer-historical" ]]; then
  appName="bi-consumer-historical-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-consumer-historical-app.properties
  className=com.aciworldwide.ra.redi.stream.consumer.BiConsumers
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-consumer-historical-app.properties -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  if [[ $METRICS_ENABLED == "Y" ]]; then
    extraConf=" --conf \"spark.driver.extraJavaOptions=-Dapp.config.name=bi-consumer-historical-app.properties -Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9015 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-executor-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
  fi

  driverMemory=$BICONSUMERHIST_DRIVER_MEMORY
  executorMemory=$BICONSUMERHIST_EXECUTOR_MEMORY
  numberOfExecutors=$BICONSUMERHIST_NUM_OF_EXECUTOR
  executorCores=$BICONSUMERHIST_NUM_OF_CORE
  queueName=$BICONSUMERHIST_QUEUE_NAME

  sed -i -e 's#BICONSUMERHIST_CHECKPOINTLOCATION#'$BICONSUMERHIST_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BICONSUMERHIST_TOPICS#'$BICONSUMERHIST_TOPICS'#g' $appConfig
  sed -i -e 's#BICONSUMERHIST_MSG_TYPE#'$BICONSUMERHIST_MSG_TYPE'#g' $appConfig
  sed -i -e 's#BICONSUMERHIST_GROUP_ID#'$BICONSUMERHIST_GROUP_ID'#g' $appConfig
  sed -i -e 's#BICONSUMERHIST_HIVE_DBURI#'$BICONSUMERHIST_HIVE_DBURI'#g' $appConfig
  sed -i -e 's#BICONSUMERHIST_HIVE_DBNAME#'$BICONSUMERHIST_HIVE_DBNAME'#g' $appConfig
  sed -i -e 's#BICONSUMERHIST_HIVE_TYPE#'$BICONSUMERHIST_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "bi-yb-consumers" ]]; then
  appName="bi-yb-consumers-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-yb-consumers-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.BiConsumers
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-yb-consumers-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  if [[ $METRICS_ENABLED == "Y" ]]; then
    extraConf=" --conf \"spark.driver.extraJavaOptions=-Dapp.config.name=bi-yb-consumers-app.conf -Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9015 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-executor-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
  fi

  ybOptions="--yb-relay-host $BIYBCONSUMERS_RELAY_HOST --yb-relay-port $BIYBCONSUMERS_RELAY_PORT --yb-host $BIYBCONSUMERS_HOST --yb-port $BIYBCONSUMERS_PORT --yb-user $BIYBCONSUMERS_USER --yb-password $BIYBCONSUMERS_PASS --yb-database $BIYBCONSUMERS_DBNAME "

  driverMemory=$BIYBCONSUMERS_DRIVER_MEMORY
  executorMemory=$BIYBCONSUMERS_EXECUTOR_MEMORY
  numberOfExecutors=$BIYBCONSUMERS_NUM_OF_EXECUTOR
  executorCores=$BIYBCONSUMERS_NUM_OF_CORE
  queueName=$BIYBCONSUMERS_QUEUE_NAME

  sed -i -e 's#BIYBCONSUMERS_CHECKPOINTLOCATION#'$BIYBCONSUMERS_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BIYBCONSUMERS_TOPICS#'$BIYBCONSUMERS_TOPICS'#g' $appConfig
  sed -i -e 's#BIYBCONSUMERS_MSG_TYPE#'$BIYBCONSUMERS_MSG_TYPE'#g' $appConfig
  sed -i -e 's#BIYBCONSUMERS_GROUP_ID#'$BIYBCONSUMERS_GROUP_ID'#g' $appConfig
fi

if [[ $3 == "bi-hive-consumers" ]]; then
  appName="bi-hive-consumers-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-hive-consumers-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.BiConsumers
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-hive-consumers-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  if [[ $METRICS_ENABLED == "Y" ]]; then
    extraConf=" --conf \"spark.driver.extraJavaOptions=-Dapp.config.name=bi-hive-consumers-app.conf -Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9015 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-executor-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
  fi

  driverMemory=$BIHIVECONSUMERS_DRIVER_MEMORY
  executorMemory=$BIHIVECONSUMERS_EXECUTOR_MEMORY
  numberOfExecutors=$BIHIVECONSUMERS_NUM_OF_EXECUTOR
  executorCores=$BIHIVECONSUMERS_NUM_OF_CORE
  queueName=$BIHIVECONSUMERS_QUEUE_NAME

  sed -i -e 's#BIHIVECONSUMERS_CHECKPOINTLOCATION#'$BIHIVECONSUMERS_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BIHIVECONSUMERS_TOPICS#'$BIHIVECONSUMERS_TOPICS'#g' $appConfig
  sed -i -e 's#BIHIVECONSUMERS_MSG_TYPE#'$BIHIVECONSUMERS_MSG_TYPE'#g' $appConfig
  sed -i -e 's#BIHIVECONSUMERS_GROUP_ID#'$BIHIVECONSUMERS_GROUP_ID'#g' $appConfig
  sed -i -e 's#BIHIVECONSUMERS_HIVE_DBURI#'$BIHIVECONSUMERS_HIVE_DBURI'#g' $appConfig
  sed -i -e 's#BIHIVECONSUMERS_HIVE_DBNAME#'$BIHIVECONSUMERS_HIVE_DBNAME'#g' $appConfig
fi

if [[ $3 == "bae-hive-consumers" ]]; then
  appName="bae-hive-consumers-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bae-hive-consumers-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.BiConsumers
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bae-hive-consumers-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  if [[ $METRICS_ENABLED == "Y" ]]; then
    extraConf=" --conf \"spark.driver.extraJavaOptions=-Dapp.config.name=bae-hive-consumers-app.conf -Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9015 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-executor-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
  fi

  driverMemory=$BAEHIVECONSUMERS_DRIVER_MEMORY
  executorMemory=$BAEHIVECONSUMERS_EXECUTOR_MEMORY
  numberOfExecutors=$BAEHIVECONSUMERS_NUM_OF_EXECUTOR
  executorCores=$BAEHIVECONSUMERS_NUM_OF_CORE
  queueName=$BAEHIVECONSUMERS_QUEUE_NAME

  sed -i -e 's#BAEHIVECONSUMERS_CHECKPOINTLOCATION#'$BAEHIVECONSUMERS_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BAEHIVECONSUMERS_TOPICS#'$BAEHIVECONSUMERS_TOPICS'#g' $appConfig
  sed -i -e 's#BAEHIVECONSUMERS_MSG_TYPE#'$BAEHIVECONSUMERS_MSG_TYPE'#g' $appConfig
  sed -i -e 's#BAEHIVECONSUMERS_GROUP_ID#'$BAEHIVECONSUMERS_GROUP_ID'#g' $appConfig
  sed -i -e 's#BAEHIVECONSUMERS_HIVE_DBURI#'$BAEHIVECONSUMERS_HIVE_DBURI'#g' $appConfig
  sed -i -e 's#BAEHIVECONSUMERS_HIVE_DBNAME#'$BAEHIVECONSUMERS_HIVE_DBNAME'#g' $appConfig
fi

if [[ $3 == "bi-trans-master-core-srtl" ]]; then
  appName="bi-trans-master-core-srtl-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-trans-master-core-srtl-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.JdbcSinkConsumer
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-trans-master-core-srtl-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  ybOptions="--url $JDBC_POSTGRES_URL --user $JDBC_POSTGRES_USER --password $JDBC_POSTGRES_PASSWORD --table $BITXNMASCORE_TABLE_NAME --mi-ingest-job-name $appName "

  driverMemory=$BITXNMASCORE_DRIVER_MEMORY
  executorMemory=$BITXNMASCORE_EXECUTOR_MEMORY
  numberOfExecutors=$BITXNMASCORE_NUM_OF_EXECUTOR
  executorCores=$BITXNMASCORE_NUM_OF_CORE
  queueName=$BITXNMASCORE_QUEUE_NAME

  sed -i -e 's#BITXNMASCORE_CHECKPOINTLOCATION#'$BITXNMASCORE_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BITXNMASCORE_TOPICS#'$BITXNMASCORE_TOPICS'#g' $appConfig
fi

if [[ $3 == "bi-trans-rule-hits-srtl" ]]; then
  appName="bi-trans-rule-hits-srtl-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-trans-rule-hits-srtl-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.JdbcSinkConsumer
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-trans-rule-hits-srtl-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  ybOptions="--url $JDBC_POSTGRES_URL --user $JDBC_POSTGRES_USER --password $JDBC_POSTGRES_PASSWORD --table $BITXNRULEHITS_TABLE_NAME --mi-ingest-job-name $appName "

  driverMemory=$BITXNRULEHITS_DRIVER_MEMORY
  executorMemory=$BITXNRULEHITS_EXECUTOR_MEMORY
  numberOfExecutors=$BITXNRULEHITS_NUM_OF_EXECUTOR
  executorCores=$BITXNRULEHITS_NUM_OF_CORE
  queueName=$BITXNRULEHITS_QUEUE_NAME

  sed -i -e 's#BITXNRULEHITS_CHECKPOINTLOCATION#'$BITXNRULEHITS_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BITXNRULEHITS_TOPICS#'$BITXNRULEHITS_TOPICS'#g' $appConfig

fi

if [[ $3 == "bi-trans-detail-srtl" ]]; then
  appName="bi-trans-detail-srtl-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-trans-detail-srtl-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.JdbcSinkConsumer
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-trans-detail-srtl-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  ybOptions="--url $JDBC_POSTGRES_URL --user $JDBC_POSTGRES_USER --password $JDBC_POSTGRES_PASSWORD --table $BITXNDETAIL_TABLE_NAME --mi-ingest-job-name $appName "

  driverMemory=$BITXNDETAIL_DRIVER_MEMORY
  executorMemory=$BITXNDETAIL_EXECUTOR_MEMORY
  numberOfExecutors=$BITXNDETAIL_NUM_OF_EXECUTOR
  executorCores=$BITXNDETAIL_NUM_OF_CORE
  queueName=$BITXNDETAIL_QUEUE_NAME

  sed -i -e 's#BITXNDETAIL_CHECKPOINTLOCATION#'$BITXNDETAIL_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BITXNDETAIL_TOPICS#'$BITXNDETAIL_TOPICS'#g' $appConfig

fi

if [[ $3 == "bi-trans-master-core-shtl" ]]; then
  appName="bi-trans-master-core-shtl-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-trans-master-core-shtl-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.JdbcSinkConsumer
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-trans-master-core-shtl-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  ybOptions="--url $JDBC_POSTGRES_URL --user $JDBC_POSTGRES_USER --password $JDBC_POSTGRES_PASSWORD --table $BITXNMASCOREHIST_TABLE_NAME --mi-ingest-job-name $appName "

  driverMemory=$BITXNMASCOREHIST_DRIVER_MEMORY
  executorMemory=$BITXNMASCOREHIST_EXECUTOR_MEMORY
  numberOfExecutors=$BITXNMASCOREHIST_NUM_OF_EXECUTOR
  executorCores=$BITXNMASCOREHIST_NUM_OF_CORE
  queueName=$BITXNMASCOREHIST_QUEUE_NAME

  sed -i -e 's#BITXNMASCOREHIST_CHECKPOINTLOCATION#'$BITXNMASCOREHIST_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BITXNMASCOREHIST_TOPICS#'$BITXNMASCOREHIST_TOPICS'#g' $appConfig

fi

if [[ $3 == "bi-trans-rule-hits-shtl" ]]; then
  appName="bi-trans-rule-hits-shtl-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-trans-rule-hits-shtl-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.JdbcSinkConsumer
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-trans-rule-hits-shtl-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  ybOptions="--url $JDBC_POSTGRES_URL --user $JDBC_POSTGRES_USER --password $JDBC_POSTGRES_PASSWORD --table $BITXNRULEHITSHIST_TABLE_NAME --mi-ingest-job-name $appName "

  driverMemory=$BITXNRULEHITSHIST_DRIVER_MEMORY
  executorMemory=$BITXNRULEHITSHIST_EXECUTOR_MEMORY
  numberOfExecutors=$BITXNRULEHITSHIST_NUM_OF_EXECUTOR
  executorCores=$BITXNRULEHITSHIST_NUM_OF_CORE
  queueName=$BITXNRULEHITSHIST_QUEUE_NAME

  sed -i -e 's#BITXNRULEHITSHIST_CHECKPOINTLOCATION#'$BITXNRULEHITSHIST_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BITXNRULEHITSHIST_TOPICS#'$BITXNRULEHITSHIST_TOPICS'#g' $appConfig

fi

if [[ $3 == "bi-trans-detail-shtl" ]]; then
  appName="bi-trans-detail-shtl-$2"
  appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-consumer-api/conf/bi-trans-detail-shtl-app.conf
  className=com.aciworldwide.ra.redi.stream.consumer.JdbcSinkConsumer
  extraDriverOptions="spark.driver.extraJavaOptions=-Dapp.config.name=bi-trans-detail-shtl-app.conf -Duser.timezone=UTC"$JVM_JAAS
  extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
  extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC"$JVM_JAAS
  extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE

  ybOptions="--url $JDBC_POSTGRES_URL --user $JDBC_POSTGRES_USER --password $JDBC_POSTGRES_PASSWORD --table $BITXNDETAILHIST_TABLE_NAME --mi-ingest-job-name $appName "

  driverMemory=$BITXNDETAILHIST_DRIVER_MEMORY
  executorMemory=$BITXNDETAILHIST_EXECUTOR_MEMORY
  numberOfExecutors=$BITXNDETAILHIST_NUM_OF_EXECUTOR
  executorCores=$BITXNDETAILHIST_NUM_OF_CORE
  queueName=$BITXNDETAILHIST_QUEUE_NAME

  sed -i -e 's#BITXNDETAILHIST_CHECKPOINTLOCATION#'$BITXNDETAILHIST_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BITXNDETAILHIST_TOPICS#'$BITXNDETAILHIST_TOPICS'#g' $appConfig

fi

if [[ $3 == "Consumer" ]]; then
  appName="redi-k2hive-consumer-baestream-$2"
  appConfig=$APP_HOME/$2/redi-consumer-api/conf/application.properties
  extraConf=" --conf spark.authenticate=true "$extraConf
  className=com.aciworldwide.ra.redi.stream.consumer.$3

  driverMemory=$CONSUMER_DRIVER_MEMORY
  executorMemory=$CONSUMER_EXECUTOR_MEMORY
  numberOfExecutors=$CONSUMER_NUM_OF_EXECUTOR
  executorCores=$CONSUMER_NUM_OF_CORE
  queueName=$CONSUMER_QUEUE_NAME

  sed -i -e 's#CONSUMER_CHECKPOINTLOCATION#'$CONSUMER_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#CONSUMER_TOPICS#'$CONSUMER_TOPICS'#g' $appConfig
  sed -i -e 's#CONSUMER_MSG_TYPE#'$CONSUMER_MSG_TYPE'#g' $appConfig
  sed -i -e 's#CONSUMER_GROUP_ID#'$CONSUMER_GROUP_ID'#g' $appConfig
  sed -i -e 's#CONSUMER_HIVE_DBURI#'$CONSUMER_HIVE_DBURI'#g' $appConfig
  sed -i -e 's#CONSUMER_HIVE_DBNAME#'$CONSUMER_HIVE_DBNAME'#g' $appConfig
  sed -i -e 's#CONSUMER_HIVE_TYPE#'$CONSUMER_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "BiConsumer" ]]; then
  appName="redi-bi-hive-consumer-$2"
  appConfig=$APP_HOME/$2/redi-consumer-api/conf/bi-app.properties
  className=com.aciworldwide.ra.redi.stream.consumer.$3

  driverMemory=$BICONSUMER_DRIVER_MEMORY
  executorMemory=$BICONSUMER_EXECUTOR_MEMORY
  numberOfExecutors=$BICONSUMER_NUM_OF_EXECUTOR
  executorCores=$BICONSUMER_NUM_OF_CORE
  queueName=$BICONSUMER_QUEUE_NAME

  sed -i -e 's#BICONSUMER_CHECKPOINTLOCATION#'$BICONSUMER_CHECKPOINTLOCATION'#g' $appConfig
  sed -i -e 's#BICONSUMER_TOPICS#'$BICONSUMER_TOPICS'#g' $appConfig
  sed -i -e 's#BICONSUMER_MSG_TYPE#'$BICONSUMER_MSG_TYPE'#g' $appConfig
  sed -i -e 's#BICONSUMER_GROUP_ID#'$BICONSUMER_GROUP_ID'#g' $appConfig
  sed -i -e 's#BICONSUMER_HIVE_DBURI#'$BICONSUMER_HIVE_DBURI'#g' $appConfig
  sed -i -e 's#BICONSUMER_HIVE_DBNAME#'$BICONSUMER_HIVE_DBNAME'#g' $appConfig
  sed -i -e 's#BICONSUMER_HIVE_TYPE#'$BICONSUMER_HIVE_TYPE'#g' $appConfig
fi

if [[ $1 == "start" ]] || [[ $1 == "restart" ]]; then
  # Replace parameters from environment
  sed -i -e 's#BOOTSTRAP_SERVERS#'$BOOTSTRAP_SERVERS'#g' $appConfig
  sed -i -e 's#KAFKA_KEYSTORE_PASSWORD#'$KAFKA_KEYSTORE_PASSWORD'#g' $appConfig
  sed -i -e 's#KAFKA_KEYSTORE#'$KAFKA_KEYSTORE'#g' $appConfig
  sed -i -e 's#KAFKA_TRUSTSTORE_PASSWORD#'$KAFKA_TRUSTSTORE_PASSWORD'#g' $appConfig
  sed -i -e 's#KAFKA_TRUSTSTORE#'$KAFKA_TRUSTSTORE'#g' $appConfig
  sed -i -e 's#KAFKA_KEY_PASSWORD#'$KAFKA_KEY_PASSWORD'#g' $appConfig

  # Spark submit
  applicatonID=$(yarn application -appStates RUNNING -list | grep $appName | awk '{print $1}')
  if [ -z "$applicatonID" ]; then
    echo "Initializing..."
    kinit $principal -k -t $keyTab

    echo "Starting application: $appName"
    spark-submit --master yarn \
      --name $appName \
      --driver-memory $driverMemory \
      --executor-memory $executorMemory \
      --num-executors $numberOfExecutors \
      --executor-cores $executorCores \
      --queue $queueName \
      --deploy-mode cluster \
      --keytab $keyTab \
      --principal $principal \
      --conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
      --conf spark.memory.fraction=0.8 \
      --conf spark.scheduler.maxRegisteredResourcesWaitingTime=60s \
      --conf spark.memory.storageFraction=0.5 \
      --conf spark.cleaner.periodicGC.interval=10min \
      --conf spark.streaming.receiver.maxRate="5000" \
      --conf spark.streaming.kafka.maxRatePerPartition="1000" \
      --conf spark.security.credentials.hiveserver2.enabled=false \
      --conf spark.yarn.kerberos.relogin.period=10m \
      --conf spark.yarn.submit.waitAppCompletion=false \
      --conf "$extraDriverOptions" \
      --conf "$extraExecutorOptions" \
      --files "$jaasConf,$certs,$log4j,$encryptor,$kafkaKeytabs" \
      --jars $appConfig,$CLASSPATH \
      --class $className $appJAR \
      $ybOptions
    exit $?
  else
    echo 'Application is already RUNNING and ID='$applicatonID
    exit 0
  fi
fi

if [[ $1 == "stop" ]]; then
  # Yarn kill
  echo "Stopping job: $appName"
  yarn application -appStates RUNNING -list | grep $appName | awk '{print $1}' | while read app; do
    echo "yarn application -kill $app"
    yarn application -kill $app
  done
  exit $?
fi

if [[ $1 == "status" ]]; then
  ## read status:  0 - FINISHED, 1 - RUNNING, 2 - FAILED

  echo "Reading job status: $appName"
  statusValue=0
  applicatonID=$(yarn application -appStates RUNNING -list | grep $appName | awk '{print $1}')
  if [ -n "$applicatonID" ]; then
    echo 'Application is RUNNING and ID='$applicatonID
    statusValue=1
  else
    applicatonID=$(yarn application -appStates FAILED -list | grep $appName | awk '{print $1}')
    if [ -n "$applicatonID" ]; then
      echo 'Application is FAILED and ID='$applicatonID
      statusValue=2
    fi
  fi

  exit $statusValue
fi

# done!

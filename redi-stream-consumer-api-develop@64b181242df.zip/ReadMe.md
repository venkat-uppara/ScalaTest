# Redi-Stream-Consumer API

This stream consumer API is used to consume the message from kafka and write into JDBC/HDFS/HIVE//Kafka. [Supporting Doc]: https://wiki.aciworldwide.com/display/RSE/Redi+Stream+API
 
## Running the project
#### Download source
```
git clone ssh://git@bitbucket.am.tsacorp.com:7999/tim/redi-stream-consumer-api.git
```
#### Build the code and run the tests
```
cd redi-stream-consumer-api
mvn clean install
mvn scala:run -com.aciworldwide.ra.redi.stream.consumer.JdbcSinkConsumer
```

### Deployment
  - Maven 3+
  - JDK 1.8
  - Spark 2.3
  - Kafka 2.11
  - Hive 3.1
  - create tables and map the table name in conf prop files
 
### Support

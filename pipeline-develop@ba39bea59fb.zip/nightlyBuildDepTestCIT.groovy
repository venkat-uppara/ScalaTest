#!groovy
// This is main nightly Jenkins job for running to build, deploy and test of the service(-s)
// creator Evgeny Makhinya 01.2020  evgeny.makhinya@aciworldwide.com
/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2019 by ACI Worldwide Inc.                                  *
 *  All rights reserved.                                                      *
 *                                                                            *
 *  This software is the confidential and proprietary information of ACI      *
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such   *
 *  Confidential Information and shall use it in accordance with the     *
 *  terms of the license agreement you entered with ACI Worldwide Inc.        *
 ******************************************************************************/

pipeline {
    parameters {
        choice(name: 'Environment', choices: 'cit', description: 'Select environment to deploy')
        booleanParam(name: 'Build', defaultValue: true, description: 'If new build is required')
        booleanParam(name: 'CleanUp', defaultValue: true, description: 'If the cleanup required')
        booleanParam(name: 'Deploy', defaultValue: true, description: 'If real deploy is required')
        booleanParam(name: 'ApplyTest', defaultValue: true, description: 'Apply Regression tests')
        booleanParam(name: 'CleanWorkspaces', defaultValue: true, description: 'Clean workspaces after build')
    }
    agent {
        node {
            label 'nrc3lscmbld07vm'
            customWorkspace '/scm/workspace/PRM/Titanium/Nightly/RA_Ansible-CI-Deploy_cit_test'
        }
    }
    options {
        skipDefaultCheckout()
        disableConcurrentBuilds()
        buildDiscarder(logRotator(numToKeepStr: '15'))
    }
    triggers {
        cron('H 19 * * 1-5')  // 5h difference - Midnight by Dublin time(London) for 00.00, time zone - EST

    }
    environment {
        SKIP_TLS = "true"
        jobDir = "${env.WORKSPACE}/${env.JOB_BASE_NAME}"
        emailTo = 'grp-aci-pd-MerchantFraud-CobaltTeam@aciworldwide.com,grp-aci-pd-Merchantfraud-allscrumteams@aciworldwide.com,grp-aci-pd-MerchantFraud-ScrumMasters@aciworldwide.com'
    //    tmpDir = "${jobDir}/tmp"
    //    appWs = "${jobDir}/app-ws"

    //    sandboxGitUrl = 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/sandbox.git'
    //    sandboxGitBranch = 'multibranch/sae_ci_21'

    }
    stages {

        stage('Build latest develop branch for all services') {  
            agent none
            steps {
                script {
                    inventoryName = params.Environment
                    if (params.Build) {
                        def jobBuild = build job: 'PRM/Titanium/Nightly/RA_Legacy_Full_Build/',
                        parameters: [
                            string(name: 'env', value: "${inventoryName}")
                        ],
                        quietPeriod: 1,
                        wait: true,
                        propagate: false
                    }
                }
            }
        }
        stage('CleanUp CIT deployment') {  // RA_Ansible-CI-Deploy in master
            agent none
            steps {
                script {
                    inventoryName = params.Environment
                    if (params.CleanUp) {
                        build job: 'PRM/Titanium/Deployment/RA_Ansible-CI-Deploy/',
                            parameters: [
                                string(name: 'ansibleRepoUrl', value: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/ansible.git'),
                                string(name: 'ansibleBranch', value: 'develop'),
                                string(name: 'playbook', value: 'cleanup'),
                                string(name: 'services', value: 'full'),
                                string(name: 'inventory', value: "${inventoryName}"),
                                booleanParam(name: 'overrideConfig', value: false),
                                booleanParam(name: 'debugMode', value: false)
                            ],
                            quietPeriod: 1,
                            wait: true,
                            propagate: true
                        println ('The cleanup is finished')
                    }
                }
            }
        }

        // Following is introduced due to OpenShift not making the PV underlying a PVC available after the PVC has 
        // been deleted. Corp IT introduced a cron job which runs every 5 minutes to make the PV available again.
        // We must wait for the PV to be available for the deployment below to succeed.      
		stage('Put the pipeline on hold (5 minutes) to wait for OpenShift release for PVC ') {
          	steps {	
          		script {
                  	sleep(time:5,unit:"MINUTES")    // The delay due to the backend cleanup for PVC on Openshift level   
            	}
            }
        }
      
        stage('Install CIT deployment') {  // RA_Ansible-CI-Deploy in master
            agent none
            steps {
                script {
                    inventoryName = params.Environment
                    if (params.Deploy) {
                        build job: 'PRM/Titanium/Deployment/RA_Ansible-CI-Deploy/',
                            parameters: [
                                string(name: 'ansibleRepoUrl', value: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/ansible.git'),
                                string(name: 'ansibleBranch', value: 'develop'),
                                string(name: 'playbook', value: 'install'),
                                string(name: 'services', value: 'full,automatedtests,cli,docker,hazelcast'),
                                string(name: 'inventory', value: "${inventoryName}"),
                                booleanParam(name: 'overrideConfig', value: false),
                                booleanParam(name: 'debugMode', value: false)
                            ],
                            quietPeriod: 1,
                            wait: true,
                            propagate: true
                        println ('The CIT deployment is finished')
                    }
                }
            }
        }

        stage('Run Nightly regression - CLI, RESTSuite, CEP and RE tests') { 
            agent none
            steps {
                script {
                    inventoryName = params.Environment
                    if (params.ApplyTest) {
                        // Only allow this regression to run for 2 hours, and abort if it's still running after this time.
                        // This will cause a build failure if the job has to be aborted. No further stages will be run.
                      try {
                        //timeout(time: 2, unit: 'HOURS') {
                            build job: 'PRM/Titanium/Validation/RA_Regression/',
                                parameters: [
                                    // Parameters for nightly job
                                    string(name: 'environment', value: "${inventoryName}"),
                                    booleanParam(name: 'Cli Tests', value: true),
                                    booleanParam(name: 'Rules Tests', value: false),
                                    booleanParam(name: 'Features Tests', value: false),
                                    booleanParam(name: 'Rules Templates Tests', value: false),
                                    booleanParam(name: 'Rules with Feature Builder Tests', value: false),
                                    booleanParam(name: 'My Rule Changes Tests', value: false),
                                    booleanParam(name: 'RestSuite', value: true),
                                    booleanParam(name: 'Cep Tests', value: true),
                                    booleanParam(name: 'RE Tests', value: true),
                                    booleanParam(name: 'LM CLI Tests', value: false),
                                    booleanParam(name: 'CSI2A Smoke Tests', value: false),
                                    string(name: 'testTimeoutInMinutes', value: "180")
                                ],
                                quietPeriod: 1,
                                wait: true,
                                propagate: true
                        //}
                      } catch (e) {
									sh("echo \"Failure in Nightly regression - CLI, RESTSuite, CEP and RE tests Execution\"")
                                  	currentBuild.result = 'FAILURE'
					  }
                    }
                }
            }
        }
        stage('Run Nightly regression - UI tests') { 
            agent none
            steps {
                script {
                    inventoryName = params.Environment
                    if (params.ApplyTest) {
                        // Only allow this regression to run for 3 hours, and abort if it's still running after this time.
                        // This will cause a build failure if the job has to be aborted. No further stages will be run.
                      try {
                        //timeout(time: 3, unit: 'HOURS') {
                            build job: 'PRM/Titanium/Validation/RA_Regression/',
                                parameters: [
                                    // Parameters for nightly job
                                    string(name: 'environment', value: "${inventoryName}"),
                                    booleanParam(name: 'Cli Tests', value: false),
                                    booleanParam(name: 'Rules Tests', value: false),
                                    booleanParam(name: 'Features Tests', value: false),
                                    booleanParam(name: 'Rules Templates Tests', value: true),
                                    booleanParam(name: 'Rules with Feature Builder Tests', value: true),
                                    booleanParam(name: 'My Rule Changes Tests', value: true),
                                    booleanParam(name: 'RestSuite', value: false),
                                    booleanParam(name: 'Cep Tests', value: false),
                                    booleanParam(name: 'RE Tests', value: false),
                                    booleanParam(name: 'LM CLI Tests', value: false),
                                    //Disabling CSI2A Smoke Tests until the issue with test data file is resolved 
                                  	booleanParam(name: 'CSI2A Smoke Tests', value: false),
                                    string(name: 'testTimeoutInMinutes', value: "180")
                                ],
                                quietPeriod: 1,
                                wait: true,
                                propagate: true
                        //}
                      } catch (e) {
									sh("echo \"Failure in Nightly regression UI tests Execution\"")
                                  	currentBuild.result = 'FAILURE'
					  }
                    }
                }
            }
        }
        stage('Run Nightly regression - ListService tests') { 
            agent none
            steps {
                script {
                    inventoryName = params.Environment
                    if (params.ApplyTest) {
                        // Only allow this regression build to run for 1 hour, and abort if it's still running after this time.
                        // This will cause a build failure if the job has to be aborted. No further stages will be run.
                      try {
                        //timeout(time: 1, unit: 'HOURS') {
                            build job: 'PRM/Titanium/Validation/RA_Regression/',
                                parameters: [
                                    // Parameters for nightly job
                                    string(name: 'environment', value: "${inventoryName}"),
                                    booleanParam(name: 'Cli Tests', value: false),
                                    booleanParam(name: 'Rules Tests', value: false),
                                    booleanParam(name: 'Features Tests', value: false),
                                    booleanParam(name: 'Rules Templates Tests', value: false),
                                    booleanParam(name: 'Rules with Feature Builder Tests', value: false),
                                    booleanParam(name: 'My Rule Changes Tests', value: false),
                                    booleanParam(name: 'RestSuite', value: false),
                                    booleanParam(name: 'Cep Tests', value: false),
                                    booleanParam(name: 'RE Tests', value: false),
                                    booleanParam(name: 'LM CLI Tests', value: true),
                                    booleanParam(name: 'CSI2A Smoke Tests', value: false),
                                    string(name: 'testTimeoutInMinutes', value: "60")
                                ],
                                quietPeriod: 1,
                                wait: true,
                                propagate: true
                        //}
                      } catch (e) {
									sh("echo \"Failure in Nightly regression UI tests Execution\"")
                                  	currentBuild.result = 'FAILURE'
					  }
                    }
                }
            }
        }
    }
    post {
        always {  // will perform always and check if the clean dir is set up, then clean workspace
            dir(jobDir) {
                script {
                    if (params.CleanWorkspaces) {
                        deleteDir()
                    println ('The cleanup of workspace is finished')
                    }
                }
            }
          	emailext (
                    attachLog: true,
                    compressLog: true,
                    to: emailTo,
                    subject: "${currentBuild.currentResult} : ${currentBuild.fullDisplayName}",
                    body: "Build ${currentBuild.fullDisplayName} status: ${currentBuild.currentResult} - ${env.RUN_DISPLAY_URL}"
            	)
        	}	
        /*failure {
            emailext (
                    attachLog: true,
                    compressLog: true,
                    to: emailTo,
                    subject: "${currentBuild.currentResult} : ${currentBuild.fullDisplayName}",
                    body: "Build ${currentBuild.fullDisplayName} status: ${currentBuild.currentResult} - ${env.RUN_DISPLAY_URL}"
            )
        }
        success {  // mail success message take from failure section
            emailext (
                    attachLog: true,
                    compressLog: true,
                    to: emailTo,
                    subject: "${currentBuild.currentResult} : ${currentBuild.fullDisplayName}",
                    body: "Build ${currentBuild.fullDisplayName} status: ${currentBuild.currentResult} - ${env.RUN_DISPLAY_URL}"
            )
        }*/
    }
}

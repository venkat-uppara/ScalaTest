Jenkins Docker for testing

===============================================================================
The Dockerfile can be used to build a container from the latest jenkins/jenkins image and add any other tools you may need.

The start_jenkins.bat file can be used to start the docker container. You should set an environment variable in Windows called TITANIUM which points to a folder, under which is a 'test_pipeline' folder. This is then shared with the container in /var/scm/test_pipeline. Use 'git init' on this folder to simulate a repository to use in Jenkins pipeline jobs.

If you use Docker Desktop natively on Windows, you need to share the drive with it. Right-click on Docker Desktop, select Settings and under Shared Drives, select the drive to share with it.
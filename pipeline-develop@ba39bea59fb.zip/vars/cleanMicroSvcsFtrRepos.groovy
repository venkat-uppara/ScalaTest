#!groovy
/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2019 by ACI Worldwide Inc.                                  *
 *  All rights reserved.                                                      *
 *                                                                            *
 *  This software is the confidential and proprietary information of ACI      *
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such   *
 *  Confidential Information and shall use it in accordance with the 		  *
 *  terms of the license agreement you entered with ACI Worldwide Inc.        *
 ******************************************************************************/
pipeline {
	
	agent {
		node {
			label 'nrc3lscmbld07vm'
			customWorkspace "/scm/Checkout/TIM/${JOB_NAME}"
			}
		}

		triggers {
			cron('H 8 * * *') //every day 8:00 PM EDT, 1:00 AM IST
		}
		
		stages {
			stage('Micro-service Feature Branch Cleanup') {
            agent none
				steps {
					script {
                      
							sh label: '', script: '''#!/usr/bin/ksh
                            #set -x
                            
                            build_pipelines_workspace_root="/scm/Checkout/TIM/PRM/Titanium/Micro-Service_Pipelines/Build-pipelines"
                            
                            # Get current free storage on the /scm mount in GB.
                            space_left_in_gb=$(df -h | grep scm | awk '{print $4}')
                            typeset -i space_left_in_gb=${space_left_in_gb%?}
                            echo "Space left on the /scm mount :${space_left_in_gb}GB"
                            
                            # Get current epoch time.
                            typeset -i current_time=$(date +"%s")
                            
                            echo "Local feature branch repo list:"
                            # for each feature branch found,
                            for branch in $(find $build_pipelines_workspace_root -name ".git" | grep "/feature/" | grep -v "/deployment/");do
                                cd $branch/..
                            	pwd
                                typeset -i last_commit_date=$(date --date="$(git log -1 --format=%cd --date=local)" +"%s")
                                typeset -i time_passed_since_commit=$current_time-$last_commit_date
                                typeset -i days_passed_since_commit=$time_passed_since_commit/86400
                                # if the feature branch has not been commited to in two days or over,
                                if [[ $days_passed_since_commit -gt 1 ]];then
                                    branch_folder_to_delete=$(basename $(pwd))
                                    cd ..
                                    # delete it.
                            		echo "Deleting $branch_folder_to_delete"
                                    rm -rf ${branch_folder_to_delete}*
                                fi
                            done
                            
                            # Get free storage on the /scm mount in GB after the job has run.
                            post_exec_space_left_in_gb=$(df -h | grep scm | awk '{print $4}')
                            typeset -i post_exec_space_left_in_gb=${post_exec_space_left_in_gb%?}
                            typeset -i space_saved=${post_exec_space_left_in_gb}-${space_left_in_gb}
                            echo "Space left on the /scm mount     :${post_exec_space_left_in_gb}GB"
                            echo "Space regained on the /scm mount :${space_saved}GB"
                            
                            exit 0

							'''
					}
				}
			}
		}
    post {
        always {  // will perform always and check if the clean dir is set up, then clean workspace
          	emailext (
                    attachLog: true,
                    compressLog: true,
                    to: "grp-aci-pd-MerchantFraud-CobaltTeam@aciworldwide.com",
                    subject: "${currentBuild.currentResult} : ${currentBuild.fullDisplayName}",
                    body: "Build ${currentBuild.fullDisplayName} status: ${currentBuild.currentResult} - ${env.RUN_DISPLAY_URL}"
            	)
        	}	
    } 
  
}

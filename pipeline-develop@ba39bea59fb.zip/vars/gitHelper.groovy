#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Retrieves path to git executable.
 */
String getGitCmd() {     
     return "${tool GIT_TOOL_NAME}"
}

/**
* Puts a tag to current HEAD
*
* @param tag A tag name.
* @param message A description message
*/
def putTag(tag, message) {
     removeTagIfExists(tag)
     sh "${getGitCmd()} tag -m \"${message}\" ${tag}"     
}

/**
* Commits changes to local branch
*
* @param message A message to annotate changes
*/
def commit(message) {
     sh "${getGitCmd()} commit -avm \"${message}\""
}


/**
* Wrapper for switchLocalBranch() to ignore errors due to merge conflicts/branch unavailablity
*
* @param branch A git branch to switch to
*/
def switchLocalBranchIgnoreErrors(branch) {
     switchLocalBranch(branch, false, true)
}

/**
* Switches local branch
* 
* @param branch A git  branch to switch to
* @param autoCreate If true, creates local branch if not exist
* @param ignoreErrors If true, always returns code 0
*/
def switchLocalBranch(branch, autoCreate = true, ignoreErrors = false) {
     if (autoCreate) {
          sh "${getGitCmd()} fetch --all"
          sh "${getGitCmd()} checkout ${branch} 2>/dev/null || git checkout --track origin/${branch} ${ignoreErrors ? '|| true' : ''}"
     } else {
          sh "${getGitCmd()} checkout ${branch} ${ignoreErrors ? '|| true' : ''}"
     }     
}

/**
* Pulls latest changes from remote upstream branch
*
* @param remote (optional) Remote git repository
* @param local (optional) Local git repository
*/
def pullChanges(remote = null, local = null) {
     sh "${getGitCmd()} pull ${remote ?: ''} ${local ?: ''} --no-edit"
}

/**
* Executes git merge
*
* @param branch A git local branch name to merge with current
*/
def mergeChanges(branch) {
     sh "${getGitCmd()} merge ${branch} --no-edit"
}

/**
* Abort merge procedure and rollback conflicted files to initial state
*
* @param ignoreResult If true, always return code 0
*/
def abortMerge(ignoreResult = true) {
     sh "${getGitCmd()} merge --abort ${ignoreResult ? '|| true' : ''}"
}

/**
* Pushes changes to remote git repository, including tags
*/
def pushChanges() {
  	 sh "${getGitCmd()} pull"
  	 sh "${getGitCmd()} push origin HEAD --tags"
}

/**
 * Set local branch
 *
 * @param local Local branch name
 */
def setBranch(local) {
     sh "${getGitCmd()} checkout ${local}"
     sh "${getGitCmd()} pull"
}

/**
* Sets remote upstream branch to track
*
* @param local Local branch name
* @param remote Remote branch name
*/
def setUpstreamBranch(local, remote = null) {
//     sh "${getGitCmd()} checkout ${local}"
     sh "${getGitCmd()} branch --set-upstream-to=${remote ?: "origin/${local}"} ${local}"
}

/**
* Rollback any commits to local branches
*
* @param local Local branch name
*/
def rollbackLocalBranchChanges(branch) {     
     sh "${getGitCmd()} reset --hard origin/${branch}"
}

/**
* Removes git tag from local and remote repositories
*
* @param tag A git tag to remove
*/
def removeTagIfExists(tag) {
     sh "${getGitCmd()} tag -d ${tag} || true"
     sh "${getGitCmd()} push origin :refs/tags/${tag} || true"
}

/**
 * Retrieves single file from repository.
 *
 * @param repositoryName Name of the repository
 * @param pathToFile Relative path to file we need to retrive
 */
def getFileFromRepository(repositoryName, pathToFile) {
    sh "${getGitCmd()} archive --remote=ssh://git@bitbucket.am.tsacorp.com:7999/blr/${repositoryName}.git HEAD ${pathToFile} | tar -x"
}

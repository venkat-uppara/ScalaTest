#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
* Executes Ansible playbook with inventory and tags provided as arguments
*
* @param inventoryName An inventory name to execute playbooks with
* @param playbook A playbook name (without '.yml' extension) to execute
* @param tags Ansible tags to control playbook execution flow (comma-separated)
*/
def executePlaybook(inventoryName, playbook, tags) {
    withCredentials([file(credentialsId: '046699e8-a16d-4fb3-b6f1-6faf893f50a5', variable: 'ansibleVaultToken')]) {
        ansiblePlaybook colorized: true,
                hostKeyChecking: 'false',
                inventory: "environment/${inventoryName}",
                limit: '',
                playbook: 'playbook/' + playbook + '.yml',
                sudoUser: null,
                tags: "${tags}",
                extras: "--vault-password-file ${ansibleVaultToken}"
    }
}

/**
 * Executes Ansible test playbook with inventory and tags provided as arguments
 *
 * @param inventoryName An inventory name to execute playbooks with
 * @param playbook A playbook name (without '.yml' extension) to execute
 * @param tags Ansible tags to control playbook execution flow (comma-separated)
 * @param testItemName test name
 * @param testItemNameTmstmp timestamp for this test
 */
def executeTestPlaybook(inventoryName, playbook, tags, testItemName, testItemNameTmstmp) {
    withCredentials([file(credentialsId: '046699e8-a16d-4fb3-b6f1-6faf893f50a5', variable: 'ansibleVaultToken')]) {
        ansiblePlaybook colorized: true,
                hostKeyChecking: 'false',
                inventory: "environment/${inventoryName}",
                limit: '',
                playbook: 'playbook/' + playbook + '.yml',
                sudoUser: null,
                tags: "${tags}",
                extras: "-vvv --vault-password-file ${ansibleVaultToken} -e \"testName=${testItemName}\" -e \"testNameTmstmp=${testItemNameTmstmp}\""
    }
}

/**
 * Executes Ansible regression cleanup playbook with inventory and tags provided as arguments
 *
 * @param inventoryName An inventory name to execute playbooks with
 * @param playbook A playbook name (without '.yml' extension) to execute
 * @param tags Ansible tags to control playbook execution flow (comma-separated)
 * @param testItemNameTmstmp timestamp for this test
 */
def executeTestCleanupPlaybook(inventoryName, playbook, tags, testItemNameTmstmp) {
    withCredentials([file(credentialsId: '046699e8-a16d-4fb3-b6f1-6faf893f50a5', variable: 'ansibleVaultToken')]) {
        ansiblePlaybook colorized: true,
                hostKeyChecking: 'false',
                inventory: "environment/${inventoryName}",
                limit: '',
                playbook: 'playbook/' + playbook + '.yml',
                sudoUser: null,
                tags: "${tags}",
                extras: "-vvv --vault-password-file ${ansibleVaultToken} -e \"testNameTmstmp=${testItemNameTmstmp}\""
    }
}

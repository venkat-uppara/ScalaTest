#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Launches Taurus performance test based on provided config files.
 *
 * @param dir Relative path to directory where taurus will be executed
 * @param params parameters that will be passed to taurus
 */
def runTaurusPerfTestAndPublishResult(params, dir) {
    sh "rm -rf $dir/results"
    def paramsConcatStr = params.join(" ")
    dir ("$dir") {
        bzt params: "$paramsConcatStr"
        dslUtils.csv2html "$dir/results"
    }
    archiveArtifacts allowEmptyArchive: true, artifacts: "$dir/results"
    publishHTML target: [
            allowMissing         : true,
            alwaysLinkToLastBuild: true,
            keepAll              : true,
            reportDir            : "$dir/results",
            reportFiles          : "*.html",
            reportName           : "Performance Report"
    ]
}
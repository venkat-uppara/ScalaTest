#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Executes Postman collection with help of Newman client.
 *
 * @param newmanVersion Version of Newman that should be used (it will be installed if missing).
 * @param newmanHtmlReporterVersion Version of Newman HTML Reporter that should be used (it will be installed if missing).
 * @param projectName Name of the project that should be tested.
 * @param environment Environment where Postman collection must be executed.
 * @param addToTrend Flag that specifies if we need to add results to the overall trend or not.
 * @param failureNewThreshold Percent of new tests failed to mark build as failed.
 * @param failureThreshold Percent of all tests failed to mark build as failed.
 * @param unstableNewThreshold Percent of new tests failed to mark build as unstable.
 * @param unstableThreshold Percent of all tests failed to mark build as unstable.
 */
def runPostmanTestAndPublishResult(params) {
    // download custom template
    def customTemplatePath = "qa/postman_custom_template/billers-postman-report-template.hbs"
    gitHelper.getFileFromRepository("tools", "${customTemplatePath}")

    def outputFolder = "newman-output"
    def projectRoot = "../../../"

    def preProcessingScript = "pre_processing.js"
    def collectionFile = "${params.projectName}.postman_collection.json"
    def environmentFile = "${params.projectName}-${params.environment}.postman_environment.json"

    def htmlReportPath = "${outputFolder}/html"
    def junitReportPath = "${outputFolder}/xml"
    def htmlReportFile = "${params.environment}-Newman-Output.html"
    def junitReportFile = "${params.environment}-Newman-Output.xml"

    // run tests
    sh(returnStdout: true, script: """#!/bin/sh
         . /scm/Apps/scripts/EnvScripts/SCM_Env_Setup.sh
         set -e
         npm install -g newman@${params.newmanVersion}
         npm install -g newman-reporter-html@${params.newmanHtmlReporterVersion}

         cd src/test/postman

         # run pre-processing script if exists, e.g. content-delivery-service pre-processing
         if [ -f "${preProcessingScript}" ]
         then
             node ${preProcessingScript}
         fi

         newman run ${collectionFile} --environment ${environmentFile} --insecure --suppress-exit-code --reporters html,junit \
            --reporter-html-export ${projectRoot}/${htmlReportPath}/${htmlReportFile} --reporter-html-template ${projectRoot}/${customTemplatePath} \
            --reporter-junit-export ${projectRoot}/${junitReportPath}/${junitReportFile}

         cd -
         """).trim()

    // remove custom template
    sh "rm ${customTemplatePath}"

    // publish reports
    publishHTML target: [
            allowMissing         : false,
            alwaysLinkToLastBuild: true,
            keepAll              : true,
            reportDir            : "${htmlReportPath}/",
            reportFiles          : "${htmlReportFile}",
            reportName           : "${params.environment} Newman Report"
    ]

    // add to overall project trend if requested
    if (params.addToTrend) {
        xunit testTimeMargin: "3000", thresholdMode: 2, thresholds: [failed(
                failureNewThreshold: "${params.failureNewThreshold}",
                failureThreshold: "${params.failureThreshold}",
                unstableNewThreshold: "${params.unstableNewThreshold}",
                unstableThreshold: "${params.unstableThreshold}"
        )],
        tools: [JUnit(
                deleteOutputFiles: true,
                failIfNotNew: true,
                pattern: "${junitReportPath}/${junitReportFile}",
                skipNoTestFiles: false,
                stopProcessingIfError: false)]
    }
}
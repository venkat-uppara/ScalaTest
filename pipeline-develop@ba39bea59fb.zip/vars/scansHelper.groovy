#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Executes CheckMarx scan.
 *
 * @param checkmarxProjectName Name of the project that will be showed in CheckMarx.
 * @param checkmarxUrl Url of the CheckMarx server.
 * @param checkmarxExclusion Directories that should be excluded from the scan.
 *
 */
def runCheckMarxScan(params) {
    step([$class       : 'CxScanBuilder', comment: '', excludeFolders: "${params.checkmarxExclusion}", excludeOpenSourceFolders: '', exclusionsSetting: 'job',
          filterPattern: '''!**/_cvs/**/*, !**/.svn/**/*,   !**/.hg/**/*,   !**/.git/**/*,  !**/.bzr/**/*, !**/bin/**/*,
                    !**/obj/**/*,  !**/backup/**/*, !**/.idea/**/*, !**/*.DS_Store, !**/*.ipr,     !**/*.iws,
                    !**/*.bak,     !**/*.tmp,       !**/*.aac,      !**/*.aif,      !**/*.iff,     !**/*.m3u, !**/*.mid, !**/*.mp3,
                    !**/*.mpa,     !**/*.ra,        !**/*.wav,      !**/*.wma,      !**/*.3g2,     !**/*.3gp, !**/*.asf, !**/*.asx,
                    !**/*.avi,     !**/*.flv,       !**/*.mov,      !**/*.mp4,      !**/*.mpg,     !**/*.rm,  !**/*.swf, !**/*.vob,
                    !**/*.wmv,     !**/*.bmp,       !**/*.gif,      !**/*.jpg,      !**/*.png,     !**/*.psd, !**/*.tif, !**/*.swf,
                    !**/*.jar,     !**/*.zip,       !**/*.rar,      !**/*.exe,      !**/*.dll,     !**/*.pdb, !**/*.7z,  !**/*.gz,
                    !**/*.tar.gz,  !**/*.tar,       !**/*.gz,       !**/*.ahtm,     !**/*.ahtml,   !**/*.fhtml, !**/*.hdm,
                    !**/*.hdml,    !**/*.hsql,      !**/*.ht,       !**/*.hta,      !**/*.htc,     !**/*.htd, !**/*.war, !**/*.ear,
                    !**/*.htmls,   !**/*.ihtml,     !**/*.mht,      !**/*.mhtm,     !**/*.mhtml,   !**/*.ssi, !**/*.stm, !**/*.gradle,
                    !**/*.stml,    !**/*.ttml,      !**/*.txn,      !**/*.xhtm,     !**/*.xhtml,   !**/*.class, !**/*.iml, !Checkmarx/Reports/*.*,
                    !**/ansible/**/*, !**/docker/**/*, !**/deployment/**/*, !**/tmp/**/*''',
          fullScanCycle: 10, groupId: '084cd925-8dfe-4468-839f-7b3bba0627cb', includeOpenSourceFolders: '',
          password     : '{AQAAABAAAAAQ0bY2DXmtYHf9tCWeMiYTz7us1miyMcs2Lx6nJE9C5/k=}', preset: '100002', projectName: "${params.checkmarxProjectName}",
          serverUrl    : "${params.checkmarxUrl}", sourceEncoding: '5', username: 'am\\svc_scm1', vulnerabilityThresholdResult: 'FAILURE'])
}

/**
 * Executes BlackDuck scan in AirGap mode which support Docker, Gradle and NuGet
 *
 * @param blackduckAirGapVersion Version of BlackDuck AirGap.
 * @param blackduckHubUrl Url of the BlackDuck Hub.
 * @param gradleCmd Path to the gradle executable file.
 * @param blackduckProjectName Name of the project that will be showed in BlackDuck Hub.
 * @param blackduckProjectVersion Version of the project that will be showed in BlackDuck Hub.
 * @param projectName Name of the project that must be analyzed.
 * @param blackduckGradleExclusions List of gradle tasks exclusions for BlackDuck analyzer.
 */
def runBlackDuckScanAirGapMode(params) {
    withCredentials([usernamePassword(credentialsId: 'SCMServiceAccount', usernameVariable: 'HUBUSER', passwordVariable: 'HUBPASSWORD')]) {
        def blackduckAirGapPath = "/scm/Apps/HubDetect-AirGap/${params.blackduckAirGapVersion}"
        sh "java -jar ${blackduckAirGapPath}/hub-detect-${params.blackduckAirGapVersion}.jar --detect.gradle.inspector.air.gap.path=${blackduckAirGapPath}/packaged-inspectors/gradle --blackduck.hub.url=${params.blackduckHubUrl} " +
                "--detect.gradle.path=${params.gradleCmd} --detect.force.success=true --blackduck.hub.username='$HUBUSER' --blackduck.hub.password='$HUBPASSWORD' --detect.fail.config.warning --detect.project.name=${params.blackduckProjectName} " +
                "--detect.project.version.name=${params.blackduckProjectVersion} --blackduck.hub.trust.cert=true --detect.hub.signature.scanner.snippet.mode=true --detect.code.location.name=${params.projectName} --logging.level.com.blackducksoftware.integration=WARN " +
                "--detect.hub.signature.scanner.exclusion.patterns=/plugins/,/build/,/gradle/,/src/test/ --detect.output.path=${blackduckAirGapPath}/results/${params.projectName} " +
                "--detect.gradle.excluded.configurations=${params.blackduckGradleExclusions}"
    }
}

/**
* Creates list of exclusion patterns based on comma-separated values provided as string
*
* @param excludeDirectories A comma separated list of exclusion directories
*/
def getExcludePatterns(excludeDirectories) {
    def excludePatterns = [] as ArrayList    
    if (excludeDirectories?.trim()) {
        def excludePatternsArray = excludeDirectories.split(',')
        for (int i = 0; i < excludePatternsArray.size(); i++) {
            def exclusionPatternList = [ exclusionPattern: excludePatternsArray[i] ]
            excludePatterns << exclusionPatternList
        }
    } else {
        def exclusionPattern = [ exclusionPattern: '' ]
        excludePatterns << exclusionPattern
    }
    return excludePatterns
}

/**
* Executes BlackDuck scan in online mode
* @param projectName Name of the project that must be analyzed.
* @param projectVersion Version of the project that will be showed in BlackDuck Hub.
* @param scanDir location of the directory to be scanned.
* @param repoId nexus repository id to pull dependencies from.
*/
def runBlackDuckScan(params) {
  try { 
  //Timeout wrapper for 30 mins
  		timeout(30) {
   			synopsys_detect """--blackduck.url=https://nrc3lbdhubvm.am.tsacorp.com
  					 --detect.maven.path="/scm/Apps/Maven/3.3.9/bin/mvnSynopsys"
					 --detect.force.success=true 
					 --detect.project.name="${params.projectName}"
					 --detect.project.version.name="${params.projectVersion}"
					 --blackduck.trust.cert=true 
					 --detect.blackduck.signature.scanner.snippet.matching=SNIPPET_MATCHING
                     --detect.blackduck.signature.scanner.exclusion.patterns="${params.exclusions}"
					 --logging.level.com.synopsys.integration=INFO 
					 --blackduck.offline.mode=false   
					 --detect.output.path="${params.scanDir}"
                     --detect.maven.build.command="-Drepo.id=${params.repoId}"
                     --blackduck.api.token=ZDA5NDcxOTAtNWQ2Ny00OWMzLWE2MWUtNGU5NTQ1OGU3ZGEzOjJjMTgzNTJmLTQ3YzUtNDE4Ny04ZjAzLTE4MGI3MzgzODhkZA==
                     
					"""
  		}
	 }	catch (err) {
                echo "Error in Blackduck Scan"
    }
}

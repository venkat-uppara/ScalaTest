#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

 /* Retrieves the artifact version from pom.xml
  *
  * @param filePath - path to the pom.xml file to read
  * @return the version as a string
  */
String readVersion(filePath) {
    return sh(returnStdout: true, script:
        """#!/bin/bash
        xmllint --xpath '//*[local-name()=\"project\"]/*[local-name()=\"version\"]/text()' \"${filePath}\"
        """).trim()
}

/* Retrieves the artifactId from pom.xml
 *
 * @param filePath - path to the pom.xml file to read
 * @return the artifactId as a string
 */
String readArtifactId(filePath) {
    return sh(returnStdout: true, script:
        """#!/bin/bash
        xmllint --xpath '//*[local-name()=\"project\"]/*[local-name()=\"artifactId\"]/text()' \"${filePath}\"
        """).trim()
}

/* Retrieves the name from pom.xml
 *
 * @param filePath - path to the pom.xml file to read
 * @return the name as a string
 */
String readName(filePath) {
    return sh(returnStdout: true, script:
        """#!/bin/bash
        xmllint --xpath '//*[local-name()=\"project\"]/*[local-name()=\"name\"]/text()' \"${filePath}\"
        """).trim()
}
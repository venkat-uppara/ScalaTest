#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

import java.util.regex.*

/**
 * Main pipeline declaration for all Titanium services.
 */
def call(body) {

    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    pipeline {
        agent none
        environment {
            // Build time variables            
          	//WORKSPACE = "${ URLDecoder.decode("${env.WORK_DIR}") ?: URLDecoder.decode("/scm/Checkout/TIM/${JOB_NAME}")}"
          	WORKSPACE = "/scm/Checkout/TIM/${JOB_NAME}"
            NODE = "nrc3lscmbld07vm"        
            
            DEVELOP_DOCKER_REGISTRY = "${pipelineParams.DEVELOP_DOCKER_REGISTRY ?: 'nrc3ldockreg01vm.am.tsacorp.com:18079/risk-app'}"   // mapped to docker-ra by default
            RELEASE_DOCKER_REGISTRY = "${pipelineParams.RELEASE_DOCKER_REGISTRY ?: 'nrc3ldockreg01vm.am.tsacorp.com:18090/risk-app'}"   // mapped to docker-rc by default

            RELEASE_DOCKER_TAG = "${pipelineParams.RELEASE_DOCKER_TAG ?: 'latest'}"

            MAVEN_TOOL_NAME = "${pipelineParams.MAVEN_TOOL_NAME ?: 'MAVEN_3.3.9_LINUX'}"
            JAVA_TOOL_NAME = "${pipelineParams.JAVA_TOOL_NAME ?: 'JDK_1.8.0_144_LINUX'}"
            GIT_TOOL_NAME = "${pipelineParams.GIT_TOOL_NAME ?: 'GIT_2.14.2_LINUX'}"            
        }
        tools {
            maven "${MAVEN_TOOL_NAME}"
            jdk "${JAVA_TOOL_NAME}"
        }
        options {
            buildDiscarder(logRotator(numToKeepStr: '5', artifactNumToKeepStr: '1'))
            skipDefaultCheckout()
            disableConcurrentBuilds()
        }
        stages {
            stage('Pull code from Git') {
              /*when {
                    allOf {
                       triggeredBy "UserIdCause"
                    }
                }*/
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }                
                steps {
                    script {  
                      	// first call to extract git url and branch info for current job run                  
                        def scmVars = checkout scm                        
                        env.GIT_URL = "${scmVars.GIT_URL}"
                        env.GIT_BRANCH = "${scmVars.GIT_BRANCH}"

                        // second call for attached HEAD checkout
                        scmVars = checkout scm: [
                            $class           : "GitSCM",
                            gitTool          : "${GIT_TOOL_NAME}",
                            branches         : [[name: "${GIT_BRANCH}"]],
                            userRemoteConfigs: [[url: "${GIT_URL}"]],
                            extensions       : [
                                [$class: 'LocalBranch', localBranch: "**"],
                                [$class: 'CleanBeforeCheckout']
                            ]
                        ]
						sleep 2
                        // extract local branch name
                        env.GIT_LOCAL_BRANCH = "${scmVars.GIT_LOCAL_BRANCH}"

                        // set upstream branch to support 'git pull' operations
                        gitHelper.setUpstreamBranch("${GIT_LOCAL_BRANCH}")

                        env.PROJECT_NAME = pomUtils.readName("${WORKSPACE}/pom.xml")    
                        env.DOCKER_IMAGE_NAME = pomUtils.readArtifactId("${WORKSPACE}/docker/pom.xml")
                        env.PROJECT_VERSION = pomUtils.readVersion("${WORKSPACE}/pom.xml")                       
                    }
                    dir("${env.TEMPDIR}") {   // creating tmp directory for docker spotify
                        writeFile file:'dummy', text:''
                    }
                }
            }

            stage('Tag git with release version') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                steps {
                    script {
                      	println "${env.PROJECT_VERSION}"
                      	println "${PROJECT_VERSION}"
                      	gitHelper.putTag("${PROJECT_VERSION}", "[${PROJECT_NAME}] Release version ${PROJECT_VERSION}")
                        gitHelper.pushChanges()       
                    }
                }
            }

            stage('Assign tag :latest to RC image') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                steps {
                    script {
                        // pull image to local repository
                      	dockerHelper.pullImage()

                        // tag and push image as :latest to development repository
                        dockerHelper.tagImage(DEVELOP_DOCKER_REGISTRY, RELEASE_DOCKER_TAG)
                        dockerHelper.pushImage(DEVELOP_DOCKER_REGISTRY, RELEASE_DOCKER_TAG)
                    }
                }
            }

            stage('Push image to RC') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                steps {
                    script {  
                      	// execute pull to verify that image still available in local repostory
                        dockerHelper.pullImage()

                        // tag as project version (for example 2.2.1) and 'latest'
                        dockerHelper.tagImage(RELEASE_DOCKER_REGISTRY, PROJECT_VERSION)
                        dockerHelper.tagImage(RELEASE_DOCKER_REGISTRY, RELEASE_DOCKER_TAG)

                        // push both version tags
                        dockerHelper.pushImage(RELEASE_DOCKER_REGISTRY, PROJECT_VERSION)
                        dockerHelper.pushImage(RELEASE_DOCKER_REGISTRY, RELEASE_DOCKER_TAG)
                        
                        // push dbp.zip to raw-rc
                        publishHelper.pushNonDockerArtifacts()                    }
                }
            }            

        }       

        post {
            failure {
                node("${NODE}") {
                    ws("${WORKSPACE}") {
                        script {
                            gitHelper.removeTagIfExists("${PROJECT_VERSION}")                                                             
                        }
                    }
                }
            } 
            always {
                node("${NODE}") {
                    script {
                        // cleanup local docker registry from produced image as well as remove unused dangling images
                        echo "Cleaning up local docker storage"
                        dslUtils.clearBuiltDockerImage("${DOCKER_IMAGE_NAME}:${PROJECT_VERSION}")
                        dslUtils.clearBuiltDockerImage("${DOCKER_IMAGE_NAME}:${RELEASE_DOCKER_TAG}")
                        dslUtils.clearUnusedDockerImages()
                    }
                }                
            }
        }
    }
}

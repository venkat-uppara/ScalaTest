#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
* Pulls docker image associated with current service
*/
def pullImage() {        
    sh "docker pull ${DEVELOP_DOCKER_REGISTRY}/${DOCKER_IMAGE_NAME}:${PROJECT_VERSION}"
}

def tagImage(registry, tag) {
    sh "docker tag ${DEVELOP_DOCKER_REGISTRY}/${DOCKER_IMAGE_NAME}:${PROJECT_VERSION} " + 
        "${registry}/${DOCKER_IMAGE_NAME}:${tag}"
}

def tagImageSnapshot(registry, tag) {
    sh "docker tag ${DEVELOP_DOCKER_REGISTRY}/${DOCKER_IMAGE_NAME}:${PROJECT_VERSION}-SNAPSHOT " + 
        "${registry}/${DOCKER_IMAGE_NAME}:${tag}"
}

def pushImage(registry, tag) {            
    sh "docker push ${registry}/${DOCKER_IMAGE_NAME}:${tag}"
}

#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
* Starts downstream regression test job and waits for results
*
* @param jobPath An absolete or relative path to regression jenkins job
* @param suiteName A test suite identifier to run (refer to regression job parameters)
* @param targetEnvironment An environment parameter (refer to regression job parameters)
* @param stopOnErrors If true, regression job fail will interrupt whole pipeline
*/
def runRegressionJob(params) {
    def jobParameters = [string(name: 'environment', value: "${params.targetEnvironment}")]
    def selectedTests = params.suites?.trim() ? params.suites.tokenize(",").collect { it.trim() } : []
    jobParameters = addTestRunParameters(jobParameters, selectedTests)
    
    build job: "${params.jobPath}",        // TODO: set proper parameters for this job once MERF-16850 completed
            parameters: jobParameters,
            propagate: "${params.stopOnErrors}",                    // propogate errors from downstream job in case of failed tests
            quietPeriod: 1,
            wait: true
}

/**
* Adds boolean parameters for each test suite in 'selectedTests' list
*
* @param parameters Initial list of parameters
* @param selectedTests List of test sute names. Values must match parameter names in regression test job.
*/
def addTestRunParameters(parameters, selectedTests) {
    if (!parameters || !selectedTests) {
        return parameters
    }

    selectedTests.each {        
        parameters << booleanParam(name: "${it}", value: true) 
    }
    return parameters
}
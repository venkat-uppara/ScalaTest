#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

import java.util.regex.*

/**
 * Main pipeline declaration for all Titanium services.
 */
def call(body) {

    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    pipeline {
        agent none
        environment {
            // Build time variables            
            WORKSPACE = "/scm/Checkout/TIM/${JOB_NAME}".replaceAll(/%2F/, "/").replaceAll(/%2f/, "/")
            NODE = "nrc3lscmbld07vm"        
            
            // Paremeters for the builing shared Java libs

            // Checkmarx parameters
            CHECKMARX_PROJECT_NAME = "${pipelineParams.CHECKMARX_PROJECT_NAME ?: ''}"
            CHECKMARX_SERVER_URL = "${pipelineParams.CHECKMARX_SERVER_URL ?: 'https://nrc2cxmgr01.am.tsacorp.com'}"
            CHECKMARX_EXCLUSIONS = "${pipelineParams.CHECKMARX_EXCLUSIONS ?: 'test, build, assembly'}"

            // BlackDuck parameters
            BLACKDUCK_PROJECT_NAME = "${pipelineParams.BLACKDUCK_PROJECT_NAME ?: ''}"
            BLACKDUCK_EXCLUSIONS = "${pipelineParams.BLACKDUCK_EXCLUSIONS ?: '/src/test/,/deployment/,/Checkmarx/,/tmp/'}"          

            NEXUS_DOCKER_REGISTRY = "${pipelineParams.NEXUS_DOCKER_REGISTRY ?: 'nrc3ldockreg01vm.am.tsacorp.com:18079/risk-app'}"
            NEXUS_SERVER_URL = "${pipelineParams.NEXUS_SERVER_URL ?: 'https://nrc3ldockreg01vm.am.tsacorp.com'}"
            NEXUS_ARTIFACTS_GROUP = "${pipelineParams.NEXUS_ARTIFACTS_GROUP ?: 'com/aciworldwide/ra'}"

            //Release pipeline parameters
            RELEASE_PIPELINE_JOB_PATH = 'PRM/Titanium/RA_pipelines/develop/RA_Release_Test_MB_Pipeline'

            MAVEN_TOOL_NAME = "${pipelineParams.MAVEN_TOOL_NAME ?: 'MAVEN_3.3.9_LINUX'}"
            JAVA_TOOL_NAME = "${pipelineParams.JAVA_TOOL_NAME ?: 'JDK_1.8.0_144_LINUX'}"
            GIT_TOOL_NAME = "${pipelineParams.GIT_TOOL_NAME ?: 'GIT_2.14.2_LINUX'}"            

            GIT_RELEASE_TAG_PREFIX = "${pipelineParams.GIT_RELEASE_TAG_PREFIX ?: ''}"  
            GIT_DEVELOP_TAG_PREFIX = "${pipelineParams.GIT_DEVELOP_TAG_PREFIX ?: ''}"  
            
            PIPELINE_DISPLAY_NAME = "${pipelineParams.PIPELINE_DISPLAY_NAME ?: 'RA Pipeline'}"              // used to annotate git commit messages and tags
            PIPELINE_SUPPORT_EMAIL = "${pipelineParams.PIPELINE_SUPPORT_EMAIL ?: ''}"                       // comma-separated list of engineers who support this pipeline            

            GIT_DEVELOP_BRANCH = "${pipelineParams.GIT_DEVELOP_BRANCH ?: 'develop'}"
            GIT_MASTER_BRANCH = "${pipelineParams.GIT_MASTER_BRANCH ?: 'master'}"

            NON_DOCKER_ARTIFACT_PREFIX = "${pipelineParams.NON_DOCKER_ARTIFACT_PREFIX ?: ''}"

            PROMOTE_BUILD = "Promote"
        }
        tools {
            maven "${MAVEN_TOOL_NAME}"
            jdk "${JAVA_TOOL_NAME}"
        }
        options {
            buildDiscarder(logRotator(numToKeepStr: '5', artifactNumToKeepStr: '1'))
            skipDefaultCheckout()
            disableConcurrentBuilds()
        }

        stages {
            stage('Promote or build only for master') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                when {
                    branch "${GIT_MASTER_BRANCH}"
                }
                steps {
                    script {                          
                        def chosenParameters = stageChoosePromoteOrBuild()

                        if (!chosenParameters) {
                            currentBuild.result = 'ABORTED'
                            error 'Job cancelled by user or timeout'
                        }

                        if (chosenParameters.option =~ /Build/) {
                            // Build only
                            PROMOTE_BUILD = "Build"
                        }

                        if(PROMOTE_BUILD =~ /Promote/) {
                            echo "Build will be promoted from develop"
                        } else {
                            echo "Build only current master"
                        }
                    }
                }
            }
            stage('Pull code from Git') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                
                steps {
                    script {                    
                        // first call to extract git url and branch info for current job run
                        def scmVars = checkout scm                        
                        env.GIT_URL = "${scmVars.GIT_URL}"
                        env.GIT_BRANCH = "${scmVars.GIT_BRANCH}"
                        env.GIT_COMMIT = "${scmVars.GIT_COMMIT}"

                        gitHelper.setBranch("${GIT_BRANCH}")

                        env.WORK_DIR = "${WORKSPACE}/${pipelineParams.WORKING_DIR ?: ''}"
                        echo "Working directory is ${env.WORK_DIR}"
                        
                        env.PROJECT_NAME = pomUtils.readName("${env.WORK_DIR}/pom.xml")
                        env.PROJECT_VERSION = pomUtils.readVersion("${env.WORK_DIR}/pom.xml").replace("-SNAPSHOT", "")

                        // this block is required for merge process and 
                        if ((dslUtils.isUserInitiatedPipeline()) && 
                            ("${GIT_BRANCH}" == "${GIT_MASTER_BRANCH}") &&
                            (PROMOTE_BUILD =~ /Promote/)) {
                            // switch to /develop
                            gitHelper.switchLocalBranch("${GIT_DEVELOP_BRANCH}")                        
                            gitHelper.rollbackLocalBranchChanges("${GIT_DEVELOP_BRANCH}")                        
                            gitHelper.pullChanges()                     

                            env.PREVIOUS_PROJECT_VERSION = pomUtils.readVersion("${env.WORK_DIR}/pom.xml").replace("-SNAPSHOT", "")

                            // master version will be upgraded to current develop version, so override project version with previous from development
                            env.PROJECT_VERSION = "${PREVIOUS_PROJECT_VERSION}"
                        }                                                          

                        env.REPO_ID = "ra"
                        env.MAVEN_LOCAL_REPO = "/scm/maven-repos/ra21"
                        env.TEMPDIR = "${WORKSPACE}/tmp"
                        env.MAVEN_TEST_SKIP = "${pipelineParams.MAVEN_TEST_SKIP ?: 'false'}"

                        if ("${BRANCH_NAME}" == "${GIT_MASTER_BRANCH}") {
                            env.IMAGE_VERSION = "${PROJECT_VERSION}"
                        } else if ("${BRANCH_NAME}" =~ /feature/) {
                            env.IMAGE_VERSION = "${PROJECT_VERSION}-FEATURE"
                        } else {
                            env.IMAGE_VERSION = "${PROJECT_VERSION}-SNAPSHOT"
                        }
                        
                        env.BUILD_VERSION = "${IMAGE_VERSION}-${BUILD_NUMBER}"

                        echo "Building ${PROJECT_NAME}, version ${PROJECT_VERSION}, from branch ${BRANCH_NAME}"
                        echo "Building in ${env.WORK_DIR}"

                        env.MAVEN_CMD = "${tool 'MAVEN_3.3.9_LINUX'}/bin/mvn"
                        env.ENVS_WITH_DEPLOYMENT_COMPLETED = ""
                        env.CHECKMARX_PROJECT_NUMBER = "${pipelineParams.CHECKMARX_PROJECT_NUMBER}"
                        currentBuild.displayName = "${PROJECT_VERSION}-${BUILD_NUMBER}"
                        stagesToRun = [:]
                    }
                    dir("${env.TEMPDIR}") {   // creating tmp directory for docker spotify
                        writeFile file:'dummy', text:''
                    }
                }
            }

            stage('Dialog: Choose version') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }        
                when {
                    allOf {
                        branch "${GIT_MASTER_BRANCH}"
                        triggeredBy "UserIdCause"
                        expression {
                            return (PROMOTE_BUILD =~ /Promote/)
                        }
                    }                    
                }        
                steps {
                    script {                          
                        def chosenParameters = stageChooseNextVersion("${PREVIOUS_PROJECT_VERSION}")

                        if (!chosenParameters) {
                            currentBuild.result = 'ABORTED'
                            error 'Job cancelled by user or timeout'
                        }

                        env.NEXT_PROJECT_VERSION = chosenParameters.version
                        env.SUBMITTER_EMAIL = chosenParameters.submitter
                    }
                }
            }    

            stage('Dialog: Chose stages for run') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                when {
                    allOf {
                        branch "feature/*"
                        triggeredBy "UserIdCause"
                    }
                }
                steps {
                    script {
                        stagesToRun = choseStagesForRun()

                        if (!stagesToRun) {
                            currentBuild.result = 'ABORTED'
                            error 'Job cancelled by user or timeout'
                        }
                    }
                }
            }

            stage('Prepare develop for merge') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }  
                when {
                    allOf {
                        branch "${GIT_MASTER_BRANCH}"
                        triggeredBy "UserIdCause"
                        expression {
                            return (PROMOTE_BUILD =~ /Promote/)
                        }
                    }                    
                }      
                steps {
                    script {                        
                        // remove snapshot from version and prepare to merge to master
                        dir ("${env.WORK_DIR}") {
                            mavenTasks.changeProjectVersion("${PREVIOUS_PROJECT_VERSION}")
                        }

                        gitHelper.commit("[${PIPELINE_DISPLAY_NAME}] Release version was upgraded to: ${PREVIOUS_PROJECT_VERSION}")
                    }
                }
            }                    

            stage('Merge changes to master') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                when {
                    allOf {
                        branch "${GIT_MASTER_BRANCH}"
                        triggeredBy "UserIdCause"
                        expression {
                            return (PROMOTE_BUILD =~ /Promote/)
                        }
                    }                    
                }      
                steps {                    
                    script {
                        gitHelper.switchLocalBranch("${GIT_MASTER_BRANCH}")

                        // perform branch rollback in case of any remaining changes from the previous job
                        gitHelper.rollbackLocalBranchChanges("${GIT_MASTER_BRANCH}")

                        // update master with latest changes
                        gitHelper.pullChanges()

                        // merge develop to master
                        gitHelper.mergeChanges("${GIT_DEVELOP_BRANCH}")    
                    }
                }   
                post {
                    failure {
                        script {
                            mailHelper.setExtendedStatus("Unable to merge changes to master")
                        }
                    }
                } 
            }
            
            stage('Build project') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }                
                steps {
                    dir ("${env.WORK_DIR}") {
                        script {
                            mavenTasks.buildInstall() // No deploy is happening here, only local install
                        }
                    }
                }
            }
            stage('Run multiple scans') {
                parallel {
                    stage('SonarQube scan') {
                        agent {
                            node {
                                label "${NODE}"
                                customWorkspace "${WORKSPACE}"
                            }
                        }
                        when {
                            anyOf {
                                branch "${GIT_DEVELOP_BRANCH}"
                                branch "${GIT_MASTER_BRANCH}"
                                expression {
                                    ("${BRANCH_NAME}" =~ /feature/) && (stagesToRun.size() != 0) && (stagesToRun.RunSonarQubeScan)
                                }
                            }
                        }
                        steps {
                            dir ("${env.WORK_DIR}") {
                                script {
                                    mavenTasks.runSonarQube()
                                }
                            }
                        }
                    }
                    stage('Run CheckMarx scan') {
                        agent {
                            node {
                                label "${NODE}"
                                customWorkspace "${WORKSPACE}"
                            }
                        }
                        when {    
                            anyOf { 
                                branch "${GIT_DEVELOP_BRANCH}"
                                branch "${GIT_MASTER_BRANCH}"
                                expression {
                                    ("${BRANCH_NAME}" =~ /feature/) && (stagesToRun.size() != 0) && (stagesToRun.RunCheckMarxScan)
                                }
                            }
                        }
                        steps {
                            dir ("${env.WORK_DIR}") {
                                script {
                                    // def branchNameNoSlash = env.BRANCH_NAME.replaceAll("/","-") commented in case of required for adding postfix
                                    scansHelper.runCheckMarxScan checkmarxProjectName: "${CHECKMARX_PROJECT_NAME}",
                                            checkmarxUrl: "${CHECKMARX_SERVER_URL}",
                                            checkmarxExclusion: "${CHECKMARX_EXCLUSIONS}"
                                }
                            }
                        }
                    }
                    stage('Run Black Duck scan') {
                        agent {
                            node {
                                label "${NODE}"
                                customWorkspace "${WORKSPACE}"
                            }
                        }
                        when {    
                            anyOf { 
                                branch "${GIT_DEVELOP_BRANCH}"
                                branch "${GIT_MASTER_BRANCH}"
                                expression {
                                    ("${BRANCH_NAME}" =~ /feature/) && (stagesToRun.size() != 0) && (stagesToRun.RunBlackDuckScan)
                                }
                            }
                        }
                        steps {
                            dir ("${env.WORK_DIR}") {
                                script {
                                    scansHelper.runBlackDuckScan projectName: "${BLACKDUCK_PROJECT_NAME}",
                                            projectVersion: "${env.PROJECT_VERSION}",
                                            scanDir: "${env.WORK_DIR}",
                                            exclusions: "${BLACKDUCK_EXCLUSIONS}",
                                            codeLocationName: "${env.PROJECT_NAME}"
                                }
                            }
                        }
                    }
                }
            }            

            stage('Deploy project') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }                
                steps {
                    dir ("${env.WORK_DIR}") {
                        script {
                            mavenTasks.buildDeploy()
                        }
                    }
                }
            }

            stage('Run release pipeline') {
                agent none
                when {
                    allOf {
                        branch "hotfix/*"
                        not { expression {
                            "${JAVA_SHARED_LIBS_BUILD}".toBoolean()
                            }
                        }
                    }    
                }
                steps {
                    script {
                        // Start scanning branches release pipeline
                        build job: "${RELEASE_PIPELINE_JOB_PATH}",
                                wait: false,
                                propagate: false

                        sleep 2

                        // launching a job for a specific branch
                        String encodedBranchName = java.net.URLEncoder.encode("${BRANCH_NAME}", "UTF-8")
                        GString pathToReleaseJob = "${RELEASE_PIPELINE_JOB_PATH}/${encodedBranchName}"
                        build job: pathToReleaseJob,
                                quietPeriod: 1,
                                wait: true
                    }
                }
            }

            stage('Push to master') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }   
                when {
                    allOf {
                        branch "${GIT_MASTER_BRANCH}"
                        triggeredBy "UserIdCause"
                        expression {
                            return (PROMOTE_BUILD =~ /Promote/)
                        }
                    }                    
                }       
                steps {
                    script {
                        // if tag already exist, move it by removing and creation operations
                        gitHelper.removeTagIfExists("${GIT_RELEASE_TAG_PREFIX}${PREVIOUS_PROJECT_VERSION}")  
                        gitHelper.putTag("${GIT_RELEASE_TAG_PREFIX}${PREVIOUS_PROJECT_VERSION}", 
                                "[${PIPELINE_DISPLAY_NAME}] Release Candidate version ${PREVIOUS_PROJECT_VERSION}")

                        // push to master
                        gitHelper.pushChanges()                       
                    }
                }    
                post {
                    failure {
                        script {
                            mailHelper.setExtendedStatus("Can't push changes to master")
                        }
                    }
                }            
            }

            stage('Update develop version') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
                when {
                    allOf {
                        branch "${GIT_MASTER_BRANCH}"
                        triggeredBy "UserIdCause"
                        expression {
                            return (PROMOTE_BUILD =~ /Promote/)
                        }
                    }                    
                }     
                steps {
                    script {
                        // switch back to 'develop'
                        gitHelper.switchLocalBranch("${GIT_DEVELOP_BRANCH}")

                        // update version to selected one
                        dir ("${env.WORK_DIR}") {
                            mavenTasks.changeProjectVersion("${NEXT_PROJECT_VERSION}")
                        }

                        gitHelper.commit("[${PIPELINE_DISPLAY_NAME}] Develop was upgraded to: ${NEXT_PROJECT_VERSION}")

                        gitHelper.putTag("${GIT_DEVELOP_TAG_PREFIX}${NEXT_PROJECT_VERSION}",
                            "[${PIPELINE_DISPLAY_NAME}] Develop version ${NEXT_PROJECT_VERSION}")

                        // in case of any changes were pushed while pipeline was working                        
                        gitHelper.pullChanges()                        

                        // push to develop
                        gitHelper.pushChanges()       
                    }
                }
                post {
                    success {
                        script {
                            mailHelper.setExtendedStatus("${GIT_DEVELOP_BRANCH} was merged to ${GIT_MASTER_BRANCH} with version ${PREVIOUS_PROJECT_VERSION}")
                        }
                    }
                    failure {
                        script {
                            mailHelper.setExtendedStatus("Unable to update develop version")
                        }
                    }
                }   
            }

        }

        post {
            failure {
                node("${NODE}") {
                    ws("${WORKSPACE}") {
                        script {
                            if ("${GIT_BRANCH}" == "${GIT_MASTER_BRANCH}") {
                                rollbackChanges()
                            }                                
                        }
                    }
                }
            }
            always {
                node("${NODE}") {
                    script {
                        // cleanup local docker registry from produced image as well as remove unused dangling images
                        echo "Cleaning up local docker storage"
                        if ((dslUtils.isUserInitiatedPipeline()) && 
                            ("${GIT_BRANCH}" == "${GIT_MASTER_BRANCH}") &&
                            (PROMOTE_BUILD =~ /Promote/)) {
                            mailHelper.sendStatusNotification()
                        } 
                        dslUtils.clearUnusedDockerImages()
                    }
                }                
            }
        }
    }
}

/**
* Used to return job to initial state
*/
def rollbackChanges() {
    echo "Rolling back changes..."

    if ((env.GIT_MASTER_BRANCH) && (PROMOTE_BUILD =~ /Promote/)) {
        // rollback master
        gitHelper.removeTagIfExists("${GIT_RELEASE_TAG_PREFIX}${PREVIOUS_PROJECT_VERSION}")                            
        gitHelper.abortMerge(true)
        gitHelper.switchLocalBranchIgnoreErrors("${GIT_MASTER_BRANCH}")                                
        gitHelper.rollbackLocalBranchChanges("${GIT_MASTER_BRANCH}")
    }

    //rollback develop
    gitHelper.removeTagIfExists("${GIT_DEVELOP_TAG_PREFIX}${PREVIOUS_PROJECT_VERSION}")     
    gitHelper.abortMerge(true)                       
    gitHelper.switchLocalBranchIgnoreErrors("${GIT_DEVELOP_BRANCH}")                                                    
    gitHelper.rollbackLocalBranchChanges("${GIT_DEVELOP_BRANCH}")

    echo "Done rolling back changes"
}

/**
 * Opens dialog in Jenkins and asks user what steps does he want to launch
 */
def choseStagesForRun() {
    try {
        timeout(time: 1, unit: 'HOURS') {
            milestone(0)
            def chosenParameters = input message: "For feature branch choose stages to run",
                    parameters: [
                            booleanParam(name: 'RunCheckMarxScan', defaultValue: false),
                            booleanParam(name: 'RunBlackDuckScan', defaultValue: false),
                            booleanParam(name: 'RunSonarQubeScan', defaultValue: false),
                    ],
                    submitterParameter: 'submitter',
                    ok: 'OK'
            echo "Following parameters were chosen: " + chosenParameters
            milestone(1)
            return chosenParameters
        }
    } catch (err) {
        echo "'Choose stages to run' action has been aborted"
    }
}

/**
* Opens dialog in Jenkins and asks user to choose the next version
*
* @param availableVersions A list with next versions available to choose
*/
def stageChooseNextVersion(currentVersion) {
    def versionsToChoose = getListOfNextVersions("${currentVersion}", "-SNAPSHOT")     

    mailHelper.sendUserInputRequest()

    try {
        timeout(time: 1, unit: 'HOURS') {
            milestone(2)            
            def chosenParameters = input message: "Choose next version for 'develop' branch", 
                    parameters: [choice(choices: versionsToChoose, description: "Version to be set in pom.xml (current is ${currentVersion}-SNAPSHOT)", name: 'version')], 
                    submitterParameter: 'submitter',                    
                    ok: 'OK'
            echo "Following parameters were chosen: " + chosenParameters
            milestone(3)
            return chosenParameters
        }
    } catch (err) {        
        echo "'Choose next version' action has been aborted"        
    }
}

/**
 * Dialog to ask user if master pipeline should do develop => master promotion, or only build artefacts
 */
 def stageChoosePromoteOrBuild() {
    def options = ["Build Only", "Promote"]
    try {
        timeout(time: 1, unit: 'HOURS') {
            milestone(0)
            def chosenParameter = input message: "Do you want to promote develop to master, or build only?",
                    parameters: [choice(choices: options, description: "Select an option.", name: 'option')],
                    submitterParameter: 'submitter',
                    ok: 'OK'
            milestone(1)
            return chosenParameter
        }
    } catch (err) {
        echo "Pipeline aborted due to timeout"
    }
 }

/**
 * Updates the version of the project in all pom files and pushes it in git
 *
 * @param projectVersion version of the project to be updated
 */
def updateProjectVersion(projectVersion) {
    echo "New project version: $projectVersion"
    mavenTasks.changeProjectVersion(projectVersion)
    gitHelper.commit("Changed project version to $projectVersion")
    gitHelper.pushChanges()
}

/**
* Generates a list of possible next versions
*
* @param projectVersion A current project version (separated with dot like 'x.y.z')
* @param suffix (Optional) A version suffix to be added at the end of each version option
*/
def getListOfNextVersions(projectVersion, suffix = '') {
    def versions = projectVersion.tokenize(".")
    def nextPossibleVersions = []
    for (i = versions.size() - 1; i >= 0; i--) {            
        try {
            def currentVersion = versions.clone()
            currentVersion[i] = currentVersion[i].toInteger() + 1

            for (j = i + 1; j < currentVersion.size(); j++) {
                currentVersion[j] = 0    
            }
    
            nextPossibleVersions << currentVersion.join(".") + suffix
        } catch (err) {
            prtintln 'Unable to parse version token: ' + currentVersion[i]
        }        
    }
    return nextPossibleVersions
}

#!groovy
/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

def call(body) {

    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    pipeline {
        agent {
            node {
                label 'nrc3lscmbld07vm'
                customWorkspace "/scm/Checkout/TIM/${JOB_NAME}"
            }
        }

        environment {
            timeStamp = new Date(currentBuild.startTimeInMillis).format("YYYYMMddHHmmss")

            NODE = "nrc3lscmbld07vm"

            DEVELOP_DOCKER_REGISTRY = "${pipelineParams.DEVELOP_DOCKER_REGISTRY ?: 'nrc3ldockreg01vm.am.tsacorp.com:18079/risk-app-tests'}"
            MAVEN_TEST_SKIP = "${pipelineParams.MAVEN_TEST_SKIP ?: 'false'}"

            DOCKER_REGISTRY_URL = "https://nrc3ldockreg01vm.am.tsacorp.com:18079"
            DOCKER_IMAGE_PREFIX = "risk-app-tests"
            DOCKER_IMAGE_NAME = "automatedtests"

            GIT_TOOL_NAME = "${pipelineParams.GIT_TOOL_NAME ?: 'GIT_2.14.2_LINUX'}"

            PIPELINE_DISPLAY_NAME = "${pipelineParams.PIPELINE_DISPLAY_NAME ?: 'RA Test Pipeline'}"
            PIPELINE_SUPPORT_EMAIL = "${pipelineParams.PIPELINE_SUPPORT_EMAIL ?: ''}"
        }

        parameters {
            string(name: 'autotestImageVersion', defaultValue: '2.3-SNAPSHOT', description: 'version for prefix for autotest docker image')
            string(name: 'ansibleBranch', defaultValue: 'develop', description: 'ansible repo branch to use to run regression test against')
            choice(name: 'environment', choices: 'dev2\nod5\nod6\ncit\nist-a\nist-b', description: 'Select environment')
            booleanParam(name: 'Cli Tests', defaultValue: true, description: 'CliTest')
            booleanParam(name: 'Rules Tests', defaultValue: false, description: 'RulesPipelineTest')
            booleanParam(name: 'Features Tests', defaultValue: false, description: 'FeaturesPipelineTest')
            booleanParam(name: 'Rules Templates Tests', defaultValue: false, description: 'RulesPipelineTest')
            booleanParam(name: 'Rules with Feature Builder Tests', defaultValue: false, description: 'RulesPipelineTest')
            booleanParam(name: 'My Rule Changes Tests', defaultValue: false, description: 'RulesPipelineTest')
            booleanParam(name: 'RestSuite', defaultValue: true, description: 'RestSuite')
            booleanParam(name: 'Cep Tests', defaultValue: true, description: 'CepTest')
            booleanParam(name: 'RestRE Tests', defaultValue: true, description: 'RestRESuite')
            booleanParam(name: 'RE Tests', defaultValue: true, description: 'RETest')
            booleanParam(name: 'LM CLI Tests', defaultValue: true, description: 'LMPipelineTest_CLI')
            booleanParam(name: 'Smoke Suite', defaultValue: false, description: 'SmokeSuite')
            booleanParam(name: 'CSI2A Smoke Tests', defaultValue: false, description: 'CSI2A Smoke Tests')
            string(name: 'freeHandTest', defaultValue: '', description: 'free-hand test or suite typed in (e.g CepTests or CountOperationFeatures) - must match valid test suite')
            string(name: 'testSleepTimeInSeconds', defaultValue: '30', description: 'Short sleep time in seconds for test job to wait for next test report poll')
            string(name: 'testTimeoutInMinutes', defaultValue: '240', description: 'Time in minutes for test suite to be cancelled and next test suite run or job completes')
        }

        options {
            buildDiscarder(logRotator(numToKeepStr: '10'))
            disableConcurrentBuilds()
            ansiColor('xterm')
        }

        stages {
            stage('Pull image') {
                steps {
                    script {
                        env.PROJECT_VERSION = "${params.autotestImageVersion}"

                        dockerHelper.pullImage()
                    }
                }
            }

            stage('Run tests') {
                steps {
                    checkout scm: [
                            $class           : 'GitSCM',
                            gitTool          : "${env.GIT_TOOL_NAME}",
                            branches         : [[name: "${params.ansibleBranch}"]],
                            userRemoteConfigs: [[url: "ssh://git@bitbucket.am.tsacorp.com:7999/tim/ansible.git"]]]

                    dir("ansible") {
                        script {
                            def inventoryName = "${params.environment}"
                            def tags = "automatedtests"
                            ansibleDeployHelper.executeTestPlaybook(inventoryName, 'Verify_OpenShift_Services', tags, "", "")
					   	
                           sh label: '', returnStdout: true, script: '''while IFS= read -r line; do
  								
  								case $line in

  								*csientitlements*Error*)
    								echo -n "$line"
                                    exit 1
    							;;
                                *sae*Error*)
    								echo -n "$line"
                                    exit 1
    							;;
  								*metadata*Error*)
    								echo -n "$line"
                                    exit 1
    							;;
  								*dbprunner*Error*)
    								echo -n "$line"
                                    exit 1
    							;;                                
								*featurecacheservice*Error*)
    								echo -n "$line"
    								exit 1
    							;;
                                *featureeventhandler*Error*)
    								echo -n "$line"
    								exit 1
    							;;
								esac
  
								done <"${WORKSPACE}/services.log"'''
                                      
                          	testTaskHelper.executeAnsibleTestsInParallel()
                          
                            sleep("${params.testSleepTimeInSeconds}")

                            def failedJob = false
                            def bldfailure = false
                            def crudTestList = testTaskHelper.getCrudTestsToRun()
							try {
								timeout(time: "${params.testTimeoutInMinutes}", unit: 'MINUTES') {
									while (crudTestList.size() > 0) {
										sh("echo ${crudTestList.size()}")
										crudTestList.each { item ->
											try {
												def testItemName = "${testTaskHelper.getTestMapValue(item)}"
												def testItemNameTmstmp = ("${testTaskHelper.getTestMapValue(item)}".replace("_", "") + timeStamp).toLowerCase()
												ansibleDeployHelper.executeTestPlaybook(inventoryName, 'test_results', tags, testItemName, testItemNameTmstmp)

												testScriptHelper.remoteCopyTestReport(testItemName, testItemNameTmstmp)
												dir("${testItemName}") {
													if (fileExists('failed.txt')) {
														failedJob = true
													}

													if (fileExists('failed.txt') || fileExists('passed.txt')) {
														testScriptHelper.copyTestReportToPublish(testItemNameTmstmp)

														testScriptHelper.remoteCopyTestReport(testItemName, testItemNameTmstmp)

														crudTestList-=item
														sh("echo ${crudTestList.size()}")
													}

												}
											} catch (e) {
											}
										}
										sleep("${params.testSleepTimeInSeconds}")
									}
								}
							} catch (e) {
								sh("echo \"Failure in Test Execution 1\"")
                                bldfailure = true
							}
                            testTaskHelper.getProcessingTestsToRun().each { item ->

                                def testItemName = "${testTaskHelper.getTestMapValue(item)}"
                                def testItemNameTmstmp = ("${testTaskHelper.getTestMapValue(item)}".replace("_", "") + timeStamp).toLowerCase()
                                ansibleDeployHelper.executeTestPlaybook(inventoryName, 'run_tests', tags, testItemName, testItemNameTmstmp)

                                dir("${testTaskHelper.getTestMapValue(item)}") {
                                    deleteDir()
                                }

                                sh("mkdir -p ${testTaskHelper.getTestMapValue(item)}")

                                sleep("${params.testSleepTimeInSeconds}")

                                def checkfile = 0
								try {
									timeout(time: "${params.testTimeoutInMinutes}", unit: 'MINUTES') {
										while (checkfile == 0) {
											try {
												ansibleDeployHelper.executeTestPlaybook(inventoryName, 'test_results', tags, testItemName, testItemNameTmstmp)

												testScriptHelper.remoteCopyTestReport(testItemName, testItemNameTmstmp)
												dir("${testTaskHelper.getTestMapValue(item)}") {
													if (fileExists('failed.txt')) {
														failedJob = true
													}

													if (fileExists('failed.txt') || fileExists('passed.txt')) {
														checkfile++

														testScriptHelper.copyTestReportToPublish(testItemNameTmstmp)

														testScriptHelper.remoteCopyTestReport(testItemName, testItemNameTmstmp)
													}
												}
											} catch (e) {
											}
											sleep("${params.testSleepTimeInSeconds}")
										}
									}
								} catch (e) {
									sh("echo \"Failure in Test Execution 2\"")
                                  	bldfailure = true
								}
                            }

                            if ("${params.freeHandTest}") {
                                testTaskHelper.getFreeHandTestsToRun().each { item ->
                                    def testItemName = item
                                    def testItemNameTmstmp = (item.replace("_", "") + timeStamp).toLowerCase()
                                    ansibleDeployHelper.executeTestPlaybook(inventoryName, 'run_tests', tags, testItemName, testItemNameTmstmp)

                                    dir("${params.freeHandTest}") {
                                        deleteDir()
                                    }

                                    sh("mkdir -p ${item}")

                                    sleep("${params.testSleepTimeInSeconds}")

                                    def checkfile = 0
									try {
										timeout(time: "${params.testTimeoutInMinutes}", unit: 'MINUTES') {
											while (checkfile == 0) {
												try {
													ansibleDeployHelper.executeTestPlaybook(inventoryName, 'test_results', tags, testItemName, testItemNameTmstmp)

													testScriptHelper.remoteCopyTestReport(testItemName, testItemNameTmstmp)
													dir("${params.freeHandTest}") {
														if (fileExists('failed.txt')) {
															failedJob = true
														}

														if (fileExists('failed.txt') || fileExists('passed.txt')) {
															checkfile++

															testScriptHelper.copyTestReportToPublish(testItemNameTmstmp)

															testScriptHelper.remoteCopyTestReport(testItemName, testItemNameTmstmp)
														}
													}
												} catch (e) {
												}
												sleep("${params.testSleepTimeInSeconds}")
											}
										}
									} catch (e) {
										sh("echo \"Failure in Test Execution 3\"")
                                      	bldfailure = true
									}
                                }
                            }

                            if (failedJob || bldfailure) {
                                currentBuild.result = 'FAILURE'
                            }

                        }
                    }
                }
            }

            stage("Clean results and delete pods") {
                steps {
                    checkout scm: [
                            $class           : 'GitSCM',
                            gitTool          : "${env.GIT_TOOL_NAME}",
                            branches         : [[name: "${params.ansibleBranch}"]],
                            userRemoteConfigs: [[url: "ssh://git@bitbucket.am.tsacorp.com:7999/tim/ansible.git"]]]

                    dir("ansible") {
                        script {
                            def inventoryName = "${params.environment}"
                            def tags = "automatedtests"

                            testTaskHelper.getCrudTestsToRun().each { item ->
                                def testItemNameTmstmp = ("${testTaskHelper.getTestMapValue(item)}".replace("_", "") + timeStamp).toLowerCase()
                                ansibleDeployHelper.executeTestCleanupPlaybook(inventoryName, 'clean_tests', tags, testItemNameTmstmp)
                            }

                            testTaskHelper.getProcessingTestsToRun().each { item ->
                                def testItemNameTmstmp = ("${testTaskHelper.getTestMapValue(item)}".replace("_", "") + timeStamp).toLowerCase()
                                ansibleDeployHelper.executeTestCleanupPlaybook(inventoryName, 'clean_tests', tags, testItemNameTmstmp)
                            }

                        }
                    }
                }
            }
        }

        post {
            always {
                script {
                    testReportHelper.publish()
                    junit 'publish/*.xml'
                    dir('publish') { deleteDir() }
                    if (currentBuild.result == 'UNSTABLE') {
                        currentBuild.result = 'FAILURE'
                    }
                    mailHelper.sendTestEmailNotification("${env.PIPELINE_SUPPORT_EMAIL}")
                }
            }
        }
    }
}

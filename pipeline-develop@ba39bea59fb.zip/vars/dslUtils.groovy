#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

import hudson.tasks.test.AbstractTestResultAction

/**
 * Finds and return value of required property from properties file.
 *
 * @param propertyName Name of the property.
 * @param fromFile Name of the properties file where search property.
 * @return String property that was found in property file or empty String if nothing was found.
 */
@NonCPS
String readProperty(propertyName, fromFile) {
    return sh(returnStdout: true, script:
            """#!/bin/sh
            echo "\$(cat ${fromFile} | grep "${propertyName}" | cut -d'=' -f2)" | tr -d '\n'
            """).trim()
}

/**
 * Calculates auto approve of deployment to qe.
 * Auto approve considered to be true if diff between failed tests from previous and current
 * build less then provided maximum difference parameter and all failed tests in current build
 * are subset of failed tests from previous build (no new tests failed)
 *
 * @param failureMaxDiff Maximum number of diff between failed tests from previous and current build.
 * @return Boolean Whether approve or reject auto approve of deployment to QE (true or false).
 */
@NonCPS
def autoApproveToQe(failureMaxDiff) {
    try {
        if ("UNSTABLE".equals(currentBuild?.currentResult) || "FAILURE".equals(currentBuild?.currentResult)) {
            echo "Current build doesn't have SUCCESS status so approve should be manual."
            return false
        }
        def testResultAction = currentBuild.rawBuild.getAction(AbstractTestResultAction.class)
        def diff = testResultAction.getFailCount() - testResultAction.getPreviousResult().getFailCount()
        println("Difference between previous tests failed and current: ${diff}")
        def currentFailures = []
        def previousFailures = []
        testResultAction.getFailedTests().each { test ->
            currentFailures << test.name
        }
        testResultAction.getPreviousResult().getFailedTests().each { test ->
            previousFailures << test.name
        }
        return diff > failureMaxDiff.toInteger() ? false : previousFailures.containsAll(currentFailures)
    } catch (exc) {
        println("Something went wrong with calculating autoapprove: ${exc}. Most probably you don't have previous build test results. You need to approve deployment manually.")
        return false
    }
}

/**
 * Deletes unused docker images
 */
def clearUnusedDockerImages() {
    try {
        sh 'docker images --filter "dangling=true" -q | xargs --no-run-if-empty docker rmi > /dev/null 2>&1 || true'
    } catch (exc) {
        println("Cannot clear images: ${exc}")
    }
}

/**
* Removes produced docker image from local repository to avoid disk space issues
*
* @param imageName A part of image name. You may pass a teg if required, for example 'someimage:1.1'
*/
def clearBuiltDockerImage(imageName) {
    sh script: """#!/bin/sh
        selected_images="\$(docker images --format "{{.Repository}}:{{.Tag}}|{{.ID}}" | grep -E '${imageName}')"
        declare -a selected_images

        for image in \${selected_images[@]}
        do
            id="\$(cut -d '|' -f 2 <<< \${image})"
            echo "Removing image \${image}"
            docker rmi -f \${id}
        done
        exit 0"""
}

/**
 * Converts csv to html files in the same directory where csv files are located
 * @param directory directory where csv files are located and must be converted to csv
 */
def csv2html(directory) {
    try {
        sh(script: """#!/bin/sh
                    function csv2html () {
                        cat "\$1" | tr '\r' '\n' > "\$1-unix.csv" && cat "\$1-unix.csv" > "\$1" && rm "\$1-unix.csv"
                        echo "<table border=\"1\">" ;
                        while read INPUT ; do
                           echo "<tr><td>\${INPUT//,/</td><td>}</td></tr>" ;
                        done < "\$1";
                        echo "</table>"
                    }
                    for file in ${directory}/*.csv; do
                        csv2html "\$file" > "${directory}/\$file.html"
                    done
        """)
    } catch (exc) {
        println("Something went wrong with converting csv reports to html: ${exc}. The reprots will be archived.")
        archiveArtifacts allowEmptyArchive: true, artifacts: "${directory}/*.csv"
    }
}

/**
* Checks if current pipeline was run manually
*/
@NonCPS
def isUserInitiatedPipeline() {       
    return currentBuild.getBuildCauses('hudson.model.Cause$UserIdCause').size() > 0
}
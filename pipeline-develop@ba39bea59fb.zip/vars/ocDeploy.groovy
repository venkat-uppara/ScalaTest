#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Makes deployment to Openshift cluster based on provided deployment template.
 *
 * @param toolName Name of the tool that was configured in Jenkins.
 * @param clusterName Name of the cluster that should be used and was configured in Jenkins.
 * @param environment Target environment where deployment config must be applied.
 * @param projectName Name of the project that should be deployed.
 * @param dcConfigFile Path to the deployment config.
 * @param paramsFile Path to the parameters file.
 * @param params Parameters that should be passed to the template.
 */
def deployToOcEnv(toolName, clusterName, environment, projectName, dcConfigFile, paramsFile, params) {
    def ocDir = tool "${toolName}"
    withEnv(["PATH+OC=${ocDir}"]) {
        openshift.withCluster("${clusterName}") {
            openshift.withProject("${environment}") {
                def paramsConcatStr = params.join(" ")
                def models = openshift.process("-f", "${dcConfigFile}",
                        "--param-file", "${paramsFile}", "${paramsConcatStr}")
                openshift.apply(models)
                openshift.raw("rollout", "latest", "dc/${projectName}")
                try {
                    timeout(10) {
                        def dc = openshift.selector('dc', "${projectName}")
                        // this will wait until the desired replicas are available
                        dc.rollout().status()
                    }
                } catch (err) {
                    try {
                        def latestDeploymentVersion = openshift.selector('dc',"${projectName}").object().status.latestVersion
                        openshift.selector("pod", [deployment : "${projectName}-${latestDeploymentVersion}"]).logs()
                    } catch (logsError) {
                        echo "Cannot retrieve logs from Openshift POD please check it in Openshift directly: ${logsError}"
                    }
                    openshift.raw("rollout", "undo", "dc/${projectName}")
                    error("Deployment to ${environment} failed, the app and configs were rolled back to the latest successful deployment. ${err}")
                }
            }
        }
    }
}

/**
 * Makes creation of resource in Openshift cluster based on provided template.
 *
 * @param toolName Name of the tool that was configured in Jenkins.
 * @param clusterName Name of the cluster that should be used and was configured in Jenkins.
 * @param environment Target environment where deployment config must be applied.
 * @param template Path to the template.
 * @param params Parameters that should be passed to the template.
 */
def createResourceFromTemplate(toolName, clusterName, environment, template, params) {
    def ocDir = tool "${toolName}"
    withEnv(["PATH+OC=${ocDir}"]) {
        openshift.withCluster("${clusterName}") {
            openshift.withProject("${environment}") {
                def paramsConcatStr = params.join(" ")
                def models = openshift.process("-f", "${template}",
                        "${paramsConcatStr}")
                openshift.apply(models)
            }
        }
    }
}

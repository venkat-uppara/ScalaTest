#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Create tag in Nexus ta can be associated with artifacts in the future.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param buildTag Tag from Jenkins build that should be created in Nexus.
 *
 */
def createNexusTag(params) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        sh(script: """#!/bin/sh
            set -e
            currentDate=\$(date -u +"%Y-%m-%dT%H:%M:%SZ")
            curl -f -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X POST "${params.nexusServer}/service/rest/v1/tags" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \\\"name\\\": \\\"${params.buildTag}\\\", \\\"firstCreated\\\": \\\"\${currentDate}\\\", \\\"lastUpdated\\\": \\\"\${currentDate}\\\"}"        
        """)
    }
}

/**
 * This method uploads artifact to Nexus amd associates existing tag in Nexus with uploaded artifact.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param projectName Name of the service (used to identify group in Nexus).
 * @param buildTag Existing tag in Nexus that should be associated with uploaded artifact.
 * @param artifactZipFileName Name of the zip archive that should be uploaded.
 * @param nexusArtifactsGroup Group where artifact will be associated
 *
 */
def associateNexusTagWithArtifact(params) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        sh(script: """#!/bin/sh
            set -e
            curl -f -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X POST "${params.nexusServer}/service/rest/v1/components?repository=raw-blr" -H "accept: application/json" -H "Content-Type: multipart/form-data" -F "raw.directory=${params.nexusArtifactsGroup}/${params.projectName}" -F "raw.tag=${params.buildTag}" -F "raw.asset1=@${params.artifactZipFileName};type=application/x-zip-compressed" -F "raw.asset1.filename=${params.artifactZipFileName}"        
        """)
    }
}

/**
 * This method uploads artifact to Nexus without any Nexus component tag.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param projectName Name of the service (used to identify group in Nexus).
 * @param artifactZipFileName Name of the zip archive that should be uploaded.
 * @param nexusArtifactsGroup Group where artifact will be associated
 *
 */
def uploadArtifactToNexus(params) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        sh(script: """#!/bin/sh
            set -e
            curl -f -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X POST "${params.nexusServer}/service/rest/v1/components?repository=raw-blr" -H "accept: application/json" -H "Content-Type: multipart/form-data" -F "raw.directory=${params.nexusArtifactsGroup}/${params.projectName}" -F "raw.asset1=@${params.artifactZipFileName};type=application/x-zip-compressed" -F "raw.asset1.filename=${params.artifactZipFileName}"        
        """)
    }
}

/**
 * Applies common tag (with -LATEST) to the existing tag in Nexus.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param commonTag Common tag that should be applied to existing tag.
 * @param projectName Name of the service (used to identify group in Nexus).
 * @param buildTag Existing tag in Nexus that should be associated with latest tag.
 * @param nexusArtifactsGroup Group where common tag will be associated
 *
 */
def applyCommonTagToArtifact(params) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        checkAndCreateCommonTagIfNotExist(params.nexusServer, params.commonTag)
        diassociateCommonTagFromArtifact(nexusServer: "${params.nexusServer}",  commonTag: "${params.commonTag}", projectName: "${params.projectName}", nexusArtifactsGroup: "${params.nexusArtifactsGroup}")
        sh(script: """#!/bin/sh
            set -e
            curl -f -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X POST "${params.nexusServer}/service/rest/v1/tags/associate/${params.commonTag}?repository=raw-blr&format=raw&group=/${params.nexusArtifactsGroup}/${params.projectName}&tag=${params.buildTag}" -H "accept: application/json"
        """)
    }
}

/**
 * Applies common tag (with -LATEST) to the existing docker image in Nexus.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param commonTag Common tag that should be applied to existing tag.
 * @param projectName Name of the service (used to identify group in Nexus).
 * @param latestTag Existing tag in Nexus that should be associated with latest tag.
 *
 */
def applyCommonTagToDockerImage(params) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        checkAndCreateCommonTagIfNotExist(params.nexusServer, params.commonTag)
        diassociateCommonTagFromDockerImage(nexusServer: "${params.nexusServer}",  commonTag: "${params.commonTag}", projectName: "${params.projectName}", latestTag: "${params.latestTag}")
        sh(script: """#!/bin/sh
            set -e
            curl -f -v -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X POST "${params.nexusServer}/service/rest/v1/tags/associate/${params.commonTag}?repository=docker-blr&docker.imageName=billers%2F${params.projectName}&docker.imageTag=${params.latestTag}" -H "accept: application/json"
        """)
    }
}

/**
 * Check whether common tag exists in Nexus and creates it if it doesn't exist.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param commonTag Common tag that should exist in Nexus.
 *
 */
def checkAndCreateCommonTagIfNotExist(nexusServer, commonTag) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        def commonTagExist = sh(returnStdout: true, script: """#!/bin/sh
                set -e
                curl -w "%{http_code}" -o /dev/null -s -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X GET "${nexusServer}/service/rest/v1/tags/${commonTag}" -H "accept: application/json"
                """)
        echo "Result from checking common tag in Nexus: ${commonTagExist}"
        if (commonTagExist == '404') {
            sh(script: """#!/bin/sh
                set -e
                echo "Common tag was not found, creating it"
                currentDate=\$(date -u +"%Y-%m-%dT%H:%M:%SZ")
                curl -f -v -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X POST "${nexusServer}/service/rest/v1/tags" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \\\"name\\\": \\\"${commonTag}\\\", \\\"firstCreated\\\": \\\"\${currentDate}\\\", \\\"lastUpdated\\\": \\\"\${currentDate}\\\"}"
            """)
        }
    }
}

/**
 * Removes common tag from specific artifact.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param commonTag Common tag that should be removed from Nexus.
 * @param projectName Name of the service where tag should be disassociated
 * @param nexusArtifactsGroup Group where artifact will be associated
 *
 */
def diassociateCommonTagFromArtifact(params) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        sh(script: """#!/bin/sh
            set -e
            curl -f -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X DELETE "${params.nexusServer}/service/rest/v1/tags/associate/${params.commonTag}?repository=raw-blr&group=/${params.nexusArtifactsGroup}/${params.projectName}" -H "accept: application/json"
        """)
    }
}

/**
 * Removes common tag from specific docker image.
 *
 * @param nexusServer Nexus hostname including protocol schema.
 * @param commonTag Common tag that should be removed from Nexus.
 * @param projectName Name of the service where tag should be disassociated
 * @param latestTag Latest tag for this image
 *
 */
def diassociateCommonTagFromDockerImage(params) {
    withCredentials([usernamePassword(credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment', usernameVariable: 'NEXUSUSER', passwordVariable: 'NEXUSPASSWORD')]) {
        sh(script: """#!/bin/sh
            set -e
            curl -f -v -k -u '${NEXUSUSER}:${NEXUSPASSWORD}' -X DELETE "${params.nexusServer}/service/rest/v1/tags/associate/${params.commonTag}?repository=docker-blr&docker.imageName=billers%2F${params.projectName}&docker.imageTag=${params.latestTag}" -H "accept: application/json"
        """)
    }
}

/**
 * Pushes zipped non-docker artifacts to corporate Nexus docker registry. 
 */
def pushNonDockerArtifacts() {
    try {

        getNonDockerArtifacts().each { item -> curlToNexus(item) }
        
        if (fileExists('LiquibaseAssembly')) {
            dir("LiquibaseAssembly/target") {
                nexusTag = "${NON_DOCKER_ARTIFACT_PREFIX}" + "${env.PROJECT_VERSION}"
                sh "rename *.zip ${NON_DOCKER_ARTIFACT_PREFIX}-liquibase-scripts-${env.IMAGE_VERSION}.zip *.zip"

                packageName = "${NON_DOCKER_ARTIFACT_PREFIX}" + "-liquibase-scripts-" + "${env.IMAGE_VERSION}" + ".zip"

                withCredentials([[$class          : 'UsernamePasswordMultiBinding', credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment',
                                  usernameVariable: 'nexusUsername', passwordVariable: 'nexusPassword']]) {

                    sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/tags\" " +
                            "-H \"accept: application/json\" -H \"Content-Type: application/json\" " +
                            "-d \"{ \\\"name\\\": \\\"" + nexusTag + "\\\", \\\"attributes\\\": {}}\""

                    sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/components?repository=raw-ra\" " +
                            "-H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=/RiskAnalytics\" -F \"raw.tag=" + nexusTag + "\" " +
                            "-F \"raw.asset1=@" + packageName + ";type=application/x-gzip\" -F \"raw.asset1.filename=" + packageName + "\""
                }
              if("${env.BRANCH_NAME}" == "${GIT_MASTER_BRANCH}"){
                withCredentials([[$class          : 'UsernamePasswordMultiBinding', credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment',
                                  usernameVariable: 'nexusUsername', passwordVariable: 'nexusPassword']]) {
    
                    sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/components?repository=raw-rc\" " +
                            "-H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=/RiskAnalytics\" -F \"raw.tag=" + nexusTag + "\" " +
                            "-F \"raw.asset1=@" + packageName + ";type=application/x-gzip\" -F \"raw.asset1.filename=" + packageName + "\""
                }
              
              }
            }
      }
      if (fileExists('dimensional-batch-processor')) {
          dir("dimensional-batch-processor/dbp-distribution/target") { 
            nexusTag = "RA_" + "${env.PROJECT_VERSION}"
          	sh "rename *.zip dbp-${env.IMAGE_VERSION}.zip *.zip"
            packageName = "dbp-" + "${env.IMAGE_VERSION}" 

              if("${env.BRANCH_NAME}" == "${GIT_DEVELOP_BRANCH}" || "${BRANCH_NAME}" =~ /feature/) {
			    withCredentials([[$class          : 'UsernamePasswordMultiBinding', credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment',
                                      usernameVariable: 'nexusUsername', passwordVariable: 'nexusPassword']]) {

                        sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/tags\" " +
                                "-H \"accept: application/json\" -H \"Content-Type: application/json\" " +
                                "-d \"{ \\\"name\\\": \\\"" + nexusTag + "\\\", \\\"attributes\\\": {}}\""

                        sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/components?repository=raw-ra\" " +
                                "-H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=/RiskAnalytics\" -F \"raw.tag=" + nexusTag + "\" " +
                                "-F \"raw.asset1=@" + packageName + ".zip;type=application/x-zip\" -F \"raw.asset1.filename=" + packageName + ".zip\""
                 }
               }
               else {
                            echo "Branch is : ${env.BRANCH_NAME} not ${GIT_DEVELOP_BRANCH} or Feature "
               }
			   if("${env.GIT_BRANCH}" =~ /hotfix/){
                  withCredentials([[$class          : 'UsernamePasswordMultiBinding', credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment',
                                        usernameVariable: 'nexusUsername', passwordVariable: 'nexusPassword']]) {
                                                
                         sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/tags\" " +
                                "-H \"accept: application/json\" -H \"Content-Type: application/json\" " +
                                "-d \"{ \\\"name\\\": \\\"" + nexusTag + "\\\", \\\"attributes\\\": {}}\""
                    
                         sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/components?repository=raw-rc\" " +
                                "-H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=/RiskAnalytics\" -F \"raw.tag=" + nexusTag + "\" " +
                                "-F \"raw.asset1=@" + packageName + ".zip;type=application/x-zip\" -F \"raw.asset1.filename=" + packageName + ".zip\""
                                            
                       
                    } 
               }
               if("${env.GIT_BRANCH}" == "${GIT_MASTER_BRANCH}"){
                  withCredentials([[$class          : 'UsernamePasswordMultiBinding', credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment',
                                        usernameVariable: 'nexusUsername', passwordVariable: 'nexusPassword']]) {
                                                
                        
                         sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/components?repository=raw-ra\" " +
                                "-H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=/RiskAnalytics\" -F \"raw.tag=" + nexusTag + "\" " +
                                "-F \"raw.asset1=@" + packageName + ".zip;type=application/x-zip\" -F \"raw.asset1.filename=" + packageName + ".zip\""
                                            
                       
                    } 
                }
                else {
                            echo "Branch is : ${env.BRANCH_NAME} not ${GIT_MASTER_BRANCH}"
                }
          }   
       }

    }
    catch (err) {
    }
}

		
/**
 *
 * @param item Non-docker artifacts to push to nexus
 * Helper method to execute POST request to nexus
 */
def curlToNexus(String item) {
  	if (fileExists(item)) {
        nexusTag = "${NON_DOCKER_ARTIFACT_PREFIX}" + "${env.PROJECT_VERSION}"
        packageName = "${NON_DOCKER_ARTIFACT_PREFIX}" + "-${item}" + "-${env.IMAGE_VERSION}"
        sh "tar -zcvf " + packageName + ".tar.gz " + "${item}"

        if("${env.BRANCH_NAME}" == "${GIT_DEVELOP_BRANCH}" || "${BRANCH_NAME}" =~ /feature/){
        withCredentials([[$class          : 'UsernamePasswordMultiBinding', credentialsId: 'NXPRD-nrc3ldockreg01vm-deployment',
                          usernameVariable: 'nexusUsername', passwordVariable: 'nexusPassword']]) {

            sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/tags\" " +
                    "-H \"accept: application/json\" -H \"Content-Type: application/json\" " +
                    "-d \"{ \\\"name\\\": \\\"" + nexusTag + "\\\", \\\"attributes\\\": {}}\""

            sh "curl -kvi -u '" + nexusUsername + ":" + nexusPassword + "' -X POST \"https://nrc3ldockreg01vm.am.tsacorp.com/service/rest/v1/components?repository=raw-ra\" " +
                    "-H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=/RiskAnalytics\" -F \"raw.tag=" + nexusTag + "\" " +
                    "-F \"raw.asset1=@" + packageName + ".tar.gz;type=application/x-gzip\" -F \"raw.asset1.filename=" + packageName + ".tar.gz\""
           }          
        }else {
                            echo "Branch is : ${env.BRANCH_NAME} not ${GIT_DEVELOP_BRANCH} or Feature "
        }
    }

}

/**
 * List of non-docker artifacts
 */
def getNonDockerArtifacts() {
    def artifacts = ["cli",
                     "kafka",
                     "cassandra",
                     "goldengate"]
    return artifacts
}

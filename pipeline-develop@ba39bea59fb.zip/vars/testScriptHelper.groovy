#!groovy
/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * copy test report to publish folder
 * @param testItemNameTmstmp test name with postfix timestamp for the report
 */
def copyTestReportToPublish(testItemNameTmstmp) {
    sh "mkdir -p ${env.WORKSPACE}/publish"
    sh "cp *.htm ${env.WORKSPACE}/publish"
    sh "cp *.txt ${env.WORKSPACE}/publish"
    sh "cp *.xml ${env.WORKSPACE}/publish"
}

/**
 * remote copy report from OCP server to jenkins workspace
 * @param testItemName
 * @param testItemNameTmstmp
 */
def remoteCopyTestReport(testItemName, testItemNameTmstmp) {
    sh("scp -r svc_scm1@cov3lcit03jmp01vm.ose.am.tsacorp.com:/home/svc_scm1/${testItemNameTmstmp}/TitaniumReports/. ${env.WORKSPACE}/ansible/${testItemName}")
}

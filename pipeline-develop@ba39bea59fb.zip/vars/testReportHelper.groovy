#!groovy
/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * publish the test report
 */
def publish() {
    def htmlReportPath = 'publish'
    def htmlReportFiles = '*.htm'

    // publish test report
    publishHTML target: [
            allowMissing         : false,
            alwaysLinkToLastBuild: true,
            keepAll              : true,
            reportDir            : "${htmlReportPath}/",
            reportFiles          : "${htmlReportFiles}",
            reportName           : "Test Report"
    ]
}

#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Executes build of project and publishing jacoco reports also checks minimum code coverage
 * that is specified in build gradle file.
 * If code coverage less then configured value the build will be failed
 * Deploys to nexus after code coverage is successful
 */
def build() {
    sh "mvn -X clean deploy -PjacocoReports -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} " +
        "-Drepo.id=${env.REPO_ID} -Djava.io.tmpdir=${env.TEMPDIR} " +
        "-DjenkinsBuildNumber=${env.BUILD_NUMBER} -Dmaven.test.skip=false"
}

/**
 * Executes  build and creates javadoc coverage reports
 */
def buildjavadoc() {
    sh "mvn -X package -Pjavadoc -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} " +
        "-Drepo.id=${env.REPO_ID} -Djava.io.tmpdir=${env.TEMPDIR} " +
        "-DjenkinsBuildNumber=${env.BUILD_NUMBER} -Dmaven.test.skip=true"
}

/**
 * Executes build with no deploy step for the artifacts whith will be used as shared libraries
 */
def buildInstall() {
    sh "mvn -X clean install -PjacocoReports -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} " +
        "-Drepo.id=${env.REPO_ID} -Djava.io.tmpdir=${env.TEMPDIR} " +
        "-DjenkinsBuildNumber=${env.BUILD_NUMBER} -Dmaven.test.skip=false"
}

/**
 * Executes deploy only with uploading artifacts to the remote repository as shared libraries
 */



def buildDeploy() {
    sh "mvn -X deploy -PjacocoReports -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} " +
        "-Drepo.id=${env.REPO_ID} -Djava.io.tmpdir=${env.TEMPDIR} " +
        "-DjenkinsBuildNumber=${env.BUILD_NUMBER} -Dmaven.test.skip=false"
}
/**
 * Executes component tests of project using cucumber automated test framework.
 * If any component tests fail the build will fail.
 */
def buildComponentTests() {
    sh "mvn -X clean install -Pcomponent-tests -DargLine=\"${env.ARG_LINE_OPTS}\""
}

/**
 * Builds docker image.
 */
def buildDockerImage() {
    sh "mvn -X clean package -Pdocker -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} " +
        "-Drepo.id=${env.REPO_ID} -Djava.io.tmpdir=${env.TEMPDIR} -DimageVersion=${env.IMAGE_VERSION} " +
        "-DjenkinsBuildNumber=${env.BUILD_NUMBER} -Dmaven.test.skip=false " +
        "-DgitRepo=${env.GIT_URL} -DgitCommitHash=${env.GIT_COMMIT} -DjenkinsBuild=${env.BUILD_URL}"
}

/**
 * Pushes built docker image to corporate Nexus docker registry.
 */
def pushDockerImage() {
    sh "mvn -X dockerfile:push -Pdocker -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} " +
        "-Drepo.id=${env.REPO_ID} -Djava.io.tmpdir=${env.TEMPDIR} -DimageVersion=${env.IMAGE_VERSION} " +
        "-DjenkinsBuildNumber=${env.BUILD_NUMBER} -Dmaven.test.skip=false " +
        "-DgitRepo=${env.GIT_URL} -DgitCommitHash=${env.GIT_COMMIT} -DjenkinsBuild=${env.BUILD_URL}"
}

/**
 * Executes maven task that will launch SonarQube scan.
 */
def runSonarQube() {
    def targetBranch = "${env.BRANCH_NAME}"
    if ("${env.BRANCH_NAME}" =~ /feature/) {
        targetBranch = "develop"
    } else if("${env.BRANCH_NAME}" =~ /hotfix/) {
        targetBranch = "master"
    }

    def projectKey = "${env.GIT_URL}".tokenize('/').last().tokenize('.').first()
	//sh "echo \"SonarQube server is down for maintenance \nAll the Sonar scans will be done once the server upgrade is completed. \""
    if ("${env.BRANCH_NAME}" == "develop" || "${env.BRANCH_NAME}" == "master") {
      sh "mvn sonar:sonar org.sonarsource.scanner.maven:sonar-maven-plugin:3.6.0.1398:sonar -Drepo.id=${env.REPO_ID} " +
            "-Dsonar.exclusions=**/migrator/src/main/java/com/aciworldwide/hive/migration/db/multiqueries/mappers/ReDShieldTransactionMapper.java " +
        	"-Dsonar.host.url=https://nrc3lsnrqb02vm.am.tsacorp.com " +
        	"-Dsonar.projectKey=com.aciworldwide.RA:${projectKey} " +
        	"-Dsonar.skipPackageDesign=true -Dsonar.language=java " +
        	"-Dsonar.login=c3016cfc34b00cfaf59e038f6a240700f9a6d383 -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} -Dsonar.scm.disabled=true -Dsonar.branch.name=${env.BRANCH_NAME} "
    } else {
    	sh "mvn sonar:sonar org.sonarsource.scanner.maven:sonar-maven-plugin:3.6.0.1398:sonar -Drepo.id=${env.REPO_ID} " +
            "-Dsonar.exclusions=**/migrator/src/main/java/com/aciworldwide/hive/migration/db/multiqueries/mappers/ReDShieldTransactionMapper.java " +
        	"-Dsonar.host.url=https://nrc3lsnrqb02vm.am.tsacorp.com " +
        	"-Dsonar.projectKey=com.aciworldwide.RA:${projectKey} " +
        	"-Dsonar.skipPackageDesign=true -Dsonar.language=java " +
        	"-Dsonar.login=c3016cfc34b00cfaf59e038f6a240700f9a6d383 -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} -Dsonar.scm.disabled=true -Dsonar.branch.name=${env.BRANCH_NAME} " +
        	"-Dsonar.branch.target=${targetBranch}"
    }
}

/**
* Updates project version in pom.xml files
*/
def changeProjectVersion(newVersion) {
    sh "mvn versions:set -Drepo.id=${env.REPO_ID} -Dmaven.repo.local=${env.MAVEN_LOCAL_REPO} -DgenerateBackupPoms=false " +
        "-DnewVersion=${newVersion} -DprocessAllModules=true"
}

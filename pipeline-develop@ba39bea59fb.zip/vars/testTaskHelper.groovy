#!groovy
/******************************************************************************
 *                                                                            *
 * Copyright (c) 2019 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * return list of processing tests
 * @return the list of processing tests
 */
def getProcessingTests() {
    def processingTests = ["RestSuite",
                           "Cep Tests",
                           "RE Tests",
                           "RestRE Tests"]
    return processingTests
}

/**
 * return list of crud tests
 * @return the list of processing tests
 */
def getCrudTests() {
    def crudTests = ["Rules Tests",
                     "Rules Templates Tests",
                     "Features Tests",
                     "Rules with Feature Builder Tests",
                     "My Rule Changes Tests",
                     "Cli Tests",
                     "LM CLI Tests",
                     "CSI2A Smoke Tests"]
    return crudTests
}

def getCrudTestsToRun() {
    def crudTestsToRun = []

    getCrudTests().each { item ->
        if (params[item]) {
            crudTestsToRun.add(item)
        }
    }

    return crudTestsToRun
}

def getProcessingTestsToRun() {
    def processingTestsToRun = []

    getProcessingTests().each { item ->
        if (params[item]) {
            processingTestsToRun.add(item)
        }
    }

    return processingTestsToRun
}

def getFreeHandTestsToRun() {
    def freeHandTestsToRun = []

    "${params.freeHandTest}".split(",").each { item ->
        if (item) {
            freeHandTestsToRun.add(item)
        }
    }

    return freeHandTestsToRun
}

def testRunner(String inputString) {
    return {
        runTests(getTestMapValue(inputString))
    }
}

def getTestMapValue(String input) {
    testMap = [
            'Cli Tests'                       : 'CliPipelineTest',
            'Rules Tests'                     : 'RulesPipelineTest',
            'Features Tests'                  : 'FeaturesPipelineTest',
            'Rules Templates Tests'           : 'RulesTemplatesPipelineTest',
            'Rules with Feature Builder Tests': 'RulesWithFeatureBuilderPipelineTest',
            'My Rule Changes Tests'           : 'MyRulesChangesPipelineTest',
            'RestSuite'                       : 'RestSuite',
            'Cep Tests'                       : 'CepPipelineTest',
            'RestRE Tests'                    : 'RestRESuite',
            'RE Tests'                        : 'REPipelineTest',
            'LM CLI Tests'                    : 'LMPipelineTest_CLI',
            'Smoke Suite'                      : 'SmokeSuite',
            'CSI2A Smoke Tests'               : 'SmokeTest_CSI2A']
    return testMap.get(input)
}

def runTests(String id) {
    try {
        containerName = 'ra_tests_t1' + id
        dockerCmd.dockerRun(containerName, id, environment)
    }
    catch (e) {
        currentBuild.result = 'FAILURE'
//      throw e
    }
}

def executeTests() {
    if (getCrudTestsToRun()) {
        def guiTestsParallel = getCrudTestsToRun().collectEntries {
            ["${it}": testRunner(it)]
        }
        parallel guiTestsParallel
    }

    getProcessingTests().each { item ->
        if (params[item]) {
//          i = processingTests.findIndexOf { it == item }
            runTests(getTestMapValue(item))
        }
    }
}

def createTestAnsible(String item) {
    def inventoryName = "${params.environment}"
    def tags = "automatedtests"
    def testItemName = "${getTestMapValue(item)}"
    def testItemNameTmstmp = ("${getTestMapValue(item)}".replace("_", "") + timeStamp).toLowerCase()

    ansibleDeployHelper.executeTestPlaybook(inventoryName, 'run_tests', tags, testItemName, testItemNameTmstmp)

    dir("${getTestMapValue(item)}") {
        deleteDir()
    }

    sh("mkdir ${getTestMapValue(item)}")
}

def ansibleRunner(String item) {
    return {
        createTestAnsible(item)
    }
}

def executeAnsibleTestsInParallel() {
    def parallelTestStart = getCrudTestsToRun().collectEntries {
        ["${it}": ansibleRunner(it)]
    }

    parallel parallelTestStart
}

def postCleanup() {
    getProcessingTests().each { item ->
        if (params[item]) {
            postActions("${item}")
        }
    }

    getCrudTestsToRun().each { item -> postActions("${item}")
    }
}

def postActions(String testId) {
    id = getTestMapValue(testId)

    titaniumLogsName = 'titanium_logs' + id
    surefireName = 'surefire' + id
    containerName = 'ra_tests_t1' + id
    titaniumLogsName = 'titanium_logs' + id
    surefireName = 'surefire' + id

    dir(titaniumLogsName) {
        deleteDir()
    }

    dir(surefireName) {
        deleteDir()
    }

    try {
        script {
            dockerCmd.copyFrameworkReports(containerName, titaniumLogsName)
            dockerCmd.copySurefireReports(containerName, surefireName)
        }
    }
    catch (e) {
        throw e
    }

    try {
        script { dockerCmd.cleanByID("ra_tests_t1", id) }
    }
    catch (e) {
        throw e
    }

    dir(titaniumLogsName) {
        sh "rename *.htm report${id}-${env.BUILD_NUMBER}.htm *.htm"
        sh "mkdir -p ${env.WORKSPACE}/publish"
        sh "cp report${id}-${env.BUILD_NUMBER}.htm ${env.WORKSPACE}/publish"
    }

    //junit "surefire/*.xml"

    dir(surefireName) {
        sh 'touch *.xml'
    }

    step([$class: 'JUnitResultArchiver', testResults: "${surefireName}/*.xml"])

    dir(titaniumLogsName) {
        deleteDir()
    }

    dir(surefireName) {
        deleteDir()
    }
}

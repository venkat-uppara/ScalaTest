#!groovy
pipeline {
   
	  agent {
		node {
			label 'nrc3lscmbld07vm'
			customWorkspace "/scm/Checkout/TIM/${JOB_NAME}"
			}
		}
		
		environment {
            NODE = "nrc3lscmbld07vm"
            WORKSPACE = "/scm/Checkout/TIM/${JOB_NAME}"
            DEVELOP_DOCKER_REGISTRY = "nrc3ldockreg01vm.am.tsacorp.com:18079/risk-app"
            registry = "nrc3ldockreg01vm.am.tsacorp.com:18090/risk-app"
		}
		
        parameters {
            string(name: 'PROJECT_VERSION', description: 'Version of docker image')
            string(name: 'DOCKER_IMAGE_NAME', description: 'Name of docker image')
        }
        
        
		stages {
			stage('Pull Image') {
            agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                        
                    }
                }
				steps {
					script {
                        library identifier: "pipeline@develop", retriever: modernSCM(
        					[$class       : "GitSCMSource",
         					remote       : "ssh://git@bitbucket.am.tsacorp.com:7999/tim/pipeline.git",
         					credentialsId: "35ec411e-2dc0-4397-896a-96bfee428b18"])
                      	PROJECT_VERSION = params.PROJECT_VERSION
                        DOCKER_IMAGE_NAME = params.DOCKER_IMAGE_NAME
                      	
                        dockerHelper.pullImage()
                        //sh "docker pull ${DEVELOP_DOCKER_REGISTRY}/${DOCKER_IMAGE_NAME}:${PROJECT_VERSION}"
					}
				}
			}
			
			stage('Tag Image') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
				steps {
					script {
                      	def tag = "${PROJECT_VERSION}"
                        dockerHelper.tagImage("${registry}", "${tag}")
                        
                        /*sh "docker tag ${DEVELOP_DOCKER_REGISTRY}/${DOCKER_IMAGE_NAME}:${PROJECT_VERSION} " + 
                            "${registry}/${DOCKER_IMAGE_NAME}:${tag}"*/
					}
				}
			}
			
			stage('Push Image') {
                agent {
                    node {
                        label "${NODE}"
                        customWorkspace "${WORKSPACE}"
                    }
                }
				steps {
					script {
                      	def tag = "${PROJECT_VERSION}"
                        dockerHelper.pushImage("${registry}", "${tag}")
                      
                        //def tag = "${PROJECT_VERSION}"
                        //sh "docker push ${registry}/${DOCKER_IMAGE_NAME}:${tag}"
					}
				}
			}
		}
}


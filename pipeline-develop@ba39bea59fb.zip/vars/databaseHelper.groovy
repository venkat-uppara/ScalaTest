#!groovy
/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2019 by ACI Worldwide Inc.                                  *
 *  All rights reserved.                                                      *
 *                                                                            *
 *  This software is the confidential and proprietary information of ACI      *
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such   *
 *  Confidential Information and shall use it in accordance with the 		  *
 *  terms of the license agreement you entered with ACI Worldwide Inc.        *
 ******************************************************************************/
pipeline {
	
	agent {
		node {
			label 'nrc3lscmbld07vm'
			customWorkspace "/scm/Checkout/TIM/${JOB_NAME}"
			}
		}

		triggers {
			cron('H 18 * * 5') //every Friday 6:00 PM EDT
		}
		
		stages {
			stage('CIT Database Cleanup') {
            agent none
				steps {
					script {
                      
							sh label: '', script: '''#!/bin/bash

								ORACLE_HOME=/usr/lib/oracle/19.5/client64
								export ORACLE_HOME

								DBUSER=\'APSFCITDEV\'
								DBUSERPASSWORD=\'APSF4100\'
								DB=\'cov3lrsdev01vm.am.tsacorp.com:1521/RAMDDEV\'

								$ORACLE_HOME/bin/sqlplus -S ${DBUSER}/${DBUSERPASSWORD}@${DB} << EOF
									
                                    DELETE FROM RMS_ACTIONSET WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_ACTIONSET_ITEM WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_ATTRIBUTE WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_AUDIT WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_CONSTANT WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_FEATURE WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_LOCK WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_METADATA_VERSION WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_ORGANIZATION WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_RELATED_ENTITY WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_RELATED_ORG WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_RESULT WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_RULE WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_RULE_MIGRATION WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_RULE_MIGRATION_AUDIT WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_SEMANTIC_ATTRIBUTE_LINK WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_SEMANTIC_FEATURE_LINK WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_SEMANTIC_TAG WHERE STATUS_CD=\'DELETED\';
									DELETE FROM RMS_TEMPLATE_CATEGORY WHERE STATUS_CD=\'DELETED\';

									DELETE FROM RMS_ACTIONSET ra WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\'; 
									DELETE FROM RMS_ACTIONSET_ITEM rai WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_ATTRIBUTE ra WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_AUDIT ra WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_CONSTANT rc WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_DELTA rd WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_ENTITY re WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_ENUM_VALUE rev WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_FEATURE rf Where CREATED_BY like \'REDSHIELDUSER18%\' or UPDATED_BY like \'REDSHIELDUSER18%\';
									DELETE FROM RMS_LOCK rl WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_METADATA_VERSION rmv WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_METADATA_VERSION_LOG rmvl WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_ORGANIZATION ro WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_RELATED_ENTITY rre WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_RELATED_ORG rro WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_RESULT rr WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_RULE rr WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE from rms_rule_draft where rule_id in (select rule_id from rms_rule where created_by like \'REDSHIELDUSER18%\');            
									DELETE FROM RMS_RULE_MIGRATION rrm WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_RULE_MIGRATION_AUDIT rrma WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_SEMANTIC_ATTRIBUTE_LINK rsal WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_SEMANTIC_FEATURE_LINK rsfl WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_SEMANTIC_TAG rst WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';
									DELETE FROM RMS_TEMPLATE_CATEGORY rtc WHERE CREATED_BY LIKE \'REDSHIELDUSER18%\';

									commit;
									EXIT;
								EOD
							'''
					}
				}
			}
		}
    post {
        always {  // will perform always and check if the clean dir is set up, then clean workspace
          	emailext (
                    attachLog: true,
                    compressLog: true,
                    to: "grp-aci-pd-MerchantFraud-CobaltTeam@aciworldwide.com",
                    subject: "${currentBuild.currentResult} : ${currentBuild.fullDisplayName}",
                    body: "Build ${currentBuild.fullDisplayName} status: ${currentBuild.currentResult} - ${env.RUN_DISPLAY_URL}"
            	)
        	}	
    } 
  
}

#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

/**
 * Copies change logs in zip format to a specific directory on provided Ansible control server.
 *
 * @param changelogDestZipDir Directory where change logs will be copied to the Ansible control server.
 * @param changelogZipFileName Name of the zip file with the change logs that should be copied.
 * @param ansibleControlCenter Ansible control server where change logs should be copied.
 */
def copyChangelogsToAnsibleControlCenter(changelogDestZipDir, changelogZipFileName, ansibleControlCenter) {
    sh "ssh ansible@${ansibleControlCenter} \"mkdir -p ${changelogDestZipDir}\" && scp build/liquibase/${changelogZipFileName} ansible@${ansibleControlCenter}:${changelogDestZipDir}/"
}

/**
 * Connects to the Ansible control server and launch playbook for liquibase database update.
 * Accepts Map of parameter
 *
 * @param ansibleControlCenter Ansible control center where playbook and liquibase change logs are located.
 * @param ansibleHomeDir Directory on the server where playbook, roles and inventories are located.
 * @param inventory Ansible inventory that will be used.
 * @param databaseName Name of the database where change logs must be executed.
 * @param databaseSchemaName Name of the schema where change logs must me executed.
 * @param postgresDbPort Port of Postgres server where database is located.
 * @param changelogDestZipDir Directory where change logs are located on the Ansible control server.
 * @param changelogZipFileName Name of the zip file with the change logs.
 */
def updateDatabaseFromChangelog(params) {
    sh "ssh ansible@${params.ansibleControlCenter} \"cd ${params.ansibleHomeDir} && ansible-playbook liquibase-postgres.yml -i inventories/${params.inventory} -e '\''postgres_db_name=${params.databaseName} postgres_schema=${params.databaseSchemaName} postgres_db_port=${params.postgresDbPort} changelog_zip_file=${params.changelogDestZipDir}/${params.changelogZipFileName}'\''\""
}
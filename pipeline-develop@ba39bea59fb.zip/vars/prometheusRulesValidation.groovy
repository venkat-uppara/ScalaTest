#!groovy

/******************************************************************************
 *                                                                            *
 * Copyright (c) 2018 by ACI Worldwide Inc.                                   *
 * All rights reserved.                                                       *
 *                                                                            *
 * This software is the confidential and proprietary information of ACI       *
 * Worldwide Inc ("Confidential Information"). You shall not disclose such    *
 * Confidential Information and shall use it only in accordance with the      *
 * terms of the license agreement you entered with ACI Worldwide Inc.         *
 ******************************************************************************/

import java.util.regex.*
import groovy.io.FileType
import  java.io.File.*

/**
 * Main pipeline declaration for all Titanium services.
 */
def call(body) {

	def skipRemainingStages = false
	pipeline {
		agent {
			node {
				label 'nrc3lscmbld07vm'
				customWorkspace '/scm/workspace/PRM/Titanium/Nightly/prometheusRulesValidation'
			}
		}
    
		stages {
        
			stage('CheckOut') {
				steps {
					script {
						//checkout([$class: 'GitSCM', branches: [[name: 'develop']], doGenerateSubmoduleConfigurations: false, extensions: [], gitTool: 'GIT_2.7.0_LINUX', submoduleCfg: [], userRemoteConfigs: [[credentialsId: '35ec411e-2dc0-4397-896a-96bfee428b18', url: 'ssh://git@bitbucket.am.tsacorp.com:7999/pb/test101.git']]])*/
						checkout([$class: 'GitSCM', branches: [[name: "develop"]], doGenerateSubmoduleConfigurations: false, extensions: [], gitTool: 'GIT_2.14.2_LINUX', submoduleCfg: [], userRemoteConfigs: [[credentialsId: '35ec411e-2dc0-4397-896a-96bfee428b18', url: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/ansible.git']]])
						if ( checkFolderForDiffs('${WORKSPACE}/ansible/monitoring/') ) {
							println "Changes in the folder"
                        
						} else {
							println "No Changes in the folder"
							skipRemainingStages = true
						}
					}
				}
			}
			stage('Syntax Check of Prometheus Rules') {
				when {
					expression { 
						!skipRemainingStages
					}
				}
				steps {
					script {
                      	dir('ansible/monitoring/Rules') {
                          String fileList = ""
                          def  FILES_LIST = sh (script: "ls   '${WORKSPACE}/ansible/monitoring/Rules'", returnStdout: true).trim()
						  for(String ele : FILES_LIST.split("\\r?\\n")){ 
 							  fileList = fileList.concat("${ele}")
                              fileList = fileList.concat(" ")
						  }
                          println "${fileList}"   
							sh label: '', script: "/scm/Apps/PromTool/prometheus-2.18.1.linux-amd64/promtool check rules ${fileList}" 
						}
                    
					}
				}
			}
			stage('Unit test of Prometheus Rules') {
				when {
					expression { 
						!skipRemainingStages
					}
				}
				steps {
					script {
						dir('ansible/monitoring/tests') {
                            String fileList = ""
                          	def  FILES_LIST = sh (script: "ls   '${WORKSPACE}/ansible/monitoring/tests'", returnStdout: true).trim()
						  	for(String ele : FILES_LIST.split("\\r?\\n")){ 
 							  fileList = fileList.concat("${ele}")
                              fileList = fileList.concat(" ")
						  	}
                          	println "${fileList}"   
							sh label: '', script: "/scm/Apps/PromTool/prometheus-2.18.1.linux-amd64/promtool test rules ${fileList}" 
						}
					}
				}
			}
		}
	}
}


/*
 * Check a folder if changed in the latest commit.
 * Returns true if changed, or false if no changes.
 */
def checkFolderForDiffs(path) {
    try {
        // git diff will return 1 for changes (failure) which is caught in catch, or
        // 0 meaning no changes 
        sh "git diff --quiet --exit-code HEAD~1..HEAD ${path}"
        return false
    } catch (err) {
        return true
    }
}

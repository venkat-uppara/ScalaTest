#!groovy
// creator katta smitha Rajathi 01.2020  smitha.katta@aciworldwide.com
/******************************************************************************
*                                                                            *
*  Copyright (c) 2019 by ACI Worldwide Inc.                                  *
*  All rights reserved.                                                      *
*                                                                            *
*  This software is the confidential and proprietary information of ACI      *
*  Worldwide Inc ("Confidential Information"). You shall not disclose such   *
*  Confidential Information and shall use it in accordance with the     *
*  terms of the license agreement you entered with ACI Worldwide Inc.        *


******************************************************************************/

pipeline {
	parameters {
		choice(name: 'Environment', choices: 'cit\nod2', description: 'Select environment to deploy (now only cit is available)')
	}
	agent {
		node {
			label 'nrc3lscmbld07vm'
			customWorkspace '/scm/workspace/PRM/Titanium/RA_pipelines/master/RA_Full_build_test'
		}
	}
	options {
		skipDefaultCheckout()
		disableConcurrentBuilds()
		buildDiscarder(logRotator(numToKeepStr: '15'))
	}

	environment {
		SKIP_TLS = "true"
		jobDir = "${env.WORKSPACE}/${env.JOB_BASE_NAME}"
		emailTo = 'grp-aci-pd-MerchantFraud-CobaltTeam@aciworldwide.com'
	}

	stages { 
//commenting Featurecachecorelib,Commonlibs,APSFCommon Build as these repos have git hook enabled and are built with every commit in Develop
/*      
		stage('Build   Featurecachecorelib ') {
			agent none
			steps {
				script {
					def fl = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/FeatureCacheCoreLib_Pipeline/develop',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def flResult = fl.getResult()
					echo "Featurecachecorelib   Build returned result: ${flResult}"
					if (flResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("Featurecachecorelib failed with result: ${flResult}")
						} 
					} 
				}
			}
		}
      
		stage('Build   Commonlibs') {
			agent none
			steps {
				script {
					def cl = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/CommonLib_Pipeline/develop',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def clResult = cl.getResult()
					echo "Commonlibs  Build returned result: ${clResult}"
					if (clResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("Commonlibs failed with result: ${clResult}")
						} 
					} 
				}
			}
		}
      
		stage('Build  APSFCommon') {
			agent none
			steps {
				script {
					def ac = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/APSFCommon_Pipeline/develop',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def acResult = ac.getResult()
					echo "APSFCommon Build returned result: ${acResult}"
					if (acResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("APSFCommon failed with result: ${acResult}")
						} 
					} 
				}
			}
		}
*/      
		stage('Build SAE') { //generates-sae,rediexporter,codegenerator,cli -- internally calls RA_21_Docker-CI-Deploy job to build docker images
			agent none
			steps {
				script {
					inventoryName = params.Environment
					if (params.Environment) {
						def sae = build job: 'PRM/Titanium/RA_pipelines/develop/RA_SAE21-CI-Deploy/',
						parameters : [
							string(name: 'saeRepoUrl', value: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/sae.git'),
							string(name: 'saeBranch', value: 'develop'),
							string(name: 'raVersion', value: '2.7-SNAPSHOT'),
							string(name: 'modules', value: 'all'),
							booleanParam(name: 'deployToOS', value: false),
							string(name: 'ocCluster', value: 'ose-dev-cluster'),
							string(name: 'openShiftProject', value: "frm-${inventoryName}-svc"),
							booleanParam(name: 'skipModulesBuild', value: false),
							booleanParam(name: 'skipJUnit', value: false),
							booleanParam(name: 'cleanWorkspaces', value: false)
						],
						propagate: false,
						quietPeriod: 1,
						wait: true
						def saeResult = sae.getResult()
						echo "SAE build returned result: ${saeResult}"
						if (saeResult == 'FAILURE') {
							catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
								error("SAE failed with result: ${saeResult}")
							}
						}
					}
				}
			}
		}

        stage('Build featurecacheservice') {
			agent none
			steps {
				script {
					inventoryName = params.Environment
					def featurecacheservice = build job: 'PRM/Titanium/RA_pipelines/develop/RA_21_Docker-CI-Deploy',
					parameters : [
						string(name: 'dockerRepoUrl', value: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/docker-base.git'),
						string(name: 'dockerBranch', value: 'develop'),
						string(name: 'raVersion', value: '2.7-SNAPSHOT'),
						string(name: 'dockerbaseProfileName', value: 'featurecacheservice'),
						string(name: 'modules', value: 'all'),
						booleanParam(name: 'deployToOS', value: false),
						string(name: 'ocCluster', value: 'ose-dev-cluster'),
						string(name: 'openShiftProject', value: "frm-${inventoryName}-svc"),
						booleanParam(name: 'deployDockerImages', value: true),
						booleanParam(name: 'updateOSConfiguration', value: false),
						booleanParam(name: 'cleanWorkspaces', value: false),
						string(name: 'codeBaseJenkinsBuild', value: 'N/A'),
						string(name: 'codeBaseGitRepo', value: 'N/A'),
						string(name: 'codeBaseGitCommitHash', value: 'N/A')
					],
					propagate: false,
					quietPeriod: 1,
					wait: true
					def featurecacheserviceResult = featurecacheservice.getResult()   
					echo "Featurecacheservice build' returned result: ${featurecacheserviceResult}"
					if (featurecacheserviceResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("featurecacheserviceResult failed with result: ${featurecacheserviceResult}")
						}
					}
				}
			}
		}      
		
		stage('Build Adminops') {
			agent none
			steps {
				script {
					inventoryName = params.Environment
					def adm = build job: 'PRM/Titanium/RA_pipelines/develop/RA_21_Docker-CI-Deploy',
					parameters : [
						string(name: 'dockerRepoUrl', value: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/docker-base.git'),
						string(name: 'dockerBranch', value: 'develop'),
						string(name: 'raVersion', value: '2.1'),
						string(name: 'dockerbaseProfileName', value: 'adminops'),
						string(name: 'modules', value: 'adminops'),
						booleanParam(name: 'deployToOS', value: false),
						string(name: 'ocCluster', value: 'ose-dev-cluster'),
						string(name: 'openShiftProject', value: "frm-${inventoryName}-svc"),
						booleanParam(name: 'deployDockerImages', value: true),
						booleanParam(name: 'updateOSConfiguration', value: false),
						booleanParam(name: 'cleanWorkspaces', value: false),
						string(name: 'codeBaseJenkinsBuild', value: 'N/A'),
						string(name: 'codeBaseGitRepo', value: 'N/A'),
						string(name: 'codeBaseGitCommitHash', value: 'N/A')
					],
					propagate: false,
					quietPeriod: 1,
					wait: true
					def adminResult = adm.getResult()   
					echo "Adminops build' returned result: ${adminResult}"
					if (adminResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("adminops failed with result: ${adminResult}")
						}
					}
				}
			}
		}
      
      	stage('Build Rule Manager') {
			agent none
			steps {
				script {
					inventoryName = params.Environment
					def rm = build job: '/PRM/Titanium/RA_pipelines/develop/RA_RM21-CI-Deploy/',
					parameters : [
						string(name: 'rmRepoUrl', value: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/rulemanager.git'),
						string(name: 'ccBranch', value: 'develop')
					],
					propagate: false,
					quietPeriod: 1,
					wait: true
					def rmResult = rm.getResult()
					echo "RuleManager build returned result: ${rmResult}"
					if (rmResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("Rule Manager failed with result: ${rmResult}")
						}                        
					}
				}
			}
		}

		stage('Build Controlcenter') {
			agent none
			steps {
				script {
					inventoryName = params.Environment
					def cc = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/ControlCenterService_Pipeline/develop/',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def ccResult = cc.getResult()
					echo "ControlCentre build returned result: ${ccResult}"
					if (ccResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("Control centre failed with result: ${ccResult}")
						}                        
					}
				}
			}
		}
//commenting Metadata Build as Metadata has git hook enabled and is built with every commit in Develop
/*
		stage('Build  Metadata') {
			agent none
			steps {
				script {
					inventoryName = params.Environment
					def md = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/MetadataService_Pipeline/develop',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def mdResult = md.getResult()
					echo "metadata build returned result: ${mdResult}"
					if (mdResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("Metadata failed with result: ${mdResult}")
						}
					}
				}
			}
		}
*/
		stage('Build  CSI Services') { //csiauth,csiweb,csicacheupdates,csientitlements
			agent none
			steps {
				script {
					def csi = build job: 'Retailers/Merchant Fraud Prevention/ReD Shield/RED_CSI2_GIT_12.1_CSI2',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def csi_Result = csi.getResult()
					echo " csi maven build job returned result: ${csi_Result}"
					if (csi_Result == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("csi Build failed with result: ${csi_Result}")
						}
                    } else {
                      	//CsiWeb job to build docker image
                    	def csiWeb = build job: 'Retailers/Merchant Fraud Prevention/ReD Shield/RED_CSI2AWeb_GIT_Assembly',
                        parameters : [
							string(name: 'GIT_BRANCH', value: 'develop')
						],
						propagate: false,
						quietPeriod: 1,
						wait: true
                      	def csiWeb_Result = csiWeb.getResult()
						echo " csiWeb docker job returned result: ${csiWeb_Result}"
                      	if (csiWeb_Result == 'FAILURE') {
							catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
								error("csiWeb Build failed with result: ${csiWeb_Result}")
							}
                    	}
                      
                      	//CsiEntitlements job to build docker image
                    	def csiEntitlements = build job: 'Retailers/Merchant Fraud Prevention/ReD Shield/RED_CSI2EntitlementsAuth_GIT_Assembly',
                        parameters : [
							string(name: 'GIT_BRANCH', value: 'develop')
						],
						propagate: false,
						quietPeriod: 1,
						wait: true
                      	def csiEntitlements_Result = csiEntitlements.getResult()
						echo " csiEntitlements docker job returned result: ${csiEntitlements_Result}"
                      	if (csiEntitlements_Result == 'FAILURE') {
							catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
								error("csiEntitlements Build failed with result: ${csiEntitlements_Result}")
							}
                    	}
                      
                      	//CsiAuth job to build docker image
                    	def csiAuth = build job: 'Retailers/Merchant Fraud Prevention/ReD Shield/RED_CSI2Adaptor_GIT_Assembly',
                        parameters : [
							string(name: 'GIT_BRANCH', value: 'develop')
						],
						propagate: false,
						quietPeriod: 1,
						wait: true
                      	def csiAuth_Result = csiAuth.getResult()
						echo "csiAuth docker job returned result: ${csiAuth_Result}"
                      	if (csiAuth_Result == 'FAILURE') {
							catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
								error("csiAuth Build failed with result: ${csiAuth_Result}")
							}
                    	}
                      
                      	//CsiCacheUpdate job to build docker image
                    	def csiCacheUpdate = build job: 'Retailers/Merchant Fraud Prevention/ReD Shield/RED_CSICacheUpdate_GIT_Assembly',
                        parameters : [
							string(name: 'GIT_BRANCH', value: 'develop')
						],
						propagate: false,
						quietPeriod: 1,
						wait: true
                      	def csiCacheUpdate_Result = csiCacheUpdate.getResult()
						echo "csiCacheUpdate docker job returned result: ${csiCacheUpdate_Result}"
                      	if (csiCacheUpdate_Result == 'FAILURE') {
							catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
								error("csiCacheUpdate Build failed with result: ${csiCacheUpdate_Result}")
							}
                    	}
                    }
				}
			}
		}
//commenting Listservice,Safreplay,DBPRUnner,Scheduler,DataMigrator,FEH,CodeGeneratorService,BlocksBackendService,BlocksService Builds as these repos have git hook enabled and are built with every commit in Develop
/*      
		stage('Build Listservice') {
			agent none
			steps {
				script {
					def ls = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/ListService_Pipeline/develop/',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def lsResult = ls.getResult()
					echo "listmanager build returned result: ${lsResult}"
					if (lsResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("listmanager failed with result: ${lsResult}")
						}                        
					}
				}
			}
		}

		stage('Build Safreplay') {
			agent none
			steps {
				script {
					def saf = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/SAFReplayService_Pipeline/develop',
					propagate: false,
					quietPeriod: 1,
					wait: true
					def srResult = saf.getResult()
					echo "safreplay build returned result: ${srResult}"
					if (srResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("safreplay failed with result: ${srResult}")
						}                        
					} 
				}
			}
		}

        stage('Build BAE- dbp runner and scheduler ') { 
            agent none
            steps {
                script {
                    inventoryName = params.Environment
                    def dbpBuild = build job: 'PRM/Titanium/RA_BAE_develop-Snapshot-Deploy', //war both scheduler and runner
                    propagate: false,
                    quietPeriod: 1,
                    wait: true
                    def dbpResult = dbpBuild.getResult()
                    echo "DBP build returned result: ${dbpResult}"
					if (dbpResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("dbp failed with result: ${dbpResult}")
                       }                         
                    }
                }
            }
        }

        stage('Nexus push DBP-scheduler and dbp-runner') { 
            agent none
            steps {
                script {
                  inventoryName = params.Environment
                    def drPush = build job: 'PRM/Titanium/RA_pipelines/develop/RA_21_Docker-CI-Deploy', // for runner only
                    parameters : [
                        string(name: 'dockerRepoUrl', value: 'ssh://git@bitbucket.am.tsacorp.com:7999/tim/docker-base.git'),
                        string(name: 'dockerBranch', value: 'develop'),
                        string(name: 'raVersion', value: '2.2-SNAPSHOT'),
                        string(name: 'dockerbaseProfileName', value: 'ra'),
                        string(name: 'modules', value: 'dbpscheduler,dbprunner,docker'),
                        booleanParam(name: 'deployToOS', value: false),
                        string(name: 'ocCluster', value: 'ose-dev-cluster'),
                        string(name: 'openShiftProject', value: "frm-${inventoryName}-svc"),
                        string(name: 'openShiftProjectType', value: 'common'),
                        booleanParam(name: 'deployDockerImages', value: true),
                        booleanParam(name: 'updateOSConfiguration', value: false),
                        booleanParam(name: 'cleanWorkspaces', value: false),
                        string(name: 'codeBaseJenkinsBuild', value: 'N/A'),
                        string(name: 'codeBaseGitRepo', value: 'N/A'),
                        string(name: 'codeBaseGitCommitHash', value: 'N/A')
                    ],
                    propagate: false,
                    quietPeriod: 1,
                    wait: true
                    def drResult = drPush.getResult()
                    echo "Nexus push of 'dbp' returned result: ${drResult}"
                    if (drResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("dbp failed with result: ${drResult}")
						}
                    }
                }
            }
        }

        stage('Build   DataMigrator') {
            agent none
            steps {
                script {
                    def dm = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/DataMigratorService_Pipeline/develop',
                    propagate: false,
                    quietPeriod: 1,
                    wait: true
                    def dmResult = dm.getResult()
                    echo "DataMigrator Build returned result: ${dmResult}"
                    if (dmResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("Datamigrator failed with result: ${dmResult}")
							}
                   } 
                }
            }
        }
      
        stage('Build FEH') {
            agent none
            steps {
                script {
                  def feh = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/FeatureCacheEventHandler_Pipeline/develop',
                    propagate: false,
                    quietPeriod: 1,
                    wait: true
                    def fehResult = feh.getResult()
                    echo "FeatureCacheEventHandler build returned result: ${fehResult}"
                    if (fehResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("FeatureCacheEventHandler failed with result: ${fehResult}")
						}                         
                    } 
                }
            }
       }
         
       stage('Build CodeGeneratorService ') {
            agent none
            steps {
                script {
                  def cg = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/CodeGeneratorService_Pipeline/develop',
                    propagate: false,
                    quietPeriod: 1,
                    wait: true
                    def cgResult = cg.getResult()
                    echo "CodeGeneratorService build returned result: ${cgResult}"
                    if (cgResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("CodeGeneratorService failed with result: ${cgResult}")
						}                       
                    } 
                }
            }
       }
      
		stage('Build BlocksBackendService ') {
            agent none
            steps {
                script {
                  def bb = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/BlocksBackendService_Pipeline/develop',
                    propagate: false,
                    quietPeriod: 1,
                    wait: true
                    def bbResult = bb.getResult()
                    echo "BlocksBackendService build returned result: ${bbResult}"
                    if (bbResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("BlocksBackendService failed with result: ${bbResult}")
						}                        
                    } 
                }
            }
		}
     
		stage('Build BlocksService') {
            agent none
            steps {
                script {
                  def bs = build job: 'PRM/Titanium/Micro-Service_Pipelines/Build-pipelines/BlocksService_Pipeline/develop',
                    propagate: false,
                    quietPeriod: 1,
                    wait: true
                    def bsResult = bs.getResult()
                    echo "BlocksService build returned result: ${bsResult}"
                    if (bsResult == 'FAILURE') {
						catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
							error("BlocksService failed with result: ${bsResult}")
						}                        
                    } 
                }
            }
		}
*/      
      	//Currency Conversion commented till it is rationalised
		/*stage('Build CurrencyConverter') { 
            agent none
            steps {
                script {
					if (params.Environment) {
						withCredentials([[$class: 'UsernamePasswordMultiBinding',
							credentialsId: 'bb738c27-a847-4912-b0e0-f3923eef1007', 
							usernameVariable: 'ocUsername', 
							passwordVariable: 'ocpassword'
						]]) 
						{
							def currency = build job: 'Retailers/Merchant Fraud Prevention/ReD Shield/ReDShield_CurrencyConverter-CI-Build',
							parameters : [
								string(name: 'OC_USER', value: ocUsername),
								password(name: 'OC_PWD', value: ocpassword),
								string(name: 'GIT_BRANCH', value: '/*develop')
							],
							propagate: false,
							quietPeriod: 1,
							wait: true
							def Currency_RESULT = currency.getResult()
							echo "currency converter build returned result: ${Currency_RESULT}"
							if (Currency_RESULT == 'FAILURE') {
								catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
									error("CurrencyConverter failed with result: ${Currency_RESULT}")
								}                        
                    		} 
						}
                   }
                }
            }
        }*/
    }
    
    
    post {
        always {  // will perform always and check if the clean dir is set up, then clean workspace
            dir(jobDir) {
                script {
                    deleteDir()
                    println ('The cleanup of workspace is finished')
                }
            }
        }
        failure {  
            emailext (
                    attachLog: true,
                    compressLog: true,
                    to: emailTo,
                    subject: "${currentBuild.currentResult} : ${currentBuild.fullDisplayName}",
                    body: "Build ${currentBuild.fullDisplayName} status: ${currentBuild.currentResult} - ${env.RUN_DISPLAY_URL}"
            )
        }
        success {  // mail to to with success message take from failure section
            emailext (
                    attachLog: true,
                    compressLog: true,
                    to: emailTo,
                    subject: "${currentBuild.currentResult} : ${currentBuild.fullDisplayName}",
                    body: "Build ${currentBuild.fullDisplayName} status: ${currentBuild.currentResult} - ${env.RUN_DISPLAY_URL}"
            )
        }
    }
}

#!/bin/bash
# Description  :This Script is used to monitor the job and whenever job fails auto restart the job.
#
# Modification history:
#
# Date         Author               Description
# ===========  ===================  ============================================
# 04/11/2017   Anand Ayyasamy       Creation
################################################################################

MOVED to generic restart script, Please REMOVE THIS SCRIPT


###APP_NAME="IncrementalTransfJobID-Two"

while true
        do
        st=$(yarn application -appStates RUNNING -list | grep $APP_NAME | awk '{print $2}')

        if [ -z "$st" ]
        then
        echo "\ $APP_NAME is NOT RUNNING, going to start now " | mailx -s " \ $APP_NAME is NOT RUNNING, going to restart now " grp-aci-fp-app-support@aciworldwide.com
          ./TransFlowProcessAction_clientgroup2.sh 
        else
                  echo "\ $APP_NAME is RUNNING, No action required"
        fi

sleep 300
done

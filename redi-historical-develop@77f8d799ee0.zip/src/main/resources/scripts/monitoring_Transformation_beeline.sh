#!/bin/bash
########################################################################################################
# Created / Version :17-NOV-2019 / Initial Draft
# Created By             :      Mayank
# Description : Beeline validation for the transformations
# Modified Version / Modified By / Date
#
########################################################################################################

TIME_DELAY=30m
APP_NAME="Allclientgroup"
CLUSTER_NAME=`hostname`
TABLE_NAME="redi.bi_trans_master_core"

while true
		do
		DATE_BEFORE=`date -u +%Y%m%d`
		COUNT_BEFORE=`beeline -e "select count(1) as count_before from $TABLE_NAME where clientdateyyyymmdd=$DATE_BEFORE;" | sed 's/[^0-9]*//g'`
		echo "sleeping for $TIME_DELAY minutes"
		sleep $TIME_DELAY
		DATE_AFTER=`date -u +%Y%m%d`
		COUNT_AFTER=`beeline -e "select count(1) as count_after from $TABLE_NAME where clientdateyyyymmdd=$DATE_AFTER;" | sed 's/[^0-9]*//g'`
		if [ $COUNT_BEFORE == $COUNT_AFTER ]
		then
			apId=$(yarn application -appStates RUNNING -list | grep $APP_NAME | awk '{print $1}')
			if [ -z "$apId" ]
			then
				echo "Application $APP_NAME is not running in $CLUSTER_NAME, no need to kill"
			else
				echo "transformation is not inserting data for minutes=$TIME_DELAY" | mailx -s " transformation is not inserting data for minutes=$TIME_DELAY in cluster $CLUSTER_NAME, going to Kill it " midhun.polisetty@aciworldwide.com kiruba.venkatesh@aciworldwide.com
				yarn application -kill $apId
			fi
		else
			echo "Transformation is processing the data, no need to restart "
		fi
done

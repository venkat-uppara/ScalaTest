#!/usr/bin/env bash

#----------------------------------------------------------------------------------------------------
# Name          : redi-historical.sh
#
# Purpose       : Used for starting, restarting, stopping and reading status of a given
#                 service (aka job)
#
# App/Services  : HISTORICAL Microservice and Services offered are
#                 historicalfailoverjob
#                 HistoricalIngestionJobID
#                 incrementalfailoverjob
#                 IncrementalTransfJobID
#                 IncrementalIngestionJobID
#                 Allclientgroup
#                 IncrementalTransfJobID-One
#                 IncrementalTransfJobID-Two
#
#----------------------------------------------------------------------------------------------------

# Check arguments
if [[ $# != 3 ]]; then
   echo "Usage: $0 <start/stop> <app version> <job name>"
   echo "Example: $0 start 5.2-SNAPSHOT HistoricalIngestionJobID"
   echo "Example: $0 stop 5.2-SNAPSHOT HistoricalIngestionJobID"
   echo "Example: $0 restart 5.2-SNAPSHOT HistoricalIngestionJobID"
   echo "Example: $0 status 5.2-SNAPSHOT HistoricalIngestionJobID"
   exit 1
fi

# App name and location
appName="$3-$2"
appJAR=/home/srvredi/apps/5.2-SNAPSHOT/redi-historical/redi-historical-$2.jar

CLASSPATH=/apps/ReDi/ReDi_ext_jars/abris_2.11-2.2.2.jar,\
/apps/ReDi/ReDi_ext_jars/avro-1.8.2.jar,\
/apps/ReDi/ReDi_ext_jars/common-config-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/common-metrics-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/common-utils-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-common-impl-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-spec-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-slf4j-adf-log-common-binder-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-testbundles-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-upf-installer-jaxb-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/encryptor-1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-avro-serializer-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-clients-2.1.0-cp2.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-client-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-streams-avro-serde-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/org.osgi.core-4.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/spark-sql-kafka-0-10_2.11-2.3.2.3.1.0.10-1.jar,\
/usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.0.175-5.jar,\
/apps/ReDi/lib/avro-1.8.2.jar,\
/apps/ReDi/lib/log4j-core-2.11.1.jar,\
/apps/ReDi/lib/log4j-api-2.11.1.jar,\
/apps/ReDi/lib/ojdbc6-11.2.0.3.jar,\
/apps/ReDi/lib/config-1.3.2.jar,\
/apps/ReDi/lib/spark-avro_2.11-4.0.0.jar,\
/usr/share/java/kafka-rest/annotations-3.0.1.jar,\
/usr/share/java/kafka-rest/avro-1.8.1.jar,\
/usr/share/java/kafka-rest/commons-compress-1.8.1.jar,\
/usr/share/java/kafka-rest/common-utils-4.1.2.jar,\
/usr/share/java/kafka-rest/jackson-core-asl-1.9.13.jar,\
/usr/share/java/kafka-rest/jackson-mapper-asl-1.9.13.jar,\
/usr/share/java/kafka-rest/jcip-annotations-1.0.jar,\
/usr/share/java/kafka-rest/jline-0.9.94.jar,\
/usr/share/java/kafka-rest/jopt-simple-5.0.4.jar,\
/usr/share/java/kafka-rest/jsr305-3.0.1.jar,\
/usr/share/java/kafka-rest/kafka_2.11-1.1.1-cp1.jar,\
/usr/share/java/kafka-rest/kafka-avro-serializer-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-clients-1.1.1-cp1.jar,\
/usr/share/java/kafka-rest/kafka-json-serializer-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-rest-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-schema-registry-client-4.1.2.jar,\
/usr/share/java/kafka-rest/log4j-1.2.17.jar,\
/usr/share/java/kafka-rest/lz4-java-1.4.1.jar,\
/usr/share/java/kafka-rest/metrics-core-2.2.0.jar,\
/usr/share/java/kafka-rest/netty-3.10.5.Final.jar,\
/usr/share/java/kafka-rest/paranamer-2.7.jar,\
/usr/share/java/kafka-rest/scala-library-2.11.12.jar,\
/usr/share/java/kafka-rest/scala-logging_2.11-3.8.0.jar,\
/usr/share/java/kafka-rest/scala-reflect-2.11.12.jar,\
/usr/share/java/kafka-rest/slf4j-api-1.7.25.jar,\
/usr/share/java/kafka-rest/slf4j-log4j12-1.7.25.jar,\
/usr/share/java/kafka-rest/snappy-java-1.1.7.1.jar,\
/usr/share/java/kafka-rest/xz-1.5.jar,\
/usr/share/java/kafka-rest/zkclient-0.10.jar,\
/usr/share/java/kafka-rest/zookeeper-3.4.10.jar,\
/usr/share/java/confluent-common/build-tools-4.1.0.jar,\
/usr/share/java/confluent-common/common-config-4.1.0.jar,\
/usr/share/java/confluent-common/common-metrics-4.1.0.jar,\
/usr/share/java/confluent-common/common-utils-4.1.0.jar,\
/usr/share/java/confluent-common/jline-0.9.94.jar,\
/usr/share/java/confluent-common/log4j-1.2.17.jar,\
/usr/share/java/confluent-common/netty-3.10.5.Final.jar,\
/usr/share/java/confluent-common/slf4j-api-1.7.25.jar,\
/usr/share/java/confluent-common/zkclient-0.10.jar,\
/usr/share/java/confluent-common/zookeeper-3.4.10.jar,\
/apps/ReDi/lib/ReDi_common-5.2-SNAPSHOT.jar

## Default config
driverMemory=4G
executorMemory=6G
numberOfExecutors=8
executorCores=1
queueName=ReDi-Batch
keyTab=/etc/security/keytabs/srvredi.keytab
principal=srvredi@IPA.AM.TSACORP.COM
jaasConf=/etc/security/keytabs/jaas.conf
certs=
kafkaKeytabs=
encryptor=/apps/ReDi/conf/encryptor.properties
appConfig=/apps/ReDi/Wave1/application.conf
extraConf=
log4j=

className=com.aciworldwide.ra.redi.rstransflow.actions.TransFlowProcessAction
if [[ $3 == "historicalfailoverjob" ]]; then
   className=com.aciworldwide.ra.redi.rstransflow.actions.HistoricalTransFlowFailedAction
   executorMemory=19G
   executorCores=2
   kafkaKeytabs=
   encryptor=
   appConfig=
fi

if [[ $3 == "HistoricalIngestionJobID" ]]; then
   className=com.aciworldwide.ra.redi.rstransflow.actions.HistoricalRSExecIngestProcess
   executorMemory=12G
   numberOfExecutors=2
   executorCores=5
   queueName=ReDi-Stream
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=false --conf spark.datasource.hive.warehouse.use.spark23x.specific.reader=true --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties" "
fi

if [[ $3 == "IncrementalIngestionJobID" ]]; then
   className=com.aciworldwide.ra.redi.rstransflow.actions.RSExecIngestProcess
   driverMemory=8G
   executorMemory=24G
   numberOfExecutors=2
   executorCores=5
   queueName=ReDi-Stream
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf spark.datasource.hive.warehouse.use.spark23x.specific.reader=false --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties" --conf spark.cleaner.ttl=3600 --conf spark.yarn.submit.waitAppCompletion=false"
   log4j=/apps/ReDi/log4j.properties 
fi

if [[ $3 == "incrementalfailoverjob" ]]; then
   className=com.aciworldwide.ra.redi.rstransflow.actions.TransFlowFailedAction
   executorMemory=19G
   executorCores=2
   log4j=
   encryptor=
   kafkaKeytabs=
   appConfig= 
fi

if [[ $3 == "IncrementalTransfJobID" ]]; then
   executorMemory=19G
   executorCores=2
   queueName=ReDi-Stream
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true "
   log4j=
   encryptor=
   kafkaKeytabs=
   appConfig= 
fi

if [[ $3 == "IncrementalTransfJobID-One" ]]; then
   driverMemory=20G
   executorMemory=20G
   numberOfExecutors=4
   executorCores=8
   queueName=ReDi-Stream
   name="clientgroup1"
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties" --conf spark.hive.vectorized.execution.enabled=false --conf spark.network.timeout=600s --conf spark.task.maxFailures=8"
   log4j=
   kafkaKeytabs=
   jaasConf=
   certs=
fi

if [[ $3 == "IncrementalTransfJobID-Two" ]]; then
   driverMemory=20G
   executorMemory=20G
   numberOfExecutors=4
   executorCores=8
   queueName=ReDi-Stream
   name="clientgroup2"
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties" --conf spark.hive.vectorized.execution.enabled=false --conf spark.network.timeout=600s --conf spark.task.maxFailures=8"
   log4j=
   kafkaKeytabs=
   jaasConf=
   certs=
fi

if [[ $1 == "start" ]] || [[ $1 == "restart" ]]; then
    # Spark submit
    applicatonID=$(yarn application -appStates RUNNING -list|grep $appName|awk '{print $1}')
    if [ -z "$applicatonID" ]; then
       echo "Starting application: $appName"
       spark-submit --master yarn \
       --name $appName \
       --driver-memory $driverMemory \
       --executor-memory $executorMemory \
       --num-executors $numberOfExecutors  \
       --executor-cores $executorCores  \
       --queue $queueName \
       --deploy-mode cluster \
       --keytab $keyTab \
       --principal $principal \
       --conf spark.memory.fraction=0.8  \
       --conf spark.scheduler.maxRegisteredResourcesWaitingTime=60s \
       --conf spark.security.credentials.hiveserver2.enabled=false \
       --conf "spark.driver.extraJavaOptions=-Duser.timezone=UTC -Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=schema_keystore.jks" \
       --conf "spark.executor.extraJavaOptions=-Duser.timezone=UTC -Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=schema_keystore.jks" \
       --conf spark.driver.extraClassPath="/usr/hdp/current/spark2-client/jars/ojdbc6-11.2.0.3.jar,./application.conf,./encryptor.properties" \
       --conf spark.yarn.submit.waitAppCompletion=false \
       --files "$encryptor,$jaasConf,$certs,$kafkaKeytabs,$appConfig,$log4j" \
       --jars $CLASSPATH \
       --class $className $appJAR
       exit $?
    else
       echo 'Application is already RUNNING and ID='$applicatonID
       exit 0
    fi
fi

if [[ $1 == "stop" ]]; then
    # Yarn kill
    echo "Stopping job: $appName"
    yarn application -appStates RUNNING -list | grep $appName | awk '{print $1}' | while read app; do echo "yarn application -kill $app";yarn application -kill $app; done;
    exit $?
fi

if [[ $1 == "status" ]]; then
    ## read status:  0 - FINISHED, 1 - RUNNING, 2 - FAILED

    echo "Reading job status: $appName"
    statusValue=0
    applicatonID=$(yarn application -appStates RUNNING -list|grep $appName|awk '{print $1}')
    if [ -n "$applicatonID" ]; then
       echo 'Application is RUNNING and ID='$applicatonID
       statusValue=1
    else
       applicatonID=$(yarn application -appStates FAILED -list|grep $appName|awk '{print $1}')
       if [ -n "$applicatonID" ]; then
          echo 'Application is FAILED and ID='$applicatonID
          statusValue=2
       fi
    fi

    exit $statusValue
fi

# done!


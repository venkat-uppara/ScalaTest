package com.aciworldwide.ra.redi.rstransflow.services


/**
  * @author : Mayank M 08.08.2018
  * This method is used to deserialize data(which comes as Byte Array from the topic).
  * First bytes will be converted into values and values will be mapped to the respective columns
  * Mapping requires schema which can get retrieved from class created using .avsc file provided

  */

trait ReDiSerializers {


  /**
    * @author : Mayank M 08.08.2018
    * This method is used to deserialize data(which comes as Byte Array from the topic).
    * First bytes will be converted into values and values will be mapped to the respective columns
    * Mapping requires schema which can get retrieved from class created using .avsc file provided
    * Takes Array of Bytes as input parameters
    */
/*  private def deserialize(bytes: Array[Byte]) = {

    val trans = new ReDShieldTransaction

    val datumReader: SpecificDatumReader[ReDShieldTransaction] =
      new SpecificDatumReader[ReDShieldTransaction](trans.getSchema)
    val decoder: Decoder = DecoderFactory.get.binaryDecoder(bytes, null)

    var result: ReDShieldTransaction = null

    try {
      result = datumReader.read(null, decoder)
    } catch {
      case e: IOException => e.printStackTrace()
    }
    result.toString
  }*/

}

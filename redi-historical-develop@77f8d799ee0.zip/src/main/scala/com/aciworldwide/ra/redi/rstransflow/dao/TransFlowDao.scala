package com.aciworldwide.ra.redi.rstransflow.dao

import com.aciworldwide.ra.redi.bi.models.coretrans.CoreTransaction
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.rstransflow.actions.RSExecIngestProcess.logRegularMessage
import com.fasterxml.jackson.databind.{DeserializationFeature, ObjectMapper}
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions.{struct, to_json}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, SparkSession}
import za.co.absa.abris.avro.AvroSerDe._
import za.co.absa.abris.avro.read.confluent.SchemaManager
import za.co.absa.abris.avro.schemas.policy.SchemaRetentionPolicies.RETAIN_SELECTED_COLUMN_ONLY

class TransFlowDao(sc: SparkSession) extends Serializable with ReDiConstants {

    //  val hive = HiveWarehouseSession.session(sc).build()
    //  hive.setDatabase(MAINFLOW_DATABASE)

    //constants
    val TOPIC = "topic"
    val KAFKA_PREFIX="kafka."

    val schemaRegistryConfs = Map(
        SchemaManager.PARAM_SCHEMA_REGISTRY_URL -> ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"),
        SchemaManager.PARAM_SCHEMA_REGISTRY_TOPIC -> ConfigFactory.load().getString("local.common.kafka.schemaRegistryTopicName"),
        SchemaManager.PARAM_VALUE_SCHEMA_NAMING_STRATEGY -> SchemaManager.SchemaStorageNamingStrategies.TOPIC_NAME, // choose a subject name strategy
        SchemaManager.PARAM_VALUE_SCHEMA_ID -> "latest" // set to "latest" if you want the latest schema version to used
    )

    @transient lazy val mainIngestionDatalogger = LogManager.getLogger(getClass.getName)

    def readTransactionsFromKafka(): DataFrame = {
        mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":read stream for the MircoBatch started")
        sc
          .readStream
          .format(KAFKA_SOURCE)
          .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
          .option(SUBSCRIBE, ConfigFactory.load().getString("local.common.kafka.transactionkafkatopic"))
          .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.kafka.maxOffsetsPerTrigger"))
          .option("failOnDataLoss", "false")
          .option("startingOffsets", "latest")
          .option(KAFKASECURITYPROTOCOL, SASL_SSL)
          .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
          .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
          .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
          .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
          .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
          .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
          .option(KAFKASASLMECHANISM, GSSAPI)
          .load()
          .fromConfluentAvro("value", None, Some(schemaRegistryConfs))(RETAIN_SELECTED_COLUMN_ONLY) // invoke the library passing over parameters to access the Schema Registry
    }


    def WriteTransactionData(df: DataFrame): Unit = {
        mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":Write stream for the MircoBatch started")
        try {
            df
              .writeStream
              .format(HiveWarehouseSession.STREAM_TO_STREAM)
              .trigger(Trigger.ProcessingTime(ConfigFactory.load().getString("local.common.kafka.processingTime")))
              .option(DATABASE, MAINFLOW_DATABASE)
              .option(TABLE, ConfigFactory.load().getString("local.common.kafka.HiveSinkTableCore"))
              .option(METASTOREURI, ConfigFactory.load().getString("local.common.kafka.metastoreUri"))
              .option(KAFKA_CHECKPOINT_LOCATION, ConfigFactory.load().getString("local.common.kafka.transactiontopicCheckpointlocationCore"))
              .start()
              .awaitTermination()
        }
        catch {
            case e: Throwable => logRegularMessage("We have an error in in writing the writing the records to Hive tables" + e)
        }
        mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":read stream for the MircoBatch ended")

    }

    /**
      * This fuction will send the required transactions to kafka
      * @param bTDf
      */

    def sendMsg2Kafka(bTDf: DataFrame): Unit = {
        import sc.implicits._
        val param: Map[String, String] = getPropertiesMap
        bTDf
          .na.fill("")
          .select(to_json(struct("*")) as "value")
          .mapPartitions {
              itr => {
                  itr.map {
                        data => enfrcSchema(data.mkString)
                  }
              }
          }
          .writeStream
          .format("kafka")
          .options(param)
          .start()
          .awaitTermination()

    }

    def enfrcSchema(kafkaMsg: String) ={
        val mapper = new ObjectMapper()
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
        val enfrData = mapper.readValue(kafkaMsg, classOf[CoreTransaction])
        mapper.writeValueAsString(enfrData)
    }

    /**
      *
      * @return
      */
    def getPropertiesMap = {

        val params = Map[String, String](
            KAFKA_BOOTSTRAP_SERVERS -> ConfigFactory.load().getString("local.common.kafka.bootstrapservers"),
            TOPIC -> ConfigFactory.load().getString("local.common.kafka.kafkabasetopic"), //change in application.con
            KAFKA_CHECKPOINT_LOCATION -> ConfigFactory.load().getString("local.common.kafka.basetopicCheckpointlocationCore"), //change in application.con
            KAFKASECURITYPROTOCOL -> SASL_SSL,
            KAFKASSLKEYSTORELOCATION -> ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"),
            KAFKASSLKEYSTOREPASSWORD -> ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"),
            KAFKASSLTRUSTSTORELOCATION -> ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"),
            KAFKASSLTRUSTSTOREPASSWORD -> ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"),
            KAFKASSLKEYPASSWORD -> ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"),
            KAFKASASLKERBEROSSERVICENAME -> KAFKA,
            KAFKASASLMECHANISM -> GSSAPI,
            KAFKA_PREFIX+ProducerConfig.COMPRESSION_TYPE_CONFIG -> ConfigFactory.load().getString("local.common.kafka.compressionType")
        )

        params
    }





    def gettheDataFromHive(sc: SparkSession, tablename: String): DataFrame = {
        val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sc).build()
        hiveSession.executeQuery(s"select * from $tablename")
    }

    /**
      * The procedure for fetching country dimension -- MERF-9239
      */

    def getCountryDimension(tablename: String): DataFrame = {
        gettheDataFromHive(sc, tablename)
    }

    def getCurrencyRates(tablename: String): DataFrame = {
        gettheDataFromHive(sc, tablename)
    }
}


/**
  * @author : Hariprasad allaka
  * @version : 1.0
  * @usecase : Common Utilities for RSTrans flow
  */
package com.aciworldwide.ra.redi.rstransflow.utils


import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import com.typesafe.config.ConfigFactory
import java.util.NoSuchElementException

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import org.apache.spark.sql.functions.{current_timestamp, lit}
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SparkSession}


trait RSTransFlowCommonUtils extends Serializable with EstablishConnections with Loggers with ReDiConstants {

  /**
    * @author: Hariprasad Allaka
    * @note : MERF-8357:Utility to convert the currency amount based on the source and destination using
    *       USD rate details.
    *
    */


  def addtransflowAuditColumns(inputdataFrame: DataFrame): DataFrame = {
    val outputDataFrame = inputdataFrame
      //.withColumn(WHENLOADED, current_timestamp())
      .withColumn(WHOLOADED, lit(WHO_LOADED_UPDATED_INSERT))
      .withColumn(WHENUPDATED, current_timestamp())
      .withColumn(WHOUPDATED, lit(WHO_LOADED_UPDATED_INSERT))
    outputDataFrame
  }

  def convertCurrency(sc: SparkSession, convrates: DataFrame, sourceCurrency: String, destcurrency: String, noOfUnits: Double): Double = {

    var convertedCurrency: Double = 0.0
    try {
      convrates.createOrReplaceTempView("convratesview")
    }
    catch {
      case e: NoSuchElementException =>
        logRegularMessage("There is an error in fetching the rates for the input date and currency " + e)
    }

    val sourceconvrate = sc.sql(s"select ConversionRate from convratesview where DestCurrencyCode=\'$sourceCurrency\'").head().getDouble(0)
    val destconvrate = sc.sql(s"select ConversionRate from convratesview where DestCurrencyCode=\'$destcurrency\'").head().getDouble(0)

    convertedCurrency = ((1 / sourceconvrate) * destconvrate) * noOfUnits
    convertedCurrency

  }


  def cardlength(cardNo: String): Int = {
    val cardLength = cardNo.trim.length
    cardLength
  }

}
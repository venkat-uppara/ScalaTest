package com.aciworldwide.ra.redi.rstransflow.actions

import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.rstransflow.controllers.TransFlowFailedController
import org.apache.logging.log4j.LogManager

object TransFlowFailedAction extends TransFlowFailedController with EstablishConnections with Loggers with Serializable {
  @transient lazy val transFlowFailedLogger = LogManager.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    try {
      failedTransFlowProcesTransformations()
    } catch {
      case e: Exception => transFlowFailedLogger.error(TRANSFLOWPROCESS_ERROR + ": We have an error in the fail over  Transformation Process")
        e.printStackTrace()
    } finally {
      transFlowFailedLogger.error(TRANSFLOWPROCESS_ERROR + ": End of Transformation Process for incremental fail over ")
    }

  }

}

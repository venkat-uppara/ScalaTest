package com.aciworldwide.ra.redi.rstransflow.schemas

case class ReDiTransaction(Oid: String,
                           OidDate: String,
                           ClientId: String,
                           SubclientId: String,
                           BillCountry: String,
                           BillZipcd: String,
                           BillCity: String,
                           BillAddress2: String,
                           BillStreet: String,
                           BillState: String,
                           ShipCountry: String,
                           VirtIpidCountryEbg: String,
                           VirtBin: String,
                           VirtIovCntryCd: String
                          )

package com.aciworldwide.ra.redi.rstransflow.controllers

import java.text.{DateFormat, SimpleDateFormat}
import java.time.Instant
import java.util.Calendar

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.rstransflow.services.ReDiSerializers
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession._
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.{DateTime, DateTimeZone}
import org.joda.time.format.DateTimeFormat

/* POC cluster related imports */


import scala.util.control.Breaks._

class HistoricalTransFlowController extends BaseController with ReDiConstants with Loggers with ReDiSerializers with ReDiTableSchemas {

  @transient lazy val transDataFlowLogger = LogManager.getLogger(getClass.getName)

  val sparkSession: SparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)


  val transMasterCore = new TransCoreController(sparkSession)
  val detail = new TransDetailController(sparkSession)
  val common = new TransCommonController(sparkSession)
  val ruleHits = new TransRuleHitsController(sparkSession)
  val dependent = new TransDependencyController(sparkSession)
  val historicalCurr = new HistoricalTransCommonCurrController(sparkSession)
  var flags = new Array[Boolean](3)

  val localtimezone: String = ConfigFactory.load().getString("local.common.serverConfig.localtimezone")
  val jobidFilter: String = ConfigFactory.load().getString("local.common.historical_transflow.jobidFilter")
  var clientFilter: String = ConfigFactory.load().getString("local.common.historical_transflow.clientFilter")
  val sourceFilter: String = ConfigFactory.load().getString("local.common.historical_transflow.sourceFilter")
  val durationFilter: String = ConfigFactory.load().getString("local.common.historical_transflow.durationFilter")

  if (clientFilter != null && !clientFilter.trim.isEmpty) {
    clientFilter = "and " + clientFilter + " "
  }
  else {
    clientFilter = ""
  }


  val simpleformat = new SimpleDateFormat(TARGDATEFORMAT)

  import sparkSession.implicits._

  def HistoricaltransFlowProcesTransformations(): Unit = {

    def fn_currenttime_utc(): String = {
      val dates = DateTime.now(DateTimeZone.UTC)
      val dateOut = DateTimeFormat.forPattern(TARGDATEFORMAT)
      dateOut.print(dates)
    }

    def fn_diff_millisec(currTime: String, endTime: String): Long = {
      val ct = java.sql.Timestamp.valueOf(simpleformat.format(simpleformat.parse(currTime)))
      val et = java.sql.Timestamp.valueOf(simpleformat.format(simpleformat.parse(endTime)))
      et.getTime - ct.getTime
    }

    var nextRunWithoutError = true
    while (nextRunWithoutError) {
      val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sparkSession).build()
      hiveSession.setDatabase(REDI_DATABASE)
      var status: String = "Success"
      var rows_count: Long = 0
      var strDate: Long = 0
      var strDate1: Long = 0
      var rowsDf: DataFrame = null
      var dateFormat: DateFormat = null
      var dateFmt: String = "yyyyMMddHHmmss"
      var sdf = new SimpleDateFormat(dateFmt)
      var dateFmt1: String = "yyyyMMdd"
      var sdf1 = new SimpleDateFormat(dateFmt1)

      try {
        breakable {
          var startTimeFromDf: DataFrame = hiveSession.executeQuery(s"select max(lastusedtime) as lastusedtime ," + // 9.10
            s"'$jobidFilter' as jobid from " + HIST_REDI_CONTROL_FOR_EXTERNAL_TABLE + s" where jobid = '$jobidFilter'")

          startTimeFromDf = startTimeFromDf.withColumn("whenloadedyyyymmdd", date_format($"lastusedtime", "yyyyMMdd"))
            .withColumn("whenloadedhh", date_format($"lastusedtime", "HH"))

          var startTime1 = startTimeFromDf.select($"lastusedtime").first()(0)

          if (startTime1 == null) {
            transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": No records inserted in hist_controlfortransflow: Please insert the records in hist_controlfortransflow")
            throw new Exception("No records inserted in hist_controlfortransflow: Please insert the records in hist_controlfortransflow")

          }
          val startTime = startTime1.toString.trim

          var whenloadedyyyymmddStart = startTimeFromDf.select($"whenloadedyyyymmdd").first()(0).toString.trim
          var whenloadedhhStart = startTimeFromDf.select($"whenloadedhh").first()(0).toString.trim

          var endTimeFromDf = startTimeFromDf.select(($"lastusedtime" + expr(durationFilter)).as("lastusedtime")) //9.20
            .select($"lastusedtime", date_format($"lastusedtime", "yyyyMMdd").as("whenloadedyyyymmdd"),
            date_format($"lastusedtime", "HH").as("whenloadedhh"))

          val endTime = endTimeFromDf.select($"lastusedtime").first()(0).toString.trim
          val whenloadedyyyymmddEnd = endTimeFromDf.select($"whenloadedyyyymmdd").first()(0).toString.trim
          val whenloadedhhEnd = endTimeFromDf.select($"whenloadedhh").first()(0).toString.trim.toInt


          // strDate is required in below logic on adding Audit data
          strDate = Instant.now().toEpochMilli

          transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": JobID : " + jobidFilter + " From time: " + startTime + " to time: " + endTime)
          transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Start of Micro batch : " + Calendar.getInstance.getTime)

          val currentTime = fn_currenttime_utc()

          if (currentTime < endTime) {
            transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Current time " + currentTime + " is less than batch endtime. Waiting till endtime... ")
            val diff = fn_diff_millisec(currentTime, endTime) + 60000 // adding one minute buffer interval to ensure ingestion completes writing
            Thread.sleep(diff)
            transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Wait period over. Continuing the batch.")
          }

          var whenloadedHH=""
          if(whenloadedyyyymmddStart.equalsIgnoreCase(whenloadedyyyymmddEnd))
            {
              whenloadedHH=" and  whenloadedhh >="+whenloadedhhStart+" and whenloadedhh<="+whenloadedhhEnd+" "
            }
          else
          {
            whenloadedHH=""
          }

          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Query : "+ s"select oid, oiddate, oiddateyyyymmdd, whenloaded, ProductDetail, clientId, subClientId, currCd, total, VirtUsdTotal, CardNo, RuleMaster, clientdate, subclientdate from " + HIST_TRANS_MASTER_CORE_BASE + s" where whenloadedyyyymmdd >='$whenloadedyyyymmddStart' " +
            s"and whenloadedyyyymmdd <='$whenloadedyyyymmddEnd' " +whenloadedHH+ " and " +
            s" whenloaded > '$startTime' and whenloaded <= '$endTime' " + clientFilter + "")

          rowsDf = hiveSession.executeQuery(s"select oid, oiddate, oiddateyyyymmdd, whenloaded, ProductDetail, clientId, subClientId, currCd, total, VirtUsdTotal, CardNo, RuleMaster, clientdate, subclientdate from " + HIST_TRANS_MASTER_CORE_BASE + s" where whenloadedyyyymmdd >='$whenloadedyyyymmddStart' " +
            s"and whenloadedyyyymmdd <='$whenloadedyyyymmddEnd' " +whenloadedHH+ " and " +
            s" whenloaded > '$startTime' and whenloaded <= '$endTime' " + clientFilter + "")

          /*          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + s"select * from " + HIST_TRANS_MASTER_CORE_BASE + s" where whenloadedyyyymmdd >='$whenloadedyyyymmddStart' " +
                      s"and whenloadedyyyymmdd <='$whenloadedyyyymmddEnd' and  whenloadedhh >='$whenloadedhhStart' " +
                      s"and whenloadedhh<='$whenloadedhhEnd' and  whenloaded > '$startTime' and whenloaded <= '$endTime' "+clientFilter+"") */

          rows_count = rowsDf.count

          transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Number of input rows from source : " + rows_count)

          if (rows_count > 0) {

            val FailedBatchDF: DataFrame = Seq(startTime).toDF()
              .withColumn("endtime", lit(endTime))
              .withColumn("jobid", lit(jobidFilter))
              .withColumn("datasource", lit(sourceFilter))
              .withColumn("jobstatus", lit("UNPROCESSED"))
              .withColumn("clientid", lit(clientFilter))
              .withColumn("noofretries", lit(0))

            /* Step-01: Transformation of Exec Data - Deriving common transformations required for all other controllers*/
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Common Transformations")
            val commondf = common.processCommonTransformation(rowsDf,historicalCurr)
//            commondf = historicalCurr.currencyConversion(commondf)
            commondf.persist()
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Common Transformations")



            /* Step-03: Transaction Details data transformations */
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Details Transformations")
            val detaildf = detail.processTransDetail(commondf)
            detaildf.persist() // Persisting the data from transaction details for using it in dependency transformations
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Details Transformations")

            /* Step-04: Transaction Rule Hits data transformations */
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Rule Hits Transformations")
            val ruleHitsdf = ruleHits.processRuleHits(commondf)
            ruleHitsdf.persist() // Persisting the data from transaction rule hits for using it in dependency transformations
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Rule Hits Transformations")

            val commondf1 = commondf.select($"oid", $"oiddate".as("oiddateintimestamp"), $"DetailLines", $"DetailLinesBand", $"DetailLinesBandDesc", $"Region", $"ClientName", $"SubClientName", $"ClientGroup", $"PSP_GROUP", $"ClientSet", $"Client12", $"CURRCLIENT", $"CURRSUBCLIENT", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient", $"cardnomask", $"ClientDateYYYYMMDD", $"SubClientDateYYYYMMDD", $"WhoLoaded", $"WhenUpdated", $"WhoUpdated")
            //val hiveSessionCore: HiveWarehouseSession = HiveWarehouseSession.session(sparkSession).build()
            val rows1: DataFrame = hiveSession.executeQuery(s"select * from " + HIST_TRANS_MASTER_CORE_BASE + s" where whenloadedyyyymmdd >='$whenloadedyyyymmddStart' " +
              s"and whenloadedyyyymmdd <='$whenloadedyyyymmddEnd' and  whenloadedhh >='$whenloadedhhStart' " +
              s"and whenloadedhh<='$whenloadedhhEnd' and  whenloaded > '$startTime' and whenloaded <= '$endTime' " + clientFilter + "")
              .withColumnRenamed("wholoaded", "wholoaded_source")
              .withColumnRenamed("whenupdated", "whenupdated_source")
              .withColumnRenamed("whoupdated", "whoupdated_source")

            val rows2 = rows1.join(commondf1, Seq("oid")).drop("wholoaded_source").drop("whenupdated_source").drop("whoupdated_source")
              .drop($"oiddate").withColumnRenamed("oiddateintimestamp","oiddate")
            /* Step-02: Transaction Master Core data transformations */
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Master Core Transformations")
            val coredf = transMasterCore.processTransMasterCore(rows2)
            coredf.persist() // Persisting the data from transaction master for using it in dependency transformations
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Master Core Transformations")
            /* Step-05: Dependent data transformations  -- Dependent transformations are those that requires data from other tables in order to do a transformation */
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Dependent Transformations")
            val finaldataFrame = dependent.processDependencies(coredf, detaildf, ruleHitsdf, hiveSession)
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Dependent Transformations")


            /* Step-05(a): Storing data into Transaction Master Hive table (BI_TRANS_MASTER_CORE) */
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Master Core data into Hive")
            try {
              dependent.StoreDateToHive(DBNAME, BI_TRANS_MASTER_CORE, APPEND_MODE, finaldataFrame("Trans_master"))
            } catch {
              case e: Exception =>
                transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Master core dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
                dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_MAINFLOW_FAILOVER, APPEND_MODE, FailedBatchDF)
                transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Batch unprocessed info saved in control_fail table, let's go to next batch ")
                dependent.StoreDateToHive(DBNAME, HIST_REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, Seq(endTime).toDF().withColumn("jobid", lit(jobidFilter)))
                break
            }

            /* Step-05(b): Storing data into Transaction Details Hive table (BI_TRANS_DETAIL) */
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Detail data into Hive")
            try {
              dependent.StoreDateToHive(DBNAME, BI_TRANS_DETAILS, APPEND_MODE, finaldataFrame("Trans_detail"))
            } catch {
              case e: Exception =>
                transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Details dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
                dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_MAINFLOW_FAILOVER, APPEND_MODE, FailedBatchDF)
                transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Batch unprocessed info saved in control_fail table, let's go to next batch ")
                dependent.StoreDateToHive(DBNAME, HIST_REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, Seq(endTime).toDF().withColumn("jobid", lit(jobidFilter)))
                break
            }

            /* Step-05(c): Storing data into Transaction Rule Hits Hive table (BI_TRANS_RULE_HITS) */
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Rule Hits data into Hive")
            try {
              dependent.StoreDateToHive(DBNAME, BI_TRANS_RULE_HITS, APPEND_MODE, finaldataFrame("Rule_hits"))
            } catch {
              case e: Exception =>
                transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Rule Hits dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
                dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_MAINFLOW_FAILOVER, APPEND_MODE, FailedBatchDF)
                transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Batch unprocessed info saved in control_fail table, let's go to next batch ")
                dependent.StoreDateToHive(DBNAME, HIST_REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, Seq(endTime).toDF().withColumn("jobid", lit(jobidFilter)))
                break
            }

            val EndTimeFromNew: DataFrame = Seq(endTime).toDF("lastUsedTime").withColumn("jobid", lit(jobidFilter))


            dependent.StoreDateToHive(DBNAME, HIST_REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, EndTimeFromNew)

            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Last time used is being inserted")
          }
          else {
            transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": There were no data from source")
            val EndTimeNoRecords: DataFrame = Seq(endTime).toDF("lastUsedTime").withColumn("jobid", lit(jobidFilter))
            dependent.StoreDateToHive(DBNAME, HIST_REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, EndTimeNoRecords)
          }
        }
        strDate1 = Instant.now().toEpochMilli
        transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": End of Micro batch : " + Calendar.getInstance.getTime)
        //nextRunWithoutError = false
        hiveSession.close()
      }
      catch {

        case e: Exception => {
          status = "Failed"
          rows_count = 0

          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + "cache End of Micro batch : " + status)


          val Microbatchend = Calendar.getInstance.getTime

          strDate1 = Instant.now().toEpochMilli
          throw e
        }

      }
      finally {

        if (rows_count > 0) {

          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + "inside finally block :  ")

          val fromdate = rowsDf.agg(min($"oidDate")).collect().map(x => x.getString(0)).mkString("")

          val parsefromdate = sdf.parse(fromdate)
          val Fromdate: Long = parsefromdate.getTime

          val todate = rowsDf.agg(max($"oidDate")).collect().map(x => x.getString(0)).mkString("")
          val parsetodate = sdf.parse(todate)
          val Todate: Long = parsetodate.getTime
          val clientid = rowsDf.select("ClientId").groupBy("ClientId").agg(count("ClientId").as("TOTALRECORDS"))


          val currentuser = System.getProperty("user.name")

          val Timetaken = strDate1 - strDate

          val strdate5 = Calendar.getInstance.getTime
          val completeddt = sdf1.format(strdate5)

          val rows1 = rowsDf.withColumn("Process", lit("Mainflow"))
            .withColumn("Stage", lit("Historical Ingestion"))
            .withColumn("ClientId", lit($"ClientId"))
            .withColumn("Fromdate", lit(Fromdate))
            .withColumn("Todate", lit(Todate))
            .withColumn("whenrun", lit(strDate))
            .withColumn("whencompleted", lit(strDate1))
            .withColumn("Whorun", lit(currentuser))
            .withColumn("Timetaken", lit(Timetaken))
            .withColumn("status", lit(status))
            .withColumn("CompletedYYYYMMDD", lit(completeddt))
          //.withColumn("CompletedYYYYMMDD", lit($"whencompleted"))


          val clientJoinRdd = rows1.join(clientid, Seq("ClientId"))


          val rows2 = clientJoinRdd.select($"Process", $"Stage", $"ClientID", $"Fromdate", $"Todate", $"whenrun", $"whencompleted", $"Whorun",
            $"Timetaken", $"TOTALRECORDS", $"status", $"CompletedYYYYMMDD").dropDuplicates()
          //rows2.show(false)


          def StoreauditdataintoHive(inputdataset: DataFrame): Unit = {
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + "Starting to push the data into Hive table " + TRANS_FLOW_AUDIT_TABLE)
            inputdataset
              .write
              .format(HIVE_WAREHOUSE_CONNECTOR)
              .option("database", REDI_DATABASE)
              .mode(APPEND_MODE)
              .option("table", TRANS_FLOW_AUDIT_TABLE)
              .save()
            transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + "Number of rows inserted in Trans Audit table: " + rows_count)
          }

          StoreauditdataintoHive(reorderSourceTableSchema(TRANS_FLOW_AUDIT_TABLE_COL_ORDER, rows2))
        }
      }
    }
  }
}



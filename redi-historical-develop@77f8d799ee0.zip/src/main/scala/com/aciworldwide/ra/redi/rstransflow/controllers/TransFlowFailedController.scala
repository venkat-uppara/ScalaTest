package com.aciworldwide.ra.redi.rstransflow.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.common.utils.DateUtils
import com.aciworldwide.ra.redi.rstransflow.services.ReDiSerializers
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.util.control.Breaks.{break, breakable}

class TransFlowFailedController extends BaseController with ReDiConstants with Loggers with ReDiSerializers {

  @transient lazy val transDataFlowLogger = LogManager.getLogger(getClass.getName)


  val sparkSession: SparkSession = createSparkSession("RStransFlowFailedtransformation")
  val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sparkSession).build()
  val transMasterCore = new TransCoreController(sparkSession)
  val detail = new TransDetailController(sparkSession)
  val common = new TransCommonController(sparkSession)
  val ruleHits = new TransRuleHitsController(sparkSession)
  val dependent = new TransDependencyController(sparkSession)
  val sourceFilter: String = ConfigFactory.load().getString("local.common.realtime_transflow.sourceFilter")
  val dateUtil = new DateUtils
  val historicalCurr: HistoricalTransCommonCurrController = new HistoricalTransCommonCurrController(sparkSession)


  import sparkSession.implicits._

  def failedTransFlowProcesTransformations(): Unit = {
    breakable {
      var failDf = hiveSession.executeQuery(s"select starttime,endtime,clientid,jobid,noofretries,datasource,jobstatus from "
        + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + s" where datasource = '$sourceFilter' and jobstatus='UNPROCESSED' and noofretries<=2  order by starttime asc ")

      var startTime: String = null
      var endTime: String = null
      var clientId: String = ""
      var clientFilter: String = ""
      var jobId: String = null
      var noOfRetries = 0

      for (row <- failDf.rdd.collect) {
        startTime = row.mkString(",").split(",")(0)
        endTime = row.mkString(",").split(",")(1)
        clientId = row.mkString(",").split(",")(2)
        jobId = row.mkString(",").split(",")(3)
        noOfRetries = row.mkString(",").split(",")(4).toInt

        transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + " Inside For Loop " + clientId)

        var partColStart = dateUtil.convertDateFormat(startTime, TARGDATEFORMAT, "yyyyMMdd").toString.trim.toInt-1
        var partColEnd = dateUtil.convertDateFormat(endTime, TARGDATEFORMAT, "yyyyMMdd").toString.trim.toInt+1

        if (clientId != null  && !clientId.equalsIgnoreCase("null") && !clientId.trim.isEmpty) {
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + " Inside If condition")
          clientFilter = clientId
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + " Inside If condition " + clientFilter)
        }
        else {
          clientFilter = ""
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + " Inside else condition " + clientFilter)
        }
        transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Updatetosuccess " + startTime + " " + endTime)

        transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + s"select oid, oiddate, oiddateyyyymmdd, whenloaded, ProductDetail, " +
          s"clientId, subClientId, currCd, total, VirtUsdTotal, CardNo, RuleMaster, clientdate, subclientdate " +
          s"from " + TRANS_MASTER_CORE_BASE + s" where oiddateyyyymmdd between '$partColStart' and '$partColEnd'  and " +
          s" whenloaded > '$startTime' and whenloaded <= '$endTime' " +
          clientFilter + s" and datasource = '$sourceFilter'")


        val rows: DataFrame = hiveSession.executeQuery(s"select oid, oiddate, oiddateyyyymmdd, whenloaded, ProductDetail, " +
          s"clientId, subClientId, currCd, total, VirtUsdTotal, CardNo, RuleMaster, clientdate, subclientdate " +
          s"from " + TRANS_MASTER_CORE_BASE + s" where oiddateyyyymmdd between '$partColStart' and '$partColEnd'  and " +
          s" whenloaded > '$startTime' and whenloaded <= '$endTime' " +
          clientFilter + s" and datasource = '$sourceFilter'")



        val rows_count = rows.count
        transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Number of input rows from source : " + rows_count)


        if (rows_count > 0) {
          /* Step-01: Transformation of Exec Data - Deriving common transformations required for all other controllers*/
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Common Transformations")
          val commondf = common.processCommonTransformation(rows,historicalCurr)
          commondf.persist()
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Common Transformations")

          /* Step-03: Transaction Details data transformations */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Details Transformations")
          val detaildf = detail.processTransDetail(commondf)
          detaildf.persist() // Persisting the data from transaction details for using it in dependency transformations
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Details Transformations")

          /* Step-04: Transaction Rule Hits data transformations */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Rule Hits Transformations")
          val ruleHitsdf = ruleHits.processRuleHits(commondf)
          ruleHitsdf.persist() // Persisting the data from transaction rule hits for using it in dependency transformations
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Rule Hits Transformations")

          val commondf1 = commondf.select($"oid", $"oiddate".as("oiddateintimestamp"), $"DetailLines", $"DetailLinesBand", $"DetailLinesBandDesc", $"Region", $"ClientName", $"SubClientName", $"ClientGroup", $"PSP_GROUP", $"ClientSet", $"Client12", $"CURRCLIENT", $"CURRSUBCLIENT", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient", $"cardnomask", $"ClientDateYYYYMMDD", $"SubClientDateYYYYMMDD", $"WhoLoaded", $"WhenUpdated", $"WhoUpdated")

          val rows1: DataFrame = hiveSession.executeQuery(s"select * from " + TRANS_MASTER_CORE_BASE + s" where oiddateyyyymmdd between '$partColStart' and '$partColEnd' and whenloaded > '$startTime' and whenloaded <= '$endTime' " +
            clientFilter + s" and datasource = '$sourceFilter'")
            .withColumnRenamed("wholoaded", "wholoaded_source")
            .withColumnRenamed("whenupdated", "whenupdated_source")
            .withColumnRenamed("whoupdated", "whoupdated_source")


          val rows2 = rows1.join(commondf1, Seq("oid")).drop("wholoaded_source").drop("whenupdated_source").drop("whoupdated_source")
            .drop($"oiddate").withColumnRenamed("oiddateintimestamp", "oiddate")


          /* Step-02: Transaction Master Core data transformations */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Master Core Transformations")
          val coredf = transMasterCore.processTransMasterCore(rows2)
          coredf.persist() // Persisting the data from transaction master for using it in dependency transformations
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Master Core Transformations")
          /* Step-05: Dependent data transformations  -- Dependent transformations are those that requires data from other tables in order to do a transformation */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Dependent Transformations")
          val finaldataFrame = dependent.processDependencies(coredf, detaildf, ruleHitsdf, hiveSession)
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Dependent Transformations")


          /* Step-05(a): Storing data into Transaction Master Hive table (BI_TRANS_MASTER_CORE) */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Master Core data into Hive")
          try {
            dependent.StoreDateToHive(DBNAME, BI_TRANS_MASTER_CORE, APPEND_MODE, finaldataFrame("Trans_master"))
          } catch {
            case e: Exception =>
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Master core dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
              noOfRetries = noOfRetries + 1
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Error in transflow failed controller " + s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set noofretries=" + noOfRetries + " where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
                " jobid='" + jobId + "' and datasource='" + sourceFilter + "' and jobstatus ='UNPROCESSED'  " +clientFilter+" ")
              hiveSession.executeUpdate(s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set noofretries=" + noOfRetries + " where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
                " jobid='" + jobId + "' and datasource='" + sourceFilter + "' and jobstatus ='UNPROCESSED'  " +clientFilter+" ")
              break
          }

          /* Step-05(b): Storing data into Transaction Details Hive table (BI_TRANS_DETAIL) */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Detail data into Hive")
          try {
            dependent.StoreDateToHive(DBNAME, BI_TRANS_DETAILS, APPEND_MODE, finaldataFrame("Trans_detail"))
          } catch {
            case e: Exception =>
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Details dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
              noOfRetries = noOfRetries + 1
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Error in transflow failed controller " + s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set noofretries=" + noOfRetries + " where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
                " jobid='" + jobId + "' and datasource='" + sourceFilter + "' and jobstatus ='UNPROCESSED'  " +clientFilter+" ")
              hiveSession.executeUpdate(s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set noofretries=" + noOfRetries + " where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
                " jobid='" + jobId + "' and datasource='" + sourceFilter + "' and jobstatus ='UNPROCESSED'  " +clientFilter+" ")
              break
          }

          /* Step-05(c): Storing data into Transaction Rule Hits Hive table (BI_TRANS_RULE_HITS) */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Rule Hits data into Hive")
          try {
            dependent.StoreDateToHive(DBNAME, BI_TRANS_RULE_HITS, APPEND_MODE, finaldataFrame("Rule_hits"))
          } catch {
            case e: Exception =>
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Rule Hits dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
              noOfRetries = noOfRetries + 1
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Error in transflow failed controller " + s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set noofretries=" + noOfRetries + " where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
                " jobid='" + jobId + "' and datasource='" + sourceFilter + "' and jobstatus ='UNPROCESSED'  " +clientFilter+" ")
              hiveSession.executeUpdate(s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set noofretries=" + noOfRetries + " where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
                " jobid='" + jobId + "' and datasource='" + sourceFilter + "' and jobstatus ='UNPROCESSED'  " +clientFilter+" ")
              break
          }

          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set jobstatus='PROCESSED' where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
            " jobid='" + jobId + "' and datasource='" + sourceFilter + "' " +clientFilter+" ")

          val res = hiveSession.executeUpdate(s"Update " + REDI_CONTROL_FOR_MAINFLOW_FAILOVER + " set jobstatus='PROCESSED' where starttime='" + startTime + "' and  endtime='" + endTime + "' and " +
            " jobid='" + jobId + "' and datasource='" + sourceFilter + "' " +clientFilter+" ")

          if (!res) {
            throw new Exception("updated failed in controlfortransflow_fail")
          }
        }
        else {
          transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": There were no data from source")
        }
      }
    }
    if (true) {
      failedTransFlowProcesTransformations()
    }
  }
}


package com.aciworldwide.ra.redi.rstransflow.services

import java.net.{HttpURLConnection, URL}

import com.aciworldwide.ra.redi.common.schemas.CurrencyResponseSchema
import com.aciworldwide.ra.redi.common.services.Loggers
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

import scala.io.Source._
import org.json4s.jackson.JsonMethods.parse

trait DataServices extends Serializable with Loggers{


  /**
    * Temporary method to get the currency information from Hive table
    * This will be replaced with rest api call
    * @return Data frame
    */


  def getDatafromHive(sc:SparkSession, sqlstring: String): DataFrame = {
    val hivedata = sc.sql(sqlstring)
    hivedata
  }



}

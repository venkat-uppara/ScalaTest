package com.aciworldwide.ra.redi.rstransflow.actions

import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.rstransflow.controllers.HistoricalTransFlowFailedController
import org.apache.logging.log4j.LogManager

object HistoricalTransFlowFailedAction extends HistoricalTransFlowFailedController with EstablishConnections with Loggers with Serializable{
  @transient lazy val historicalTransFailLogger = LogManager.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    try {
      transFlowProcesTransformations()
    } catch {
      case e: Exception => historicalTransFailLogger.error(TRANSFLOWPROCESS_ERROR + ": We have an error in the Historical trans flow failed Transformation Process")
        e.printStackTrace()
    } finally {
      historicalTransFailLogger.error(TRANSFLOWPROCESS_ERROR + ": End of Transformation Process,  Transform Historical fail Transaction Flow Data")
    }

  }

}

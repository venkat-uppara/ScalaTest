package com.aciworldwide.ra.redi.bi.models.coretrans;

public class ServiceProcess
{
    public String ServiceName;

    public String ProcessingString;

    public String TransDate;

    public String ServiceType;

    public String SvcStartTime;

    public String SvcEndTime;


}
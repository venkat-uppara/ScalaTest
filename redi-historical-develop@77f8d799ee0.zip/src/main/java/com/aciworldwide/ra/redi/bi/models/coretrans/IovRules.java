package com.aciworldwide.ra.redi.bi.models.coretrans;

public class IovRules {

    public String VirtIovRReason;

    public String VirtIovRType;

    public String VirtIovRScore;
}

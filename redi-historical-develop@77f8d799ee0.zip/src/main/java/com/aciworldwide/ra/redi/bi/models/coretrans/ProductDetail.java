package com.aciworldwide.ra.redi.bi.models.coretrans;

public class ProductDetail
{
    public String ProdQuantity;

    public String ProdUnitPrice;

    public String ProdCategory;

    public String ProdSku;

    public String ProdCd;

    public String Upc;

    public String Manufacturer;

    public String ManPartno;

    public String ProdDesc;

    public String ProdType;

    public String RecipientFirstName;

    public String RecipientLastName;

    public String RecipientMidName;

    public String RecipientSalutation;

    public String RecipientEmail;

    public String RecipientStreet;

    public String RecipientAddress2;

    public String RecipientApt;

    public String RecipientCity;

    public String RecipientState;

    public String RecipientCountry;

    public String RecipientZipcd;

    public String RecipientPhone;

    public String ItemShipMethod;

    public String ItemCarrier;

    public String ItemShipmentNo;

    public String ItemshipInstruction;

    public String ItemShipComments;

    public String ItemWrapped;

    public String ItemCardAttach;

    public String ItemGiftMessage;

    public String ItemGiftCardType;

}

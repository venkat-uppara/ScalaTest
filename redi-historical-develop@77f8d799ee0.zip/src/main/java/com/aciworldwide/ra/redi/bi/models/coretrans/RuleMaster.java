package com.aciworldwide.ra.redi.bi.models.coretrans;

public class RuleMaster
{
    public String RuleSource;

    public String RuleId;

    public String RuleName;

    public String SdsAnswer;

}
package com.aciworldwide.ra.redi.bi.models.coretrans;

public class NumRuleInfo {
    public String ServiceName;

    public String NumRuleHits;

    public String ErrorCount;

    public String Answer;

}
package com.aciworldwide.ra.redi.bi.models.coretrans;

import java.io.Serializable;

public class RuleCategoryFlag implements Serializable
{
    public String RcfSource;
    public String RcfValue;

}
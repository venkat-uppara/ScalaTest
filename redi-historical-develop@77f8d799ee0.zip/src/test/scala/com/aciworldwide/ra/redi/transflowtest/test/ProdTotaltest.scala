/*
package com.aciworldwide.ra.redi.transflowtest.test

import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.controllers.{TransCoreController, TransDetailController}
import com.aciworldwide.ra.redi.transflowtest.services.ReDiTransflowTestSpec
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}


class ProdTotaltest  extends BaseController  with FlatSpec with CommonUtils with Matchers with Eventually with BeforeAndAfter with ReDiTransflowTestSpec {
  val sparkSession: SparkSession = createSparkSession(TRANSDETAILTESTAPP)

  private var rsTransflowControl: TransCoreController = _
  private var rsTransDetailflowControl: TransDetailController = _
  private var rawtrans :DataFrame =_
  private var rbiRefClientData :DataFrame=_
  var clientvalueBand :String = _
  var result : Array[Row] = _
  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    import _sqlc.implicits._

    rsTransflowControl = new TransCoreController(sparkSession)
    rsTransDetailflowControl = new TransDetailController(sparkSession))
    val df = _sqlc.read.option("multiline", "true").json("/tmp/rakeshfiletemp.json")
     rsTransDetailflowControl.prodDetailsTotal(rsTransflowControl(rsTransflowControl.currencyConversionAndValueBands(df)))
    result= rawtrans.select("ProdTotal","ProdTotalUSD","ProdTotalGBP","ProdTotalEUR","ProdTotalClientCurr","ProdTotalSubClientCurr")
      .where($"ProdQuantity"==="55.56").collect().map(x=>x)
    rawtrans.show()

  }

  "This test is used to test for prodTotal." should "be" in {
    val prodTotal = result.map(x=>x.getDecimal(0)).mkString("")
    prodTotal shouldBe "6976.11"
  }

  "This test is used to test for totalUSD." should "be" in {
    val prodTotal = result.map(x=>x.getDecimal(1)).mkString("")
    prodTotal shouldBe "243.26"
  }

  "This test is used to test for ProdTotalGBP." should "be" in {
    val prodTotal = result.map(x=>x.getDecimal(2)).mkString("")
    prodTotal shouldBe "5319.06"
  }

  "This test is used to test for ProdTotalEUR." should "be" in {
    val prodTotal = result.map(x=>x.getDecimal(3)).mkString("")
    prodTotal shouldBe "5980.72"
  }

  "This test is used to test for ProdTotalClientCurr." should "be" in {
    val prodTotal = result.map(x=>x.getDecimal(4)).mkString("")
    prodTotal shouldBe "476886.88"
  }

  "This test is used to test for ProdTotalSubClientCurr." should "be" in {
    val prodTotal = result.map(x=>x.getDecimal(5)).mkString("")
    prodTotal shouldBe "131705.06"
  }
}*/

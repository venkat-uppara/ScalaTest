/*
package com.aciworldwide.ra.redi.transflowtest.test

/**
  * @author : GR
  * @note : Contains the unit test suite for all the currencyConversions
  */

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.rstransflow.controllers.TransCoreController
import com.aciworldwide.ra.redi.transflowtest.services.ReDiTransflowTestSpec
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}


case class RawTransMasterDfSchema (Oid: String, OidDate: String, clientId: String, subClientId: String, currCd: String, VirtUSDTotal: String, total: String)
class CurrencyTotalandBandTest extends BaseController with FlatSpec
  with Matchers with Eventually with BeforeAndAfter with ReDiTransflowTestSpec with ReDiConstants{

  val sparkSession: SparkSession = createSparkSession(TRANSMASTERTESTAPP)

  private var rsTransflowControl: TransCoreController = _
  private var rawtrans :DataFrame =_
  private var rbiRefClientData :DataFrame=_
  val data = Array(
    RawTransMasterDfSchema("120", "08022018", "001018", "000002", "EUR", "", "175"))
  var clientvalueBand :String = _
  var result : Array[Row] = _
  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    import _sqlc.implicits._

    rsTransflowControl = new TransCoreController(sparkSession)
    rawtrans =  rsTransflowControl.currencyConversionAndValueBands(_sqlc.sparkContext.parallelize(data).toDF())
    result = rawtrans.select("TotalGBP","TotalEUR","TotalClient","TotalSubClient","GBPValueBand","EURValueBand","ClientValueBand","SubClientValueBand"
      ,"GBPValueBandCode","EURValueBandCode","ClientValueBandCode","SubClientValueBandCode").collect().map(x=>x)
  }

  "This test is used to test for totalGbp." should "be" in {
    val totalGbp = result.map(x=>x.getString(0)).mkString("")
    totalGbp shouldBe "155.63947398502768"
  }

  "This test is used to test for TotalEUR." should "be" in {
    val totalEUR = result.map(x=>x.getString(1)).mkString("")
    totalEUR shouldBe "175"
  }

  "This test is used to test for TotalClient." should "be" in {
    val totalClient = result.map(x=>x.getString(2)).mkString("")
    totalClient shouldBe "3853.783269607169"
  }

  "This test is used to test for TotalSubClient." should "be" in {
    val ColResult = result.map(x=>x.getString(3)).mkString("")
    ColResult shouldBe "204.12590952673116"
  }

  "This test is used to test for GBPValueBand." should "be" in {
    val ColResult = result.map(x=>x.getString(4)).mkString("")
    ColResult shouldBe "£100-£200"
  }

  "This test is used to test for EURValueBand." should "be" in {
    val ColResult = result.map(x=>x.getString(5)).mkString("")
    ColResult shouldBe "EUR100-200"
  }
  "This test is used to test for ClientValueBand." should "be" in {
    val ColResult = result.map(x=>x.getString(6)).mkString("")
    ColResult shouldBe "MXN2000-5000"
  }
  "This test is used to test for SubClientValueBand." should "be" in {
    val ColResult = result.map(x=>x.getString(7)).mkString("")
    ColResult shouldBe "$200-$300"
  }
  "This test is used to test for GBPValueBandCode." should "be" in {
    val ColResult = result.map(x=>x.getString(8)).mkString("")
    ColResult shouldBe "VA0100"
  }

  "This test is used to test for EURValueBandCode." should "be" in {
    val ColResult = result.map(x=>x.getString(9)).mkString("")
    ColResult shouldBe "VA0100"
  }
  "This test is used to test for ClientValueBandCode." should "be" in {
    val ColResult = result.map(x=>x.getString(10)).mkString("")
    ColResult shouldBe "VA2000"
  }
  "This test is used to test for SubClientValueBandCode." should "be" in {
    val ColResult = result.map(x=>x.getString(11)).mkString("")
    ColResult shouldBe "VA0200"
  }

}
*/

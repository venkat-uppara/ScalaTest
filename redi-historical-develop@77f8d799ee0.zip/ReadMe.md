TIM Redi-Historical repository

===============================================================================
Install and Initialize Git Bash

Request git installation through the ACI Application Store.  
After is has been installed follow these steps to initialize it before using.

From the Windows Start menu, navigate to the git folder and select Git Bash.  This will open unix bash shell like command line window.

Enter the following commands substituting your name:

git config --global user.name "FirstName LastName"
git config --global user.email first.last@aciworldwide.com
git config --global core.autocrlf true (DO NOT SET ON UNIX)
git config --global push.default simple
git config --global http.sslVerify false

If you are working from a UNIX (Linux) machine and you get a "Proxy CONNECT aborted" set the following:

export NO_PROXY= bitbucket.am.tsacorp.com

===============================================================================
Setup SSH Authentication to BitBucket

To eliminate the need to continually provide credentials to git, you can setup your BitBucket account for SSH.  
To do this you need to create an SSH key for each user account/system pair you want to use for connecting to BitBucket.

 
Instructions on how to setup BitBucket for SSH can be found here:
https://confluence.atlassian.com/bitbucketserver0515/using-ssh-keys-to-secure-git-operations-961275232.html

or 

To create a key:
-Using the account you want to create the key for, log into the system.
-From the Start menu, navigate to the Git folder and open Git Bash.
-Type ssh-keygen and press Enter.
-Press Enter to accept all defaults.
-Change directories to your user home directory plus /.ssh.  This will generally be /c/users/me/.ssh
-Type clip < id_rsa.pub and press Enter.  This will copy your public key into the clipboard.
-Log-in to BitBucket here https://bitbucket.am.tsacorp.com/projects
-In the upper right corner, locate the drop-down with your avatar.  Open the drop-down and select Manage Account.
-On the left, select SSH keys
-Click the Add key button.
-Paste the key into the Key box and click Add key.
 
Now when cloning your repository, in the clone dialog select SSH instead of the HTTP address.  The address will look like:
 
ssh://git@bitbucket.am.tsacorp.com:7999/TIM/Redi-Historical.git
 
===============================================================================
Git Basics, Getting Started
 
Some useful procedures
 
Initial setup for git
 
git config --global user.name "Ken Cook"
git config --global user.email ken.l.cook@aciworldwide.com
git config --global core.autocrlf=true
 
Clone a new repository
 
git clone ssh://git@bitbucket.am.tsacorp.com:7999/TIM/Redi-Historical.git

Make a change to a file and commit it to the master repository
 
git fetch origin
git checkout -f feature/mybranchname
git pull
notepad myfile
git commit -a -m "changed important stuff to myfile"
git pull
git push

Create a new branch

git fetch origin
git checkout -b feature/mybranchname [tag or commit id if not HEAD]
git push --set-upstream origin feature/mybranchname
 
Merge changes from branchA to branchB

git fetch origin
git checkout branchB
git pull
git merge branchA
git push

Merge selected changes from branchA to branchB

git fetch origin
git checkout branchB
git pull
git cherry-pick -m 1 [list of commits from branchA]
git push

===============================================================================
Working with your repository

I just want to clone this repository
If you want to simply clone this empty repository then run this command in your terminal.

git clone ssh://git@bitbucket.am.tsacorp.com:7999/TIM/Redi-Historical.git

My code is ready to be pushed
If you already have code ready to be pushed to this repository then run this in your terminal.

cd existing-project
git init
git add --all
git commit -m "Initial Commit"
git remote add origin ssh://git@bitbucket.am.tsacorp.com:7999/TIM/Redi-Historical.git
git push -u origin master

My code is already tracked by Git
If your code is already tracked by Git then set this repository as your "origin" to push to.

cd existing-project
	git remote set-url origin ssh://git@bitbucket.am.tsacorp.com:7999/TIM/Redi-Historical.git
	git push -u origin --all
	git push origin --tags

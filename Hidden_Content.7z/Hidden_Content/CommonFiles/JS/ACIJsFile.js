// JScript source code
var cidchange  = 0 ;
var scidchange = 0 ;
var currchange = 0 ;
var fdchange = 0 ;
var tdchange = 0 ;
 
 
function date_alert(cntl_nme){
//var val_date = IbComposer_getComponentById(cntl_nme).value ;
//if (val_date == ''){
alert('Please select a date from the Calendar Control');
//}
}
 
 
//Begin Date Range Validation
function dateRangeValidtion(startDate,endDate){
     var objFromDate = IbComposer_getComponentById(startDate).value;
     var objToDate = IbComposer_getComponentById(endDate).value;
 
    if(new Date(objFromDate) > new Date(objToDate))
    {
       alert("To Date should be greater than or equal to From Date.");
       var curr_date = new Date();
       var month = curr_date.getMonth()+1;
       var day = curr_date.getDate();
       //var reset_toDate = curr_date.getFullYear() + '/' + (month<10 ? '0' : '') + month + '/' +(day<10 ? '0' : '') + day;
       var reset_toDate = curr_date.getFullYear()+ '/' +(month<10 ? '0' : '') + month + '/' +(day<10 ? '0' : '') + day;

       IbComposer_getComponentById(startDate).value = "";
       IbComposer_getComponentById(endDate).value = "";

       IbComposer_getComponentById(startDate).value = reset_toDate ;
       IbComposer_getComponentById(endDate).value = reset_toDate ;
       return false;
     
}
}
//End Date Range Validation
 
function checkdate(input){
var validformat=/^\d{4}\/\d{2}\/\d{2}$/ //Basic check for format validity
var returnval=false
var yearfield=input.value.split("/")[0]
var monthfield=input.value.split("/")[1]
var dayfield=input.value.split("/")[2]
var dayobj = new Date(yearfield, monthfield-1, dayfield)
if ((dayobj.getFullYear()!=yearfield)||(dayobj.getMonth()+1!=monthfield)||(dayobj.getDate()!=dayfield))
alert("Invalid Day, Month, or Year range detected. Please correct and submit again.")
else
returnval=true
 
if (returnval==false) input.select()
return returnval
}
 
 
function checkdate_txt(input){
var validformat=/^\d{4}\/\d{2}\/\d{2}$/ //Basic check for format validity
var returnval=false
if (!validformat.test(input.value)) {
alert("Please enter in YYYY/MM/DD Format. Please correct and submit again.")
 
}
else{ //Detailed check for valid date ranges
var yearfield=input.value.split("/")[0]
var monthfield=input.value.split("/")[1]
var dayfield=input.value.split("/")[2]
var dayobj = new Date(yearfield, monthfield-1, dayfield)
if ((dayobj.getFullYear()!=yearfield)||(dayobj.getMonth()+1!=monthfield)||(dayobj.getDate()!=dayfield))
alert("Invalid Day, Month, or Year range detected. Please correct and submit again.")
else
returnval=true
}
if (returnval==false) input.select()
return returnval
}
 
 
function isNumberKey(evt, element) {
  var charCode = (evt.which) ? evt.which : event.keyCode
  if (charCode > 31 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8))
    {alert("Please Enter Numeric");
    return false;
  }
  else {
    var len = $(element).val().length;
    var index = $(element).val().indexOf('.');
    if (index > 0 && charCode == 46) {
      return false;
    }
    if (index > 0) {
      var CharAfterdot = (len + 1) - index;
      if (CharAfterdot > 10) {
        return false;
      }
    }
  }
  return true;
}
 
 
//Added Dynamic Filter validation
 
function ValidDate(dateStr) {
 
 // Checks for the following valid date formats:
 // YYYY/MM/DD
 var datePat = /^\d{4}\/\d{2}\/\d{2}$/;
 //var datePat = /^\2(\d{4}|\d{4})(\d{2,2})(\/)(\d{2,2})$/;
 var matchArray = dateStr.match(datePat); // is the format ok?
 if (matchArray == null) {
  alert("Date must be in YYYY/MM/DD format")
  return 0;
 }
 var datesplit=dateStr.split(/[\\\/]/);
 month = datesplit[1]; // parse date into variables
 day = datesplit[2];
 year = datesplit[0];
 if (month < 1 || month > 12) { // check month range
  alert("Month must be between 1 and 12");
  return 0;
 }
 if (day < 1 || day > 31) {
  alert("Day must be between 1 and 31");
  return 0;
 }
 if ((month==4 || month==6 || month==9 || month==11) && day==31) {
  alert("Month "+month+" doesn't have 31 days!")
  return 0;
 }
 if (month == 2) { // check for february 29th
  var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
  if (day>29 || (day==29 && !isleap)) {
   alert("February " + year + " doesn't have " + day + " days!");
   return 0;
    }
 }
 return 1;  // date is valid
 
}
 
//Validate Numeric Values 
function NumericValidation(inputstring)
{
 
var pattern =/^(0|[1-9]\d*)(\.\d+)?$/;
    var result = pattern.test(inputstring);
 
    if (result == false)
    {
        alert("Please insert a valid numeric value ");
        return 0;
    }
    else
    {
        return 1;
    }
}
 
 
 
 
// Dynamic Filter Addition and Remove
//Initialize the  variable
var id = 1;
var cnt = 1;
var filter_cnt=0;
 
function Dynamic_Filter() {
document.getElementById("Dynamic_Filter_Panel").style.display= "block";
if( filter_cnt<8)
{
/* Dynamic panel creation */
filter_cnt=filter_cnt+1; 
var fieldWrapper1 = $("<div class='IBI_Panel IBI_rounded_m internal_default IBI_ResponsiveElement' id='field" + cnt + " 'style='min-height:40px; border:none'/>");
var fieldWrapper2 = $("<div class='IBI_Panel IBI_rounded_m internal_default IBI_ResponsiveElement' id='field" + cnt + " 'style='min-height:40px; border:none'/>");
var fieldWrapper3 = $("<div class='IBI_Panel IBI_rounded_m internal_default IBI_ResponsiveElement' id='field" + cnt + " 'style='min-height:40px; border:none'/>");
var fieldWrapper4 = $("<div class='IBI_Panel IBI_rounded_m internal_default IBI_ResponsiveElement' id='field" + cnt + " 'style='min-height:0px; border:none'/>");
 
//Column name drop down creation
ddc = document.createElement("select");
ddc.setAttribute("id", "DropDownCol"+id);
ddc.className = 'DDC';
ddc.style.position = "absolute";
ddc.style.width = "100px";
ddc.style.left= "21px";
ddc.classList.add("drop_down");
var column_length=document.getElementById("Dynamic_Column_Drop_Down").options.length;
//var avalues = IbComposer_getCurrentSelectionEx('Dynamic_Column_Drop_Down');
for (i=0; i<column_length; i++)
  {
    var aset = new Option();
    aset.text = document.getElementById("Dynamic_Column_Drop_Down").options[i].text;
    aset.value = document.getElementById("Dynamic_Column_Drop_Down").options[i].value;
//      aset.text  = avalues[i].getDisplayValue();
//      aset.value = avalues[i].getValue();
    ddc.options.add(aset);
  }
//Operator drop down creation
ddo = document.createElement("select");
ddo.setAttribute("id", "DropDownOpr"+id);
ddo.className = 'DDO';
ddo.style.position = "absolute";
ddo.style.left= "21px";
ddo.style.width = "30px";
ddo.classList.add("drop_down");
var opr_length=document.getElementById("Dynamic_Operator_Drop_Down").options.length;
//var bvalues = IbComposer_getCurrentSelectionEx('Dynamic_Operator_Drop_Down');
for (j=0; j<opr_length; j++)
  {
    var bset= new Option();
    bset.text = document.getElementById("Dynamic_Operator_Drop_Down").options[j].text;
    bset.value = document.getElementById("Dynamic_Operator_Drop_Down").options[j].value;
//      bset.text  = bvalues[j].getDisplayValue();
//      bset.value = bvalues[j].getValue();
 
    ddo.options.add(bset);
  }
//Input box creation 
var ddv = document.createElement("input");
ddv.setAttribute("id", "DropDownTxt"+id);
ddv.className = 'DDV';
ddv.style.position = "absolute";
ddv.style.left= "21px";
ddv.style.width = "100px";
ddv.classList.add("text-box");
//ddv.setAttribute('onChange','var inputs_ddc = $(".DDC");var colname_datatype=$(inputs_ddc.val();var split_string=colname_datatype.split('|', 2);var col_name= split_string[0];var col_dataype= split_string[1].toUpperCase();if( col_dataype == "DATE" || col_dataype == "TIMESTAMP"){ checkdate_txt($(inputs_ddv[i]).val()) }');
//Remove button creation  
var oImg = document.createElement("img");
oImg.setAttribute("id", "DropDownImg"+id);
oImg.setAttribute('src', '/ibi_apps/WFServlet.ibfs?IBFS1_action=RUNFEX&IBFS_path=/WFC/Repository/ReDi/Hidden_Content/CommonFiles/Images/minus.png');
oImg.setAttribute('alt', 'NA');
oImg.style.top= '-36px';
oImg.style.left= '305px';
oImg.style.height = '14px';
oImg.style.width = '14px';
oImg.style.position = "absolute";
oImg.style.margin = '0px';
oImg.style.cursor= 'pointer';
//oImg.setAttribute('onclick','$(this).parent().parent().remove();var ctrl_panel= document.getElementById("RS_Summary_Filter_ControlPanel");var ctrl_panel_height = ctrl_panel.offsetHeight;var ctrl_panel_new_height = ctrl_panel_height - 120;ctrl_panel.style.minHeight = ctrl_panel_new_height + "px"; var Dynamic_Filter_Pnl_Rmv= document.getElementById("Dynamic_Filter_Panel");var Dynamic_Filter_Pnl_height_Rmv = Dynamic_Filter_Pnl_Rmv.offsetHeight;var Dynamic_Filter_Pnl_new_height_Rmv = Dynamic_Filter_Pnl_height_Rmv - 120;Dynamic_Filter_Pnl_Rmv.style.minHeight = Dynamic_Filter_Pnl_new_height_Rmv + "px";filter_cnt=filter_cnt-1;id-=1;  alert(filter_cnt);');
oImg.setAttribute('onclick','$(this).parent().parent().remove();var Dynamic_Filter_Pnl_Rmv= document.getElementById("Dynamic_Filter_Panel");var Dynamic_Filter_Pnl_height_Rmv = Dynamic_Filter_Pnl_Rmv.offsetHeight;var Dynamic_Filter_Pnl_new_height_Rmv = Dynamic_Filter_Pnl_height_Rmv - 120;Dynamic_Filter_Pnl_Rmv.style.minHeight = Dynamic_Filter_Pnl_new_height_Rmv + "px";filter_cnt=filter_cnt-1;id-=1; if (filter_cnt == 0) document.getElementById("Dynamic_Filter_Panel").style.display= "none";');
 
//Adding all the controls into dynamic panels
fieldWrapper1.append(ddc);
fieldWrapper2.append(ddo);
fieldWrapper3.append(ddv);
fieldWrapper4.append(oImg)
 
var newRow = $("<div class='IBI_Panel IBI_rounded_m internal_default IBI_ResponsiveElement' id='row'style='min-height:120px; border:none;margin-left:0px'/> ");
 
$(newRow).append(fieldWrapper1);
$(newRow).append(fieldWrapper2);
$(newRow).append(fieldWrapper3);
$(newRow).append(fieldWrapper4);
$(Dynamic_Filter_Panel).append(newRow);
 
id+=1; 
}
else 
{
    alert("Maximum 8 filter are allowed .If you want to add additional filter please remove anyone of the filters and proceed!!!");
    return false;
 }
}
//Get Dynamic Filters value and validation
function getDynamicFiltersVal()
{
    var inputs_ddc = $(".DDC");
    var inputs_ddo = $(".DDO");
    var inputs_ddv = $(".DDV");
    var where_condition= "";
    var null_string="_FOC_NULL";
    var val_response=[];
    for(var i = 0; i < inputs_ddc.length; i++)
    {
        var colname_datatype=$(inputs_ddc[i]).val();
        var split_string=colname_datatype.split('|', 2);
        var col_name= split_string[0].replace( /\s/g, '');
        var col_dataype= split_string[1].toUpperCase();
        var input_string=$(inputs_ddv[i]).val();
        if( col_dataype == 'STRING' || col_dataype == 'DATE'|| col_dataype == 'TIMESTAMP')
        {
            if( col_dataype == 'DATE'|| col_dataype == 'TIMESTAMP')
            {
                if (  $(inputs_ddv[i]).val() == "")
                {
                     where_condition+=' \n';
                 }
                else
                {
                    val_response.push(ValidDate(input_string));
                    where_condition+= 'WHERE '+col_name+' '+$(inputs_ddo[i]).val()+' '+"'"+$(inputs_ddv[i]).val()+"'"+'; \n';
                }    
            }
            else
            {
                  if (  $(inputs_ddv[i]).val() == "")
                   {
                    //where_condition+ = 'WHERE '+ col_name +' ' + $(inputs_ddo[i]).val() + ' '+ "'" + null_string + "'; \n" ;
                    where_condition+=' \n';
                    val_response.push(1);
                    }
                    else
                    {
                        //alert($(inputs_ddv[i]).val()); 
                       //checkdate_txt($(inputs_ddv[i]).val())
                        where_condition+= 'WHERE '+col_name+' '+$(inputs_ddo[i]).val()+' '+"'"+$(inputs_ddv[i]).val()+"'"+'; \n';
                       val_response.push(1);
                    }    
            }
        }
        else
        {    
          if ( $(inputs_ddv[i]).val() == "")
            {
              // where_condition+ = 'WHERE '+col_name+' '+$(inputs_ddo[i]).val()+' '+"'"+_FOC_NULL+"'"+'; \n';
                where_condition+=' \n';
               val_response.push(1);
            } 
            else
            {
                val_response.push(NumericValidation(input_string));
                where_condition+= 'WHERE '+col_name+' '+$(inputs_ddo[i]).val()+' '+$(inputs_ddv[i]).val()+'; \n';
            }
       }
    }
var response=[val_response,where_condition];
return response;
}

package com.org.aci.stream.service.model;

public class ServiceProcess
{
    public String ServiceName;

    public String ProcessingString;

    public String TransDate;

    public String ServiceType;

    public String SvcStartTime;

    public String SvcEndTime;


}
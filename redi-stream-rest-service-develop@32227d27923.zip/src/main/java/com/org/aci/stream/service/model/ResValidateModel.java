package com.org.aci.stream.service.model;
import java.util.List;
import java.util.StringJoiner;


public class ResValidateModel {
    private String results;

    public String getResults() {
        return results;
    }

    public void setResults(String results) {
        this.results = results;
    }
}

package com.org.aci.stream.service.model;

public class IovRules {
    public String VirtIovRReason;

    public String VirtIovRType;

    public String VirtIovRScore;

}

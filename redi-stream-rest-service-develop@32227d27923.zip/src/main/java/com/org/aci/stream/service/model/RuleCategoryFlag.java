package com.org.aci.stream.service.model;

import java.io.Serializable;

public class RuleCategoryFlag implements Serializable
{

    public String RcfSource;
    public String RcfValue;

}
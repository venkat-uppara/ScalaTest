#!/usr/bin/env bash
kill $(cat ./pid.file)
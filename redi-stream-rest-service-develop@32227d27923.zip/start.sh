#!/usr/bin/env bash
#auth
principal=srvredi@IPA.AM.TSACORP.COM
keyTab=/home/srvredi/keytabs/srvredi.keytab
kinit $principal -k -t $keyTab


java "-Djava.security.auth.login.config=/home/srvredi/auth/jaas.conf" -jar stream-rest-service-api-0.0.1.jar --spring.config.location=file:application.properties & echo $! > ./pid.file &